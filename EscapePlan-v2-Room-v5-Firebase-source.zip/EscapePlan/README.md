# EscapePlan 2.2 — merged Android source, Room v5 + Firebase

## 108-place India catalogue and screen refresh

The supplied `India_Hidden_Places_108_Catalogue.xlsx` is retained under
`data-sources` and converted into the offline asset
`app/src/main/assets/hidden_places_catalog.json`. The app validates and displays
108 unique places: three entries for each of 28 states and 8 union territories.
Every entry preserves its categories, reason to visit, best season, suggested
time, difficulty, stay area and suggestion, food, transport, caution/permit note,
evidence status, source and discovery links, and last-reviewed date.

The root navigation now follows the supplied screen references: **Home**,
**Explore**, a raised central **Plan** action, **Saved**, and **Me**. Home searches
and filters the 108-place catalogue. Explore uses the existing rich destination
cards with category and budget chips. Saved lists normalized Room v5 plans and
shows the referenced empty state. Me uses the referenced profile/preferences and
settings layout. The warm terracotta light/dark theme is shared across screens.

The catalogue remains an offline asset rather than a new Room table, so Room stays
at schema v5 and existing data is unaffected. Live catalogue editing or Firebase
catalogue synchronization is not included. External links open current searches;
the app does not scrape or cache Google, OYO, MakeMyTrip, Instagram or Facebook.
Run `python3 tests/check_hidden_places_catalog.py` after catalogue updates.

## Places catalog update

Open **Categories** in the top app bar to browse the 12 supplied groups, search
names and aliases, expand travel details, open a matching existing guide, or start
a planner prompt. There are 54 unique entries and 60 category memberships.
Repeated places share one entry; category labels preserve the user's grouping
and are not independently verified classifications.

The offline asset `app/src/main/assets/places_catalog.json` holds the cleaned
catalog, including all supplied Goa and Udaipur coordinates, seasons, airport and
railway names, six hotels, four food suggestions and eight attractions. It is
loaded through a Result-returning repository and StateFlow ViewModel. Missing
fields remain absent. Alternate names include Kashi/Varanasi, Pondicherry/
Puducherry, Gurgaon/Gurugram and Mysore/Mysuru. The supplied `goa_beach` and
`udaipur_royal` identifiers are aliases, so identity does not depend on category.

The supplied simplified `DestinationEntity` is represented by a serializable
`PlaceCatalogEntry` DTO with multiple categories. It does not replace the existing
Room entity or duplicate its table. The asset works offline without a schema
change; Room remains v5. Existing catalog content and user trips are preserved.
The new categories are available in their own browser; they do not change the
legacy Explore category taxonomy or overwrite conflicting existing guide data.

To edit or add entries, update this JSON, keep IDs unique and stable, and supply
only known fields. Rebuild to distribute catalog edits. Run
`python3 tests/check_places_catalog.py` to check the current supplied catalog's
membership, aliases and detailed records. Update its expected counts when adding
more places. Live editing/admin sync is not implemented.

This project extends the merged source from `EscapePlan-main (3).zip` and
`untitled.zip`. It retains the combined India destination catalog, detailed
destination pages, favorites, offline planner and legacy saved trips.

The implementation is source-complete for review, but has **not been compiled or
run on Android** in this environment. No APK/AAB, cloud deployment or live billing
verification is included. Follow `SETUP.md` before building.

## Changes

| Area | Implementation |
| --- | --- |
| Database | Explicit, additive v4→v5 migration; profiles and normalized trip/day/activity tables; existing saved-trip JSON remains readable in My Trips. |
| Navigation | Kotlin Serialization typed routes, shared Material 3 scaffold and five-tab navigation, transitions, destination IDs and trip deep links. Root back handling is delegated to Navigation/Android. |
| UI | Reusable loading shimmer, retry banner and empty state; existing light/dark theme; profile, map, planner and paywall screens. |
| Authentication | Firebase email/password and Credential Manager Google sign-in, password reset, profile sync with local pending-write recovery. |
| Session | Android Keystore AES-GCM encrypted DataStore for app identity and entitlement cache. Firebase SDK manages its own authentication credentials; this store does not wrap Firebase's internal token persistence. |
| Search/maps | 300 ms debounced local + Places search, India restriction, Maps Compose pins, optional location, permission-denied fallback, destination/photo sheet and planner handoff. |
| AI | Authenticated, App Check protected Cloud Function calls Gemini with a JSON schema; both server and Android validate; Room save is transactional. |
| Timeline | Day tabs, long-press activity movement, accessible up/down controls, manual activity replacement, cancellation and recovery of recent completed server jobs. |
| Offline/sharing | Local trip read/edit/delete, formatted text, local deep link and paginated PdfDocument export through FileProvider. |
| Billing | Play Billing 8, subscription/pass product lookup, server token verification, account binding, restore, acknowledgement/consumption and refund notifications. |
| Release | Signing from protected properties/environment, R8/resource shrinking, tag-triggered lint/tests followed by signed APK/AAB builds. |

## Behavior and current limits

- Destination data, distances, prices, hotels, seasons and labels come from the
  uploaded projects. They have not been refreshed or independently verified.
  The AI Studio URL is not a live data feed. `README-MERGE.md` records catalog
  precedence and deduplication rules. Edit the catalog sources under
  `data/datasource` or `data/imported`; run `check_catalog.py` afterwards.
- Maps **Add to Trip** fills a new planner prompt. It does not append a stop to an
  existing itinerary. Existing destination detail pages provide the richer local
  travel information; Places results do not include a complete travel guide.
- Legacy saved trips remain in their original tables. They are not converted into
  the new normalized timeline format. New timeline plans are available through
  Planner and the link in My Trips.
- `escapeplan://trip/{tripId}` opens a trip already stored for the current account
  on the device. It is not a public cloud-sharing URL. Share text or PDF to deliver
  content to somebody else. Completed AI jobs can be recovered from the latest
  20 server jobs; local edits are not synchronized across devices.
- Cancelling stops the local coroutine; an accepted server job can still finish
  and consume a pass. Recovery retrieves its result. Failed jobs refund reserved
  credits; scheduled reconciliation handles jobs stalled over ten minutes.
- Default policy is three free generations per UTC day, then premium or a pass,
  with 50 total generation attempts per day including failures. Premium therefore
  has a fair-use cap, not literally unlimited generation. Change the policy and
  paywall copy together before launch if different terms are intended.
- A pass unlocks one additional generation after the free allowance and PDF for
  that generated trip. Premium enables PDF and custom pin colors. Cached premium
  access lasts at most 24 hours after verification and never beyond expiry;
  previously verified pass-unlocked trips remain exportable offline.
- OS backup/device transfer is disabled for app data to avoid restoring encrypted
  values without their Keystore key. Uninstalling can remove local trips; exports
  are not a restorable database backup.
- This is not a complete production launch package: account deletion UX,
  retention/cleanup policies, public cloud trip sharing, billing integration tests,
  accessibility/device screenshots and production operational monitoring still
  need work. Backend dependencies have no generated lockfile yet.

## Verification actually performed

- Hidden-place import check: passed 108 unique records, 36 jurisdictions,
  three entries per jurisdiction, required fields and HTTPS discovery links.
- Python catalog structure/wiring check: passed (1,159 named constructor calls).
- Python SQLite migration smoke test: passed additive SQL, legacy row retention
  and cascading deletion. This is not Android Room migration validation.
- Node syntax check and 11 itinerary contract tests: passed.
- XML, workflow YAML and Firebase JSON parsing: passed.

Room migration tests, Kotlin contract tests and existing Android unit tests are
included but **not executed**. Gradle, Android SDK and a Kotlin compiler were not
available; dependency retrieval was blocked/timed out. Lint, compilation, release
signing, device navigation, permission flows, Firebase rules/emulator tests and
Play test-track purchases remain unverified. The supplied screen references were
implemented in Compose but could not be rendered on an Android device here. CI is configured to gate release
artifacts on lint and unit tests; no CI run has been performed here.

## Source layout

`app/src/main/java/com/example/data/local` contains Room entities and migration;
`data/auth` and `data/repository` contain auth, profile, trip and billing layers;
`domain` contains the itinerary contract/use case; `ui/screens`, `ui/components`
and `ui/viewmodel` contain Compose and StateFlow presentation; `functions` contains
the server; root Firebase configuration contains access rules and indexes.
