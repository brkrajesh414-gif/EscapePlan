"""Exercises migration SQL using SQLite, without claiming Room runtime validation."""
import re
import sqlite3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / 'app/src/main/java/com/example/data/local/Migration4To5.kt').read_text()
statements = re.findall(r'db\.execSQL\("([^"\n]+)"\)', source)
assert len(statements) == 6
db = sqlite3.connect(':memory:')
db.execute('PRAGMA foreign_keys=ON')
db.execute('CREATE TABLE saved_trips (id TEXT PRIMARY KEY, itineraryJson TEXT NOT NULL)')
db.execute('INSERT INTO saved_trips VALUES (?, ?)', ('legacy', '{"title":"Keep me"}'))
for sql in statements:
    db.execute(sql)
assert db.execute('SELECT itineraryJson FROM saved_trips WHERE id=?', ('legacy',)).fetchone()[0] == '{"title":"Keep me"}'
db.execute("INSERT INTO planner_trips VALUES ('trip','Title','uid','INR',1,1)")
db.execute("INSERT INTO day_schedules VALUES ('day','trip',1,'Day one')")
db.execute("INSERT INTO trip_activities VALUES ('activity','day',0,'09:00','Museum','Confirm locally',NULL,NULL,200)")
db.execute("DELETE FROM planner_trips WHERE id='trip'")
assert db.execute('SELECT count(*) FROM day_schedules').fetchone()[0] == 0
assert db.execute('SELECT count(*) FROM trip_activities').fetchone()[0] == 0
assert db.execute('PRAGMA foreign_key_check').fetchall() == []
assert db.execute('SELECT count(*) FROM saved_trips').fetchone()[0] == 1
print('PASS: six migration statements, legacy-row preservation, cascading deletes and foreign keys.')
print('Room schema validation and actual v4-device upgrade testing remain required.')
