import json
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parents[1]
entries = json.loads((root / "app/src/main/assets/hidden_places_catalog.json").read_text())
assert len(entries) == 108
assert len({entry["id"] for entry in entries}) == 108
regions = Counter(entry["stateOrUt"] for entry in entries)
assert len(regions) == 36
assert all(count == 3 for count in regions.values())
assert sum(entry["regionType"] == "State" for entry in entries) == 84
assert sum(entry["regionType"] == "Union territory" for entry in entries) == 24
required = {
    "id", "stateOrUt", "regionType", "name", "districtOrBase", "categories", "whyVisit",
    "bestSeason", "suggestedTime", "difficulty", "stayArea", "staySuggestion", "foodToTry",
    "transport", "cautionOrPermit", "evidenceStatus", "primarySourceUrl", "googleMapsUrl",
    "googleHotelsUrl", "makeMyTripUrl", "oyoUrl", "foodMapUrl", "instagramUrl", "facebookUrl",
    "lastReviewed"
}
for entry in entries:
    assert set(entry) == required
    assert all(entry[field] for field in required - {"primarySourceUrl"})
    assert entry["categories"] and len(entry["categories"]) == len(set(entry["categories"]))
    for field in ["googleMapsUrl", "googleHotelsUrl", "makeMyTripUrl", "oyoUrl", "foodMapUrl", "instagramUrl", "facebookUrl"]:
        assert entry[field].startswith("https://")
    assert "HYPERLINK is not implemented" not in json.dumps(entry)
assert (root / "data-sources/India_Hidden_Places_108_Catalogue.xlsx").is_file()
print("PASS: 108 unique places, three per state/UT, all required app fields and live-link URLs.")
print("Travel facts and external availability still require current local verification.")
