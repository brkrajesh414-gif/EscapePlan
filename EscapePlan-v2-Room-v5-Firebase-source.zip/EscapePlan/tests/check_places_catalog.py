import json
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parents[1]
catalog = json.loads((root / "app/src/main/assets/places_catalog.json").read_text())
assert len(catalog) == 54
assert len({p["id"] for p in catalog}) == len(catalog)
assert len({p["name"].casefold() for p in catalog}) == len(catalog)
categories = Counter(c for p in catalog for c in p["categories"])
assert set(categories) == {"Beach", "Mountain", "Religious", "Party", "Royal", "Food", "Ancient", "Snow", "Green", "Waterfall", "River", "Lake"}
assert all(count == 5 for count in categories.values())
assert "Click to open" not in json.dumps(catalog)
by_name = {p["name"]: p for p in catalog}
assert set(by_name["Varanasi"]["categories"]) == {"Religious", "Food", "River"}
assert "Kashi" in by_name["Varanasi"]["aliases"]
assert "Pondicherry" in by_name["Puducherry"]["aliases"]
assert "Gurgaon" in by_name["Gurugram"]["aliases"]
assert "Mysore" in by_name["Mysuru"]["aliases"]
for place in catalog:
    assert place["id"] and place["name"]
    assert len(place["categories"]) == len(set(place["categories"]))
    assert (place.get("latitude") is None) == (place.get("longitude") is None)
    if place.get("latitude") is not None:
        assert -90 <= place["latitude"] <= 90
        assert -180 <= place["longitude"] <= 180
    for hotel in place.get("popularHotels", []):
        assert set(hotel) == {"name", "priceTier", "location"}
        assert all(hotel.values())
    for food in place.get("popularFoodSpots", []):
        assert set(food) == {"dishOrCuisine", "recommendedSpot"}
        assert all(food.values())
for name in ["Goa", "Udaipur"]:
    place = by_name[name]
    assert len(place["popularHotels"]) == 3
    assert len(place["popularFoodSpots"]) == 2
    assert len(place["topAttractions"]) == 4
    assert all(place.get(key) for key in ["state", "bestTimeToVisit", "nearestAirport", "nearestRailwayStation"])
for place in catalog:
    if place["name"] not in ["Goa", "Udaipur"]:
        assert "latitude" not in place and "popularHotels" not in place
print("PASS: 54 unique places, 12 categories, 60 memberships, aliases and supplied Goa/Udaipur details.")
print("Travel fact verification and Android compilation are not covered by this check.")
