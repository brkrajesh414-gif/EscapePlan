# Configure, build and verify EscapePlan

## Android and Firebase

1. Use JDK 17, Gradle 9.3.1, Android SDK platform 36.1 and build-tools 36.0.0.
   The uploaded sources omit the Gradle wrapper launchers/JAR, so CI installs
   Gradle explicitly. Do not substitute an unverified wrapper binary.
2. Register Android package `com.aistudio.tripplanner.kvxwq` in your Firebase
   project. Add the SHA-1/SHA-256 certificates for the debug key, release/upload
   key and Play App Signing key as applicable. Download `google-services.json`
   to `app/`; keep project configuration out of public commits.
3. Enable Firebase Authentication Email/Password and Google providers. Create
   Firestore. Register Play Integrity App Check for release and a debug App Check
   token for development. The callable backend enforces App Check.
4. Enable Maps SDK for Android and Places API (New). Configure a key restricted
   to the app package and signing certificates and to the required APIs. Set
   `MAPS_ANDROID_KEY` and the OAuth **Web** client ID `GOOGLE_WEB_CLIENT_ID` in the
   environment or root `local.properties`. Environment values take precedence.
   These Android configuration values are compiled into the app; the Gemini key
   must only be a backend secret.

## Firebase backend

Use a billing-enabled Firebase project and Node 22. The source uses the default
Functions region (`us-central1`) on both server and Android. If changing region,
change both sides.

From `functions`, run `npm install`, review the resolved dependencies and commit
the resulting lockfile. Run `npm test` and `npm run check`. From the project root,
select the intended project with Firebase CLI (`firebase use --add`), then set
the secret using `firebase functions:secrets:set GEMINI_API_KEY`. Set
`GEMINI_MODEL` to a model available to that project with structured JSON support
when the deployment CLI requests the parameter. No model name is hardcoded.

Deploy only after reviewing configuration and testing:

```sh
firebase deploy --only firestore:rules,firestore:indexes,functions
```

The deployment includes callable generation, recovery, entitlement and purchase
verification, a Pub/Sub Play notification handler and a 15-minute reconciliation
job. The Android client is not pointed at emulators automatically. For emulator
testing, configure Firebase Android SDK emulator endpoints in a debug-only setup
and use registered debug App Check credentials; never disable server checks for
production.

Firestore permits each signed-in user to access only their own validated profile
document. Entitlements, purchase tokens and generation jobs are server-only.
Generation prompts/results and purchase tokens contain account-related data;
configure an appropriate retention policy before production deployment.

## Play products and verification

| Product ID | Play type | App benefit |
| --- | --- | --- |
| `escapeplan_premium_monthly` | Subscription with active base plan/offer | Premium while entitled |
| `escapeplan_premium_annual` | Subscription with active base plan/offer | Premium while entitled |
| `escapeplan_trip_pass` | Consumable one-time product | One additional generation and that trip's PDF |

Enable the Android Publisher API. Grant the Functions runtime service account
the Play Console permissions needed to read purchases, acknowledge subscriptions
and consume products for this app. The backend uses Application Default
Credentials; do not include service-account private keys in Android.

Configure Play real-time developer notifications to the Cloud Pub/Sub topic
`escapeplan-play-events` in the same project. Grant the Google Play notification
publisher the required topic publisher permission. Verify test notifications and
subscription renewal, cancellation, grace period and voided-pass events.

Use a Play internal testing track and licensed testers. Test pending purchases,
repeated verification, interrupted network, account changes, consumed-pass
restore via server entitlement, refunds and stale offline cache. Do not treat
local JSON validation tests as purchase-verification tests.

## Signing and CI

Keep the original app signing identity for an in-place upgrade. A different debug
key will not update an existing installation. Do not uninstall to bypass a key
mismatch if local data must be preserved.

For local release builds, root `keystore.properties` may contain `storeFile`,
`storePassword`, `keyAlias`, `keyPassword`. Missing properties fall back to
`KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` environment values.
The keystore must exist; a release build fails rather than creating a new key.

In GitHub's `release` environment configure these secrets:

- `KEYSTORE_BASE64`: base64 bytes of the upload/signing keystore.
- `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
- `GOOGLE_SERVICES_JSON_BASE64`: base64 bytes of the Firebase Android config.
- `GOOGLE_WEB_CLIENT_ID`, `MAPS_ANDROID_KEY`.

Copy the project, including `.github`, into your repository. No repository branch
was checked out or pushed by this source update. The requested release workflow
is `.github/workflows/build-apk-workflow.yml`; pushing a `v*` tag or manually
running it executes static checks, lint and unit tests before building signed APK
and AAB artifacts. This does not publish to Google Play or deploy Firebase.

Local verification/build commands:

```sh
python3 check_catalog.py
python3 tests/check_migration.py
node --test functions/validation.test.js
gradle --no-daemon :app:lintDebug :app:testDebugUnitTest
gradle --no-daemon :app:assembleRelease :app:bundleRelease
```

After the first successful build, retain exported Room schemas under
`app/schemas`. Test a real v4 installation upgraded to v5 without clearing data,
including favorites, old saved trips, profile writes and new timeline persistence.
Also test root/system back, deep links with missing trips, dark mode, process
recreation, location denial, map attribution, long itineraries/PDF page wrapping
and offline entitlement expiry on devices.

## API references used

- [Typed Compose navigation](https://developer.android.com/guide/navigation/design/type-safety)
- [Firebase Google authentication](https://firebase.google.com/docs/auth/android/google-signin)
- [Callable Functions](https://firebase.google.com/docs/functions/callable)
- [Functions runtime configuration](https://firebase.google.com/docs/functions/manage-functions)
- [Maps Compose](https://developers.google.com/maps/documentation/android-sdk/maps-compose)
- [Play Billing security](https://developer.android.com/google/play/billing/security)
