"""Offline structural checks; NOT a replacement for Gradle compilation/tests."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
JAVA = ROOT / 'app/src/main/java/com/example'

def mask(text):
    return re.sub(r'"""[\s\S]*?"""|"(?:\\.|[^"\\])*"|//[^\n]*|/\*[\s\S]*?\*/',
                  lambda m: ('X' if m[0].startswith('"') else ' ') + ''.join('\n' if c == '\n' else ' ' for c in m[0][1:]), text)

def body(text, start):
    depth = 1
    for i in range(start, len(text)):
        if text[i] == '(':
            depth += 1
        elif text[i] == ')':
            depth -= 1
            if depth == 0:
                return text[start:i]
    raise AssertionError('Unbalanced parentheses')

def parts(text):
    depth = 0
    start = 0
    for i, c in enumerate(text):
        if c in '([{': depth += 1
        elif c in ')]}': depth -= 1
        elif c == ',' and depth == 0:
            yield text[start:i]
            start = i + 1
    yield text[start:]

model = mask((JAVA / 'data/model/TravelModels.kt').read_text())
schemas = {}
for match in re.finditer(r'data class (\w+)\s*\(', model):
    fields = {}
    for field in re.finditer(r'val\s+(\w+)\s*:([\s\S]*?)(?=,\s*val\s|\Z)', body(model, match.end())):
        fields[field[1]] = '=' not in field[2]
    schemas[match[1]] = fields

errors = []
count = 0
files = list((JAVA / 'data/imported').rglob('*.kt'))
files += list((ROOT / 'app/src/test/java/com/example').glob('CatalogMergeTest.kt'))
for path in files:
    text = mask(path.read_text())
    for match in re.finditer(r'\b(' + '|'.join(schemas) + r')\s*\(', text):
        args = list(parts(body(text, match.end())))
        named = [re.match(r'\s*(\w+)\s*=', a) for a in args if a.strip()]
        if not all(named): continue  # Positional arguments require Kotlin compiler.
        supplied = {m[1] for m in named}
        schema = schemas[match[1]]
        missing = {k for k, required in schema.items() if required} - supplied
        unknown = supplied - schema.keys()
        if missing or unknown:
            errors.append(f'{path.relative_to(ROOT)}:{text[:match.start()].count(chr(10))+1} {match[1]} missing={missing} unknown={unknown}')
        count += 1

for error in errors: print(error)
assert not errors, f'{len(errors)} constructor compatibility problems'
assert 'version = 5' in (JAVA / 'data/local/AppDatabase.kt').read_text()
assert 'com.example.data.imported.DestinationsDataSource.destinations' in (JAVA / 'data/datasource/DestinationsDataSource.kt').read_text()
assert not list(ROOT.rglob('*.apk')), 'Do not ship a stale APK as the new build'
print(f'PASS: {count} named constructor calls checked across {len(files)} files.')
print('PASS: catalog connected; Room schema v5 declared; no stale APK packaged.')
print('Gradle build, JUnit execution, and device testing are still required.')
