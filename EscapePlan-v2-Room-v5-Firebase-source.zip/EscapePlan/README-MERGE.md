# EscapePlan 1.1 — merged catalog source

This file records the earlier merge. For the current v2.0 implementation, Room v5,
Firebase configuration and validation status, read `README.md` and `SETUP.md`.

## What changed

Base: EscapePlan-main (3).zip. Additional source: untitled.zip.

- Preserves EscapePlan's screens, original detailed destinations, images, planner,
  saved-trip models, Room schema v4, migrations, and package ID.
- Includes the second export's Kotlin destination catalog: added regions include
  Gujarat, Bihar, Madhya Pradesh, Odisha, West Bengal, Uttarakhand, Northeast
  destinations and Union Territories, plus updates to existing regions.
- Combines catalogs by ID or normalized state + destination name. Existing IDs
  take precedence; aliases preserve lookup of imported IDs. Similar but differently
  named places are not guessed to be identical.
- Adds missing attractions, stays, food, hidden gems, seasons and other list content.
  Existing scalar values take precedence, except blank descriptions/metadata and
  missing coordinates/images. Conflicting travel facts require editorial review.
- Adds missing catalog rows when opening an existing database. Existing rows and
  user content are not overwritten. Existing stored catalog rows are not refreshed;
  the Explore/planner repository uses the merged in-memory catalog.
- Version code 2 / version name 1.1. GitHub workflow specifies Gradle 9.3.1 and SDK
  installation. Debug builds use Android's default debug key, not the absent exported key.
- Adds catalog merge and upgrade regression tests. Robolectric tests target SDK 34.

## Intentionally not merged

The second export's replacement database, login/profile flow, weather services,
new screens and search engine were not ported. They require a separate integration
and migration review. Its nested `_imported_repo` is an incomplete duplicate and is
not compiled. Redundant JSON state lists are not added because the existing app
already has its own state master. No old APK is included as a new build.

## Validation status

`python3 check_catalog.py` passes static named-constructor compatibility and wiring
checks. This is NOT Kotlin compilation or Android runtime validation.

Gradle/JUnit/device tests and APK generation could not run in the editing environment:
no Gradle/Android SDK is installed, and the compiler download timed out. The included
tests and GitHub workflow must pass before this build is considered verified.
Travel facts, costs, ratings and existing verification labels came from the supplied
projects; they were not independently verified or updated from live sources.

## Build the updated APK

1. Copy this folder's contents to the root of your existing GitHub repository,
   including `.github/workflows/build-apk.yml`. Keep private keys out of Git.
2. Run **Actions → Build EscapePlan Android APK → Run workflow**.
3. After tests/build succeed, download **EscapePlan-debug-apk** from the run's artifacts.
4. Extract and test the APK on a device, including old favorites and saved trips.

Alternatively install JDK 17, Gradle 9.3.1 and the required Android SDK locally,
then run `gradle :app:testDebugUnitTest :app:assembleDebug` from this folder.
The exports do not contain a Gradle wrapper JAR/launcher; the workflow uses installed
Gradle explicitly. Android Studio may offer to generate/update the wrapper.

For current AI configuration, follow `SETUP.md`. The v2.0 app calls the secured
Firebase backend; its Gemini key must never be included in the Android build.

## Installation/signing warning

A newly generated debug key may differ from the previously installed app's key.
For an in-place update preserving user data, sign with the SAME original signing
key. Do not uninstall the existing app merely to resolve a signature mismatch:
uninstalling can erase local saved trips. Release signing remains your responsibility.
