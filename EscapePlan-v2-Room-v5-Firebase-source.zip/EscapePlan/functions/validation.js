"use strict";
function validateItinerary(plan) {
  if (!plan || typeof plan.title !== "string" || !plan.title.trim() || plan.title.length > 200 || plan.currency !== "INR") throw new Error("Invalid title/currency");
  if (!Array.isArray(plan.days) || plan.days.length < 1 || plan.days.length > 14) throw new Error("Invalid days");
  plan.days.forEach((day, index) => {
    if (day.day !== index + 1 || typeof day.title !== "string" || day.title.length > 200 || !Array.isArray(day.activities) || day.activities.length < 1 || day.activities.length > 20) throw new Error("Invalid day schedule");
    day.activities.forEach(a => {
      if (typeof a.activity !== "string" || !a.activity.trim() || a.activity.length > 300 || typeof a.notes !== "string" || a.notes.length > 2000 || !/^([01]\d|2[0-3]):[0-5]\d$/.test(a.timeSlot)) throw new Error("Invalid activity");
      if (!Number.isFinite(a.estimatedCost) || a.estimatedCost < 0 || a.estimatedCost > 10000000) throw new Error("Invalid cost");
      if ((a.latitude == null) !== (a.longitude == null)) throw new Error("Incomplete coordinates");
      if (a.latitude != null && (!Number.isFinite(a.latitude) || a.latitude < -90 || a.latitude > 90 || !Number.isFinite(a.longitude) || a.longitude < -180 || a.longitude > 180)) throw new Error("Invalid coordinates");
    });
  });
  return { title: plan.title, currency: plan.currency, days: plan.days.map(day => ({
    day: day.day, title: day.title, activities: day.activities.map(activity => ({
      timeSlot: activity.timeSlot, activity: activity.activity, notes: activity.notes,
      latitude: activity.latitude ?? null, longitude: activity.longitude ?? null, estimatedCost: activity.estimatedCost
    }))
  })) };
}
const responseSchema = {
  type: "OBJECT", required: ["title", "currency", "days"], properties: {
    title: { type: "STRING" }, currency: { type: "STRING", enum: ["INR"] },
    days: { type: "ARRAY", items: { type: "OBJECT", required: ["day", "title", "activities"], properties: {
      day: { type: "INTEGER" }, title: { type: "STRING" },
      activities: { type: "ARRAY", items: { type: "OBJECT", required: ["timeSlot", "activity", "notes", "latitude", "longitude", "estimatedCost"], properties: {
        timeSlot: { type: "STRING" }, activity: { type: "STRING" }, notes: { type: "STRING" },
        latitude: { type: "NUMBER", nullable: true }, longitude: { type: "NUMBER", nullable: true }, estimatedCost: { type: "NUMBER" }
      } } }
    } } }
  }
};
module.exports = { validateItinerary, responseSchema };
