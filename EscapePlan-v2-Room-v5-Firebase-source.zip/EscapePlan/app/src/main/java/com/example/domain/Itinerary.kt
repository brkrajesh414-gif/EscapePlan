package com.example.domain

import kotlinx.serialization.Serializable

@Serializable data class Itinerary(val title: String, val currency: String = "INR", val days: List<PlanDay>)
@Serializable data class PlanDay(val day: Int, val title: String, val activities: List<PlanActivity>)
@Serializable data class PlanActivity(
    val timeSlot: String, val activity: String, val notes: String = "",
    val latitude: Double? = null, val longitude: Double? = null, val estimatedCost: Double = 0.0
)

fun Itinerary.validated(): Itinerary {
    require(title.isNotBlank() && title.length <= 200 && currency == "INR") { "Invalid trip title or currency" }
    require(days.size in 1..14 && days.map { it.day } == (1..days.size).toList()) { "Trip days must be sequential (1–14)." }
    days.forEach { day ->
        require(day.title.length <= 200 && day.activities.size in 1..20) { "Invalid day schedule" }
        day.activities.forEach {
            require(it.activity.isNotBlank() && it.activity.length <= 300 && it.notes.length <= 2000) { "Invalid activity" }
            require(Regex("([01]\\d|2[0-3]):[0-5]\\d").matches(it.timeSlot)) { "Activity time must be HH:mm" }
            require(it.estimatedCost.isFinite() && it.estimatedCost in 0.0..10_000_000.0) { "Invalid activity cost" }
            require((it.latitude == null) == (it.longitude == null)) { "Coordinates must be a complete pair" }
            require(it.latitude == null || it.latitude.isFinite() && it.latitude in -90.0..90.0) { "Invalid latitude" }
            require(it.longitude == null || it.longitude.isFinite() && it.longitude in -180.0..180.0) { "Invalid longitude" }
        }
    }
    return this
}
