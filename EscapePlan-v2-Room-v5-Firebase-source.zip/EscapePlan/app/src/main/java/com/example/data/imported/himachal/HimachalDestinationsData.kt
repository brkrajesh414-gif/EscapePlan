package com.example.data.imported.himachal

import com.example.data.imported.common.RegionalSeasonalHelper
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.DiscoveryLevel
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.HiddenGem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo
import com.example.data.model.VerificationLevel

object HimachalDestinationsData {

    val manali = Destination(
        id = "himachal-manali",
        name = "Manali & Solang Valley",
        state = "Himachal Pradesh",
        stateCode = "HP",
        district = "Kullu",
        latitude = 32.2432,
        longitude = 77.1892,
        tagline = "Himalayan adventure haven amidst deodar forests and snow-crowned summits",
        description = "Manali sits at 2,050 meters along the Beas River. Gateway to Solang Valley, Atal Tunnel, and Ladakh, it offers paragliding, snow activities, apple orchards, wooden Himachali temples, and tranquil forest treks.",
        shortDescription = "Himalayan resort town famous for snow valleys and river adventures",
        bestDurationMinDays = 3,
        bestDurationMaxDays = 5,
        altitude = "2,050 m",
        destinationTypes = listOf("Himalayas", "Snow", "Adventure", "Hill Station", "Rivers", "Trekking"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "March to June & October to February (for Snow)",
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.ADVENTURE, TravelCategory.NATURE),
        verificationLevel = VerificationLevel.TRUSTED,
        attractions = listOf(
            Attraction(
                id = "solang-valley-manali",
                destinationId = "himachal-manali",
                name = "Solang Valley Snow Point",
                description = "Side valley renowned for adventure sports including skiing, paragliding, zorbing, and cable car rides.",
                category = "Adventure / Snow",
                latitude = 32.3166,
                longitude = 77.1578,
                recommendedDurationMinutes = 180,
                familyFriendly = true,
                photographyAllowed = true
            ),
            Attraction(
                id = "hadimba-temple-manali",
                destinationId = "himachal-manali",
                name = "Hidimba Devi Temple",
                description = "Unique 16th-century pagoda-style wooden temple built around a natural cave sanctuary inside towering deodar pine forest.",
                category = "Temple / Heritage",
                latitude = 32.2483,
                longitude = 77.1812,
                entryFeeAdult = "Free",
                recommendedDurationMinutes = 60,
                familyFriendly = true,
                photographyAllowed = true
            ),
            Attraction(
                id = "atal-tunnel-sissu",
                destinationId = "himachal-manali",
                name = "Atal Tunnel & Sissu Waterfall (Lahaul)",
                description = "Engineering marvel cutting 9.02 km through the Pir Panjal mountain into the barren, snow-capped Tibetan landscape of Lahaul Valley and Sissu waterfall.",
                category = "Mountain Pass / Wonder",
                latitude = 32.4930,
                longitude = 77.1265,
                recommendedDurationMinutes = 120
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-jogini-waterfall-manali",
                destinationId = "himachal-manali",
                name = "Jogini Waterfall & Vashisht Pine Trail",
                description = "Cascading mountain waterfall flowing through sacred deodar groves, reached via a quiet cliff trek from Vashisht village.",
                whyItIsSpecial = "Secluded natural pools and panoramic views of snow peaks, far quieter than the town center.",
                category = "Hidden Waterfall",
                location = "Vashisht, Manali",
                latitude = 32.2610,
                longitude = 77.1950,
                crowdLevel = "Low to Moderate"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Siddu with Ghee & Walnut Chutney",
                    isVegetarian = true,
                    description = "Steamed fermented wheat bun stuffed with crushed spiced poppy seeds or walnuts, dipped in hot clarified mountain butter.",
                    popularAt = "Old Manali Cafes",
                    priceRange = "₹120 - ₹180"
                ),
                FoodItem(
                    name = "Trout Fish Fry",
                    isVegetarian = false,
                    description = "Fresh Himalayan brown or rainbow trout caught from cold glacier streams, lightly spiced and butter-pan-fried.",
                    popularAt = "Johnson's Cafe",
                    priceRange = "₹400 - ₹700"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Delhi" to 540, "Chandigarh" to 310, "Shimla" to 250),
            drivingTimes = mapOf("Delhi" to "11 Hours", "Chandigarh" to "7.5 Hours"),
            roadTripRoute = "NH 21 through Kiratpur -> Mandi -> Kullu -> Manali with four-lane highway stretches.",
            nearestRailwayStation = "Joginder Nagar (Narrow gauge - 145 km) / Chandigarh (Broad gauge - 310 km)",
            nearestAirport = "Bhuntar Airport (KUU - 50 km)"
        ),
        seasons = RegionalSeasonalHelper.createHighAltitudeSeasons("himachal-manali")
    )

    val shimla = Destination(
        id = "himachal-shimla",
        name = "Shimla & Kufri",
        state = "Himachal Pradesh",
        stateCode = "HP",
        district = "Shimla",
        latitude = 31.1048,
        longitude = 77.1734,
        tagline = "The Queen of Hills with neo-Gothic colonial architecture and pine-draped Himalayan ridges",
        description = "Perched at 2,276 meters, Shimla was the summer capital of British India. Famous for the pedestrian Mall Road, historic Ridge, Christ Church, the UNESCO Kalka-Shimla Toy Train, and snowy slopes of Kufri.",
        shortDescription = "Colonial Himalayan capital famed for Mall Road, Toy Train, and cedar slopes",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 4,
        altitude = "2,276 m",
        destinationTypes = listOf("Himalayas", "Hill Station", "Colonial Heritage", "Toy Train", "Snow"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "March to June & December to February (Snow)",
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.FAMILY, TravelCategory.HERITAGE),
        verificationLevel = VerificationLevel.TRUSTED,
        attractions = listOf(
            Attraction(
                id = "the-ridge-shimla",
                destinationId = "himachal-shimla",
                name = "The Ridge & Christ Church",
                description = "Expansive open pedestrian terrace in the heart of Shimla offering panoramic vistas of the snow-clad Dhauladhar range and the yellow neo-Gothic Christ Church built in 1857.",
                category = "Colonial Landmark",
                latitude = 31.1052,
                longitude = 77.1751,
                entryFeeAdult = "Free",
                recommendedDurationMinutes = 90
            ),
            Attraction(
                id = "jakhu-temple-shimla",
                destinationId = "himachal-shimla",
                name = "Jakhu Temple & Giant Hanuman Statue",
                description = "Highest point in Shimla at 2,455m featuring a 108-foot colossal vermilion statue of Lord Hanuman overlooking Himalayan valleys.",
                category = "Temple / Viewpoint",
                latitude = 31.1008,
                longitude = 77.1852,
                entryFeeAdult = "Free (Ropeway ₹500 return)",
                recommendedDurationMinutes = 90
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-mashobra-craignano",
                destinationId = "himachal-shimla",
                name = "Craignano Nature Park, Mashobra",
                description = "Quiet Italian-style country estate with sprawling oak groves, wild apple trees, and quiet cycling trails away from crowded Shimla.",
                whyItIsSpecial = "Completely peaceful Himalayan forest retreat with ancient pine aromas.",
                category = "Nature Park / Offbeat Hill",
                location = "Mashobra, 14 km from Shimla",
                latitude = 31.1320,
                longitude = 77.2280,
                crowdLevel = "Low"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Himachali Dhaam (Chana Madra & Babru)",
                    isVegetarian = true,
                    description = "Festive feast cooked in bronze vessels featuring white chickpeas simmered in rich spiced yogurt and puffed whole-wheat kachoris.",
                    popularAt = "Himachali Rasoi, Mall Road",
                    priceRange = "₹200 - ₹350"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Chandigarh" to 115, "Delhi" to 345, "Amritsar" to 330),
            drivingTimes = mapOf("Chandigarh" to "3.5 Hours via Himalayan Expressway", "Delhi" to "7 Hours"),
            roadTripRoute = "NH 5 four-lane expressway from Chandigarh to Parwanoo and Solan up to Shimla bypass.",
            nearestRailwayStation = "Shimla Railway Station (Toy Train) / Kalka (Broad gauge - 88 km)",
            nearestAirport = "Jubarhati Airport (SLV - 22 km)"
        ),
        seasons = RegionalSeasonalHelper.createHighAltitudeSeasons("himachal-shimla")
    )

    val dharamshala = Destination(
        id = "himachal-dharamshala",
        name = "Dharamshala & McLeod Ganj",
        state = "Himachal Pradesh",
        stateCode = "HP",
        district = "Kangra",
        latitude = 32.2190,
        longitude = 76.3234,
        tagline = "Home of the Dalai Lama, Tibetan spirituality, and soaring pine-clad Dhauladhar cliffs",
        description = "Surrounded by cedar forests and shadowed by the dramatic rock walls of the Dhauladhar Range, Dharamshala and its upper cantonment McLeod Ganj are the headquarters of the Central Tibetan Administration and His Holiness the Dalai Lama.",
        shortDescription = "Little Lhasa nestled against dramatic snowy Dhauladhar granite peaks",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 4,
        altitude = "1,457 m - 2,082 m",
        destinationTypes = listOf("Himalayas", "Tibetan Culture", "Spirituality", "Trekking", "Cafes"),
        discoveryLevel = DiscoveryLevel.POPULAR,
        bestMonths = "March to June & September to November",
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.SPIRITUAL, TravelCategory.ADVENTURE),
        verificationLevel = VerificationLevel.TRUSTED,
        attractions = listOf(
            Attraction(
                id = "tsuglagkhang-dalai-lama-temple",
                destinationId = "himachal-dharamshala",
                name = "Tsuglagkhang Complex (Dalai Lama Temple)",
                description = "Spiritual hub housing the monastery of the Dalai Lama, Namgyal monks, prayer wheels, and serene Buddhist shrines.",
                category = "Monastery / Spiritual",
                latitude = 32.2355,
                longitude = 76.3255,
                entryFeeAdult = "Free",
                recommendedDurationMinutes = 90
            ),
            Attraction(
                id = "triund-trek",
                destinationId = "himachal-dharamshala",
                name = "Triund Ridge Trek",
                description = "Iconic 9 km trail through rhododendron and oak forest leading to an elevated ridge right beneath the sheer rock wall of the Dhauladhar peaks.",
                category = "Trekking / Mountain Ridge",
                latitude = 32.2570,
                longitude = 76.3530,
                recommendedDurationMinutes = 360
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-norbulingka-institute",
                destinationId = "himachal-dharamshala",
                name = "Norbulingka Institute of Tibetan Arts",
                description = "Traditional Japanese-style water gardens and pavilions dedicated to preserving Tibetan thangka painting, wood carving, and statue making.",
                whyItIsSpecial = "Peaceful sanctuary with koi fish streams, bamboo bridges, and working Tibetan master artisans.",
                category = "Cultural Sanctuary",
                location = "Sidhhpur, Dharamshala",
                latitude = 32.1850,
                longitude = 76.3550,
                crowdLevel = "Low"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Tibetan Momos, Thukpa & Tingmo",
                    isVegetarian = true,
                    description = "Hand-rolled steamed buns and noodle soup with herbs, greens, and fiery mountain chili chutney.",
                    popularAt = "Tibet Kitchen & Peace Cafe, McLeod Ganj",
                    priceRange = "₹100 - ₹250"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Chandigarh" to 240, "Delhi" to 475, "Amritsar" to 205),
            drivingTimes = mapOf("Chandigarh" to "5.5 Hours", "Amritsar" to "4.5 Hours"),
            roadTripRoute = "NH 503 through Kangra Valley directly reaching Dharamshala.",
            nearestRailwayStation = "Pathankot Junction (PTK - 85 km)",
            nearestAirport = "Gaggal Kangra Airport (DHM - 14 km)"
        ),
        seasons = RegionalSeasonalHelper.createHighAltitudeSeasons("himachal-dharamshala")
    )

    val destinations: List<Destination> = listOf(manali, shimla, dharamshala)
}
