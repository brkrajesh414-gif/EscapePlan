package com.example.data.repository

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.example.core.operation
import com.example.data.auth.EncryptedSessionStore
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import java.security.MessageDigest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable private data class EntitlementCache(val uid: String, val cachedAt: Long, val premiumUntil: Long,
    val credits: Int, val unlockedTrips: Set<String>)

data class BillingState(val products: List<ProductDetails> = emptyList(), val premiumUntil: Long = 0,
    val credits: Int = 0, val unlockedTrips: Set<String> = emptySet(), val error: String? = null, val loading: Boolean = false) {
    val premium: Boolean get() = premiumUntil > System.currentTimeMillis()
    fun canExport(tripId: String): Boolean = premium || tripId in unlockedTrips
}

class BillingRepository(context: Context, private val scope: CoroutineScope) {
    private val cache = EncryptedSessionStore(context.applicationContext)
    private val mutable = MutableStateFlow(BillingState())
    val state = mutable.asStateFlow()
    private val client = BillingClient.newBuilder(context.applicationContext)
        .setListener { result, purchases ->
            when (result.responseCode) {
                BillingClient.BillingResponseCode.OK -> purchases.orEmpty().forEach(::verify)
                BillingClient.BillingResponseCode.USER_CANCELED -> mutable.update { it.copy(loading = false) }
                else -> mutable.update { it.copy(loading = false, error = result.debugMessage) }
            }
        }
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .enableAutoServiceReconnection().build()
    private var observedUid: String? = null

    fun accountChanged(uid: String?) {
        observedUid = uid
        mutable.update { BillingState(products = it.products) }
        if (uid != null) scope.launch {
            val cached = operation { cache.read("billing_$uid")?.let { Json.decodeFromString<EntitlementCache>(it) } }.getOrNull()
            if (cached != null && observedUid == uid && cached.uid == uid && System.currentTimeMillis() - cached.cachedAt in 0..86_400_000L) {
                mutable.update { it.copy(premiumUntil = minOf(cached.premiumUntil, cached.cachedAt + 86_400_000L), credits = cached.credits, unlockedTrips = cached.unlockedTrips) }
            }
            if (observedUid == uid) refresh()
        }
    }

    fun connect() {
        if (client.isReady) { loadProducts(); return }
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) loadProducts()
                else mutable.update { it.copy(error = result.debugMessage, loading = false) }
            }
            override fun onBillingServiceDisconnected() { mutable.update { it.copy(error = "Play Billing disconnected. Retry when online.", loading = false) } }
        })
    }

    private fun loadProducts() {
        listOf(BillingClient.ProductType.SUBS to listOf("escapeplan_premium_monthly", "escapeplan_premium_annual"),
            BillingClient.ProductType.INAPP to listOf("escapeplan_trip_pass")).forEach { (type, ids) ->
            val params = QueryProductDetailsParams.newBuilder().setProductList(ids.map { id ->
                QueryProductDetailsParams.Product.newBuilder().setProductId(id).setProductType(type).build()
            }).build()
            client.queryProductDetailsAsync(params) { result, details ->
                mutable.update { current ->
                    if (result.responseCode == BillingClient.BillingResponseCode.OK)
                        current.copy(products = (current.products.filterNot { it.productId in ids } + details.productDetailsList).distinctBy { it.productId })
                    else current.copy(error = result.debugMessage)
                }
            }
        }
    }

    fun buy(activity: Activity, product: ProductDetails) {
        val uid = runCatching { FirebaseAuth.getInstance().currentUser?.uid }.getOrNull()
        if (uid == null) { mutable.update { it.copy(error = "Sign in before purchasing.") }; return }
        if (!client.isReady) { connect(); mutable.update { it.copy(error = "Connecting to Play Billing. Please retry.") }; return }
        val detail = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(product)
        if (product.productType == BillingClient.ProductType.SUBS) {
            val offer = product.subscriptionOfferDetails?.firstOrNull { it.offerId == null }
                ?: product.subscriptionOfferDetails?.firstOrNull()
            if (offer == null) { mutable.update { it.copy(error = "No eligible subscription offer.") }; return }
            detail.setOfferToken(offer.offerToken)
        }
        val account = MessageDigest.getInstance("SHA-256").digest(uid.toByteArray()).joinToString("") { "%02x".format(it) }
        val result = client.launchBillingFlow(activity, BillingFlowParams.newBuilder()
            .setObfuscatedAccountId(account).setProductDetailsParamsList(listOf(detail.build())).build())
        if (result.responseCode != BillingClient.BillingResponseCode.OK) mutable.update { it.copy(error = result.debugMessage) }
    }

    private fun verify(purchase: Purchase) {
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) {
            mutable.update { it.copy(error = "Purchase is pending. Premium access starts after payment completes.", loading = false) }
            return
        }
        val uid = observedUid ?: return
        scope.launch {
            mutable.update { it.copy(loading = true, error = null) }
            val result = operation {
                val product = purchase.products.singleOrNull() ?: error("Unsupported purchase contents")
                FirebaseFunctions.getInstance().getHttpsCallable("verifyPurchase").call(mapOf(
                    "productId" to product, "purchaseToken" to purchase.purchaseToken
                )).await().data
            }
            if (observedUid == uid) result.fold(::accept, { error -> mutable.update { it.copy(loading = false, error = error.message ?: "Verification failed") } })
        }
    }

    private fun accept(data: Any?) {
        val fields = data as? Map<*, *> ?: run { mutable.update { it.copy(error = "Invalid entitlement response", loading = false) }; return }
        mutable.update { it.copy(premiumUntil = (fields["premiumUntil"] as? Number)?.toLong() ?: 0,
            credits = (fields["credits"] as? Number)?.toInt() ?: 0,
            unlockedTrips = (fields["unlockedTrips"] as? List<*>)?.filterIsInstance<String>()?.toSet().orEmpty(), error = null, loading = false) }
        val uid = observedUid ?: return
        val snapshot = mutable.value
        scope.launch {
            operation { cache.save("billing_$uid", Json.encodeToString(EntitlementCache(uid, System.currentTimeMillis(), snapshot.premiumUntil, snapshot.credits, snapshot.unlockedTrips))) }
                .onFailure { error -> if (observedUid == uid) mutable.update { it.copy(error = "Offline entitlement cache unavailable: ${error.message}") } }
        }
    }

    fun refresh() {
        val uid = observedUid ?: return
        scope.launch {
            val result = operation { FirebaseFunctions.getInstance().getHttpsCallable("getEntitlement").call().await().data }
            if (uid == observedUid) result.fold(::accept, { error -> mutable.update { it.copy(error = error.message, loading = false) } })
        }
    }
    fun restore() {
        if (!client.isReady) { connect(); return }
        for (type in listOf(BillingClient.ProductType.SUBS, BillingClient.ProductType.INAPP)) {
            client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(type).build()) { result, purchases ->
                if (result.responseCode == BillingClient.BillingResponseCode.OK) purchases.forEach(::verify)
                else mutable.update { it.copy(error = result.debugMessage) }
            }
        }
        refresh()
    }
    fun close() { client.endConnection() }
}
