package com.example.data.imported.tamilnadu

import com.example.data.model.*

object TamilNaduHillsNatureData {

    val ooty = Destination(
        id = "tamilnadu-ooty",
        name = "Ooty (Udhagamandalam)",
        state = "Tamil Nadu",
        district = "The Nilgiris",
        tagline = "The Queen of Hill Stations & Nilgiri Mountain Toy Train",
        description = "Perched at 2,240 meters amidst the Blue Mountains (Nilgiris), Ooty was established as the summer capital of the Madras Presidency. Renowned for the UNESCO-inscribed Nilgiri Mountain Railway steam toy train, century-old Government Botanical Garden, Ooty Lake, Doddabetta Peak, and eucalyptus and tea plantations.",
        bestDurationMinDays = 3,
        bestDurationMaxDays = 4,
        altitude = "2,240 m",
        destinationTypes = listOf("Hill Station", "Nature", "Heritage", "Tea Gardens"),
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.FAMILY, TravelCategory.COUPLES, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.8f,
        reviewCount = 24600,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Coimbatore" to 85, "Bengaluru" to 275, "Mysuru" to 125, "Chennai" to 540),
            drivingTimes = mapOf("Coimbatore" to "2h 45m via Coonoor ghat", "Mysuru" to "3h 30m via Bandipur", "Bengaluru" to "6h via Expressway"),
            roadTripRoute = "From Bengaluru/Mysuru via NH766 through Bandipur/Mudumalai Tiger Reserves ascending Kalhatty ghat.",
            nearestRailwayStation = "Udhagamandalam (Ooty) / Mettupalayam (52 km)",
            nearestAirport = "Coimbatore International Airport (CJB - 88 km)"
        ),
        budget = BudgetBreakdown(4200, 1200, 800, 2000, 12000, 30000)
    )

    val coonoor = Destination(
        id = "tamilnadu-coonoor",
        name = "Coonoor",
        state = "Tamil Nadu",
        district = "The Nilgiris",
        tagline = "Lush Tea Valleys, Sim's Park & Catherine Falls",
        description = "Quieter and more relaxed than Ooty, Coonoor is surrounded by sprawling tea estates, colonial bungalows, and dramatic gorges including Dolphin's Nose and Lamb's Rock.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "1,850 m",
        destinationTypes = listOf("Hill Station", "Tea Gardens", "Nature"),
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.COUPLES, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.7f,
        reviewCount = 12400,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Coimbatore" to 70, "Ooty" to 19, "Bengaluru" to 285),
            drivingTimes = mapOf("Coimbatore" to "2h 15m", "Ooty" to "45m"),
            roadTripRoute = "NH181 from Coimbatore via Mettupalayam through lush mountain twists.",
            nearestRailwayStation = "Coonoor Railway Station (Toy Train stop)",
            nearestAirport = "Coimbatore International Airport (70 km)"
        ),
        budget = BudgetBreakdown(3500, 1000, 600, 1500, 9000, 22000)
    )

    val kotagiri = Destination(
        id = "tamilnadu-kotagiri",
        name = "Kotagiri",
        state = "Tamil Nadu",
        district = "The Nilgiris",
        tagline = "Original British Nilgiri Retreat & Catherine Falls Trek",
        description = "The oldest of the three Nilgiri hill stations, Kotagiri offers uninterrupted silence, year-round pleasant weather, Kodanad viewpoint overlooking the Moyar river valley, and Catherine Falls.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "1,793 m",
        destinationTypes = listOf("Hill Station", "Quiet Getaway", "Nature"),
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.6f,
        reviewCount = 8200
    )

    val kodaikanal = Destination(
        id = "tamilnadu-kodaikanal",
        name = "Kodaikanal",
        state = "Tamil Nadu",
        district = "Dindigul",
        tagline = "The Princess of Hill Stations & Shola Forests",
        description = "Set around a star-shaped lake in the Palani Hills, Kodaikanal boasts mist-covered cliffs, Pine Forests, Pillar Rocks, Bryant Park, and Kurinji flowers that bloom once every 12 years.",
        bestDurationMinDays = 3,
        bestDurationMaxDays = 4,
        altitude = "2,133 m",
        destinationTypes = listOf("Hill Station", "Lakes", "Romance", "Forest"),
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.COUPLES, TravelCategory.FAMILY, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.8f,
        reviewCount = 31200,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Madurai" to 115, "Coimbatore" to 175, "Bengaluru" to 465, "Chennai" to 525),
            drivingTimes = mapOf("Madurai" to "3h", "Coimbatore" to "4h 30m"),
            roadTripRoute = "Via NH83 from Dindigul through Batlagundu and Ghat road.",
            nearestRailwayStation = "Kodai Road (80 km)",
            nearestAirport = "Madurai Airport (120 km)"
        )
    )

    val yercaud = Destination(
        id = "tamilnadu-yercaud",
        name = "Yercaud",
        state = "Tamil Nadu",
        district = "Salem",
        tagline = "Jewel of the Shevaroy Hills & Coffee Country",
        description = "An accessible and serene hill getaway in the Eastern Ghats known for Emerald Lake, Lady's Seat viewpoint, extensive coffee plantations, and 20 hairpin bend scenic drive from Salem.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "1,515 m",
        destinationTypes = listOf("Hill Station", "Lake", "Budget Mountain"),
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.WEEKEND_GETAWAYS, TravelCategory.FAMILY),
        rating = 4.5f,
        reviewCount = 14500
    )

    val yelagiri = Destination(
        id = "tamilnadu-yelagiri",
        name = "Yelagiri",
        state = "Tamil Nadu",
        district = "Tirupattur",
        tagline = "Serene Hillocks, Punganoor Lake & Swamimalai Trek",
        description = "A cluster of 14 tribal hamlets nestled among four mountains, featuring fruit orchards, rose gardens, boating lake, and paragliding hotspots midway between Chennai and Bengaluru.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 2,
        altitude = "1,110 m",
        destinationTypes = listOf("Hill Station", "Adventure", "Weekend Getaway"),
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.WEEKEND_GETAWAYS, TravelCategory.ADVENTURE),
        rating = 4.4f,
        reviewCount = 9800
    )

    val kolliHills = Destination(
        id = "tamilnadu-kolli-hills",
        name = "Kolli Hills (Kolli Malai)",
        state = "Tamil Nadu",
        district = "Namakkal",
        tagline = "Mountains of Death, 70 Hairpin Bends & Agaya Gangai Falls",
        description = "An untouched Eastern Ghats paradise renowned for its thrilling 70 continuous hairpin bends, medicinal herbs, Arapaleeswarar temple, and 300-ft roaring Agaya Gangai waterfall.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "1,300 m",
        destinationTypes = listOf("Adventure", "Waterfalls", "Hairpin Bends"),
        categories = listOf(TravelCategory.ADVENTURE, TravelCategory.MOUNTAINS, TravelCategory.OFFBEAT),
        rating = 4.6f,
        reviewCount = 7600
    )

    val valparai = Destination(
        id = "tamilnadu-valparai",
        name = "Valparai",
        state = "Tamil Nadu",
        district = "Coimbatore",
        tagline = "40 Hairpin Bends, Anamalai Tea Carpets & Lion-tailed Macaques",
        description = "Surrounded by Anamalai Tiger Reserve, Valparai is a high-altitude sanctuary enveloped in mist and rainforests, home to rare wildlife, dams, and tea gardens.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "1,193 m",
        destinationTypes = listOf("Wildlife", "Tea Gardens", "Scenic Drive"),
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.MOUNTAINS, TravelCategory.OFFBEAT),
        rating = 4.7f,
        reviewCount = 11200
    )

    val pollachi = Destination(
        id = "tamilnadu-pollachi",
        name = "Pollachi",
        state = "Tamil Nadu",
        district = "Coimbatore",
        tagline = "Gateway to Anamalai Tiger Reserve & Coconut Groves",
        description = "A picturesque town bordered by coconut plantations, jaggery markets, and Western Ghats wildlife corridors including Topslip and Parambikulam.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        destinationTypes = listOf("Nature", "Rural", "Wildlife"),
        categories = listOf(TravelCategory.NATURE, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.5f,
        reviewCount = 8900
    )

    val mudumalai = Destination(
        id = "tamilnadu-mudumalai",
        name = "Mudumalai National Park & Tiger Reserve",
        state = "Tamil Nadu",
        district = "The Nilgiris",
        tagline = "Elephant Whisperers Land & Nilgiri Biosphere Wildlife",
        description = "Part of the UNESCO Nilgiri Biosphere Reserve, Mudumalai features open savanna woodlands, elephant camps at Theppakadu, and healthy populations of tigers, leopards, and gaurs.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        destinationTypes = listOf("Wildlife", "Safari", "Tiger Reserve"),
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.NATURE, TravelCategory.ADVENTURE),
        rating = 4.7f,
        reviewCount = 16800
    )

    val meghamalai = Destination(
        id = "tamilnadu-meghamalai",
        name = "Meghamalai (Highwavys)",
        state = "Tamil Nadu",
        district = "Theni",
        tagline = "The High Waves: Cloud-Wrapped Cardamom & Tea Mountains",
        description = "A pristine, eco-sensitive mountain range known for elephant corridors, emerald tea gardens, Suruli Falls, and breathtaking cloud formations.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "1,500 m",
        destinationTypes = listOf("Offbeat Hill Station", "Wildlife", "Tea & Cardamom"),
        categories = listOf(TravelCategory.OFFBEAT, TravelCategory.MOUNTAINS, TravelCategory.NATURE),
        rating = 4.6f,
        reviewCount = 5400
    )

    val hogenakkal = Destination(
        id = "tamilnadu-hogenakkal",
        name = "Hogenakkal Falls",
        state = "Tamil Nadu",
        district = "Dharmapuri",
        tagline = "The Niagara of India: Coracle Rides & Carbonatite Rocks",
        description = "Spectacular tiered waterfalls on the Kaveri river where ancient carbonatite rocks meet swirling waters, famous for coracle boat rides and therapeutic herbal massages.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Waterfalls", "Boating", "River"),
        categories = listOf(TravelCategory.WATERFALLS, TravelCategory.FAMILY, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.6f,
        reviewCount = 19400
    )

    val courtallam = Destination(
        id = "tamilnadu-courtallam",
        name = "Courtallam (Kutralam)",
        state = "Tamil Nadu",
        district = "Tenkasi",
        tagline = "The Spa of South India: Nine Medicinal Herbal Waterfalls",
        description = "Famed for its nine cascading waterfalls infused with medicinal Western Ghats herbs, where thousands gather during the monsoon for rejuvenating natural baths.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        destinationTypes = listOf("Waterfalls", "Ayurvedic Bath", "Monsoon"),
        categories = listOf(TravelCategory.WATERFALLS, TravelCategory.HERITAGE, TravelCategory.FAMILY),
        rating = 4.6f,
        reviewCount = 15200
    )

    val allHillsNatureDestinations: List<Destination> = listOf(
        ooty, coonoor, kotagiri, kodaikanal, yercaud,
        yelagiri, kolliHills, valparai, pollachi,
        mudumalai, meghamalai, hogenakkal, courtallam
    )
}
