package com.example.data.imported.unionterritories

import com.example.data.imported.common.RegionalSeasonalHelper
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.DiscoveryLevel
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.HiddenGem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo

object UnionTerritoriesDestinationsData {

    val ladakh = Destination(
        id = "ut-ladakh",
        name = "Ladakh (Leh, Pangong & Nubra)",
        state = "Ladakh",
        stateCode = "LA",
        district = "Leh",
        latitude = 34.1526,
        longitude = 77.5771,
        tagline = "Land of High Passes: surreal azure Pangong Tso, Hunder double-humped camel sand dunes, and cliffside gompas",
        description = "A high-altitude desert plateau situated between 3,000 and 5,300 meters above sea level, Ladakh is renowned for the dramatically color-changing saline lake Pangong Tso, Nubra Valley's cold desert sand dunes with Bactrian camels, cliffside monasteries like Thiksey and Hemis, and the world's highest motorable passes like Khardung La.",
        shortDescription = "High-altitude Himalayan desert with turquoise glacial lakes and Tibetan monasteries",
        bestDurationMinDays = 5,
        bestDurationMaxDays = 8,
        altitude = "3,500 m – 5,350 m",
        destinationTypes = listOf("High Altitude Desert", "Glacial Lakes", "Passes", "Monasteries", "Biking"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "May to September (Roads open via Manali & Srinagar, comfortable temperatures)",
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.ADVENTURE, TravelCategory.LAKES),
        attractions = listOf(
            Attraction(
                id = "pangong-tso-ladakh",
                destinationId = "ut-ladakh",
                name = "Pangong Tso High-Altitude Salt Lake (4,225 m)",
                description = "World's highest saltwater lake extending 134 km from India into Tibet, known for shifting shades from turquoise green to royal indigo under passing clouds.",
                category = "Alpine Salt Lake",
                latitude = 33.7595,
                longitude = 78.6674,
                entryFeeAdult = "Inner Line Permit (ILP) required (₹400 per person + Wildlife fee)",
                recommendedDurationMinutes = 240,
                familyFriendly = true,
                insiderTip = "Stay overnight in eco-cottages at Spangmik to witness the starry Milky Way over the lake; temperatures drop near freezing even in summer."
            ),
            Attraction(
                id = "nubra-valley-hunder",
                destinationId = "ut-ladakh",
                name = "Nubra Valley & Hunder Sand Dunes (Diskit)",
                description = "Dramatic high-altitude sand dunes framed by snow peaks where rare double-humped Bactrian camels roam along the Shyok River.",
                category = "Cold Desert & Sand Dunes",
                latitude = 34.5800,
                longitude = 77.4700,
                entryFeeAdult = "Camel safari ₹350 - ₹500 for 15 mins",
                recommendedDurationMinutes = 180,
                familyFriendly = true,
                insiderTip = "Visit the monumental 106-foot Maitreya Buddha statue at Diskit Monastery facing the Shyok river at sunset."
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-tso-moriri-lake",
                destinationId = "ut-ladakh",
                name = "Tso Moriri High-Altitude Wetland Reserve (4,522 m)",
                description = "Vast, tranquil, crystal-clear sapphire lake in Changthang plateau, breeding ground for rare Black-Necked Cranes and Bar-Headed Geese.",
                whyItIsSpecial = "Far less tourist traffic than Pangong, offering raw untouched wilderness and Changpa nomadic pastoral life.",
                category = "Ramsar High-Altitude Lake",
                location = "Changthang, 220 km from Leh",
                latitude = 32.8986,
                longitude = 78.3094,
                entryFee = "ILP permit required",
                crowdLevel = "Low",
                difficulty = "High altitude acclimatization mandatory"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Ladakhi Skyu & Butter Tea (Gur Gur Chai)",
                    isVegetarian = true,
                    description = "Traditional slow-cooked thumb-pressed wheat pasta stew with root vegetables, accompanied by salted yak butter tea.",
                    popularAt = "The Tibetan Kitchen in Leh & Local Homestays",
                    priceRange = "₹150 - ₹280"
                )
            )
        ),
        stays = listOf(
            Accommodation(
                id = "stay-leh-resort",
                name = "The Grand Dragon Ladakh",
                category = "Luxury Solar Heated Hotel",
                pricePerNight = 8500,
                rating = 4.8f,
                amenities = listOf("Oxygen Enriched Rooms", "Solar Heating", "Mountain Views", "Multi-Cuisine Dining")
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Srinagar" to 420, "Manali" to 430, "Delhi" to 950),
            drivingTimes = mapOf("Srinagar" to "14 Hours (overnight halt in Kargil recommended)", "Manali" to "14 Hours (overnight in Sarchu/Jispa)"),
            roadTripRoute = "Manali-Leh Highway (Atal Tunnel -> Jispa -> Baralacha La -> Sarchu -> Tanglang La -> Leh) OR Srinagar-Leh Highway (Sonamarg -> Zoji La -> Drass -> Kargil -> Leh).",
            nearestRailwayStation = "Jammu Tawi (JAT - 680 km) / Chandigarh (CDG - 720 km)",
            nearestAirport = "Kushok Bakula Rimpochee Airport, Leh (IXL - direct daily flights from Delhi, Mumbai)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 3500,
            foodEstimatePerDay = 1000,
            activitiesTotal = 2500,
            travelEstimate = 4500,
            totalEstimateMin = 11500,
            totalEstimateMax = 28000
        ),
        seasons = RegionalSeasonalHelper.createHighAltitudeSeasons("ut-ladakh")
    )

    val andaman = Destination(
        id = "ut-andaman",
        name = "Andaman & Nicobar (Havelock & Neil)",
        state = "Andaman and Nicobar Islands",
        stateCode = "AN",
        district = "South Andaman",
        latitude = 11.9761,
        longitude = 92.9876,
        tagline = "Tropical Island Paradise: Radhanagar Blue Flag beach, bioluminescence, and world-class scuba diving",
        description = "Archipelago of over 500 emerald islands in the Bay of Bengal, celebrated for Radhanagar Beach on Havelock Island (consistently rated among Asia's best beaches), vibrant coral reefs at Elephant Beach and Neil Island, historical Cellular Jail in Port Blair, and night kayaking under bioluminescent waters.",
        shortDescription = "Tropical archipelago with world-renowned Blue Flag beaches and scuba diving",
        bestDurationMinDays = 4,
        bestDurationMaxDays = 7,
        altitude = "Sea level",
        destinationTypes = listOf("Islands", "Beaches", "Scuba Diving", "Marine Life", "History"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "October to May (Calm seas, crystal underwater visibility)",
        categories = listOf(TravelCategory.BEACHES, TravelCategory.ADVENTURE, TravelCategory.NATURE),
        attractions = listOf(
            Attraction(
                id = "radhanagar-beach-havelock",
                destinationId = "ut-andaman",
                name = "Radhanagar Beach (Beach No. 7 - Blue Flag)",
                description = "Powder-soft white sands, gentle turquoise waves, and dense mahua forest borders with golden sunsets.",
                category = "Blue Flag Beach",
                latitude = 11.9842,
                longitude = 92.9514,
                entryFeeAdult = "Free",
                recommendedDurationMinutes = 180,
                familyFriendly = true,
                insiderTip = "Walk 500 meters left of the main entrance to find tranquil, completely secluded white sand stretches."
            ),
            Attraction(
                id = "cellular-jail-port-blair",
                destinationId = "ut-andaman",
                name = "Cellular Jail National Memorial (Kala Pani)",
                description = "Historic British colonial prison where Indian freedom fighters were exiled, featuring 7-winged panopticon architecture and an emotional evening Light & Sound show.",
                category = "National Memorial & History",
                latitude = 11.6739,
                longitude = 92.7478,
                entryFeeAdult = "₹30 entry, ₹150 for Light & Sound Show",
                openingTime = "09:00",
                closingTime = "17:00",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                photographyAllowed = true
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-neil-natural-bridge",
                destinationId = "ut-andaman",
                name = "Howrah Bridge Natural Rock Formation (Neil Island)",
                description = "Naturally carved living coral and rock bridge standing on Lakshmanpur Beach, surrounded by shallow tide pools with sea anemones, clownfish, and star corals.",
                whyItIsSpecial = "Only accessible during low tide when the seabed reveals vibrant marine life.",
                category = "Natural Rock Arch & Tidal Pools",
                location = "Neil Island (Shaheed Dweep)",
                latitude = 11.8310,
                longitude = 93.0420,
                crowdLevel = "Low to Moderate",
                difficulty = "Easy (Walk on reef requires sturdy water shoes)"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Fresh Grilled Red Snapper with Coconut Garlic Sauce",
                    isVegetarian = false,
                    description = "Catch-of-the-day reef fish grilled on charcoal with local island spices, crushed black pepper, and lime.",
                    popularAt = "Something Different Cafe & Full Moon Cafe (Havelock)",
                    priceRange = "₹450 - ₹750"
                )
            )
        ),
        stays = listOf(
            Accommodation(
                id = "stay-taj-exotica-havelock",
                name = "Taj Exotica Resort & Spa, Andamans",
                category = "5-Star Luxury Eco-Resort",
                pricePerNight = 18000,
                rating = 4.9f,
                amenities = listOf("Private Beach", "Olympic Infinity Pool", "Dive Concierge", "Presidential Villas")
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Chennai" to 1350, "Kolkata" to 1300),
            drivingTimes = mapOf("Port Blair to Havelock" to "1.5 to 2.5 Hours by High-Speed Catamaran Ferry (Makruzz / Nautika)"),
            roadTripRoute = "Ferry connection between Port Blair, Havelock Island (Swaraj Dweep), and Neil Island (Shaheed Dweep).",
            nearestRailwayStation = "Not applicable (Island territory)",
            nearestAirport = "Veer Savarkar International Airport, Port Blair (IXZ - direct flights from Delhi, Mumbai, Kolkata, Chennai, Bengaluru, Hyderabad)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 4500,
            foodEstimatePerDay = 1200,
            activitiesTotal = 3500,
            travelEstimate = 5000,
            totalEstimateMin = 14200,
            totalEstimateMax = 32000
        ),
        seasons = RegionalSeasonalHelper.createCoastalSeasons("ut-andaman")
    )

    val puducherry = Destination(
        id = "ut-puducherry",
        name = "Puducherry & Auroville",
        state = "Puducherry",
        stateCode = "PY",
        district = "Puducherry",
        latitude = 11.9416,
        longitude = 79.8083,
        tagline = "The French Riviera of the East: pastel colonial boulevards, Auroville Matrimandir, and coastal promenades",
        description = "A distinctive coastal town blending 18th-century French colonial architecture in the French Quarter (White Town) with Tamil heritage across the canal. Renowned for tree-lined avenues with vibrant bougainvillea, beachfront Promenade Beach, Sri Aurobindo Ashram, the experimental international township of Auroville with its golden Matrimandir dome, and world-class French patisseries.",
        shortDescription = "French colonial coastal haven with pastel avenues, cafes, and Auroville",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "Sea level",
        destinationTypes = listOf("French Colonial", "Beach", "Auroville", "Cafes", "Spiritual"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "October to March",
        categories = listOf(TravelCategory.BEACHES, TravelCategory.HERITAGE, TravelCategory.FOOD),
        attractions = listOf(
            Attraction(
                id = "white-town-puducherry",
                destinationId = "ut-puducherry",
                name = "White Town (French Quarter) Heritage Walk",
                description = "Charming grid of streets with mustard-yellow colonial mansions, arched windows, chic boutiques, and the oceanfront Promenade.",
                category = "Colonial Heritage Quarter",
                latitude = 11.9338,
                longitude = 79.8358,
                entryFeeAdult = "Free",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                insiderTip = "Rent a vintage bicycle to explore Rue Romain Rolland, Rue Suffren, and the Promenade early in the morning."
            ),
            Attraction(
                id = "auroville-matrimandir",
                destinationId = "ut-puducherry",
                name = "Auroville Matrimandir & Visitors Centre",
                description = "Universal township founded by Mirra Alfassa (The Mother), centered on the golden geodesic dome of the Matrimandir for silent concentration.",
                category = "Universal Township / Meditation",
                latitude = 11.9961,
                longitude = 79.8106,
                entryFeeAdult = "Free (Inner Chamber pass requires advance online booking 3-7 days prior)",
                openingTime = "09:00",
                closingTime = "17:00",
                recommendedDurationMinutes = 180,
                familyFriendly = true,
                photographyAllowed = true
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-eden-blue-flag-beach",
                destinationId = "ut-puducherry",
                name = "Eden Beach (Blue Flag Certified)",
                description = "Pristine white sand beach between Arts and Crafts Village and Chunnambar backwaters, certified with the international Blue Flag standard for clean water and eco-management.",
                whyItIsSpecial = "Cleanest, safest, and most tranquil beach in Puducherry, bordered by backwaters and casuarina groves.",
                category = "Blue Flag Beach",
                location = "Chinnaveerampattinam, 7 km south of White Town",
                latitude = 11.8847,
                longitude = 79.8172,
                entryFee = "Free",
                crowdLevel = "Low to Moderate",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "French Croissants, Ratatouille & Creole Curry",
                    isVegetarian = true,
                    description = "Fresh buttery flaky croissants, artisanal wood-fired sourdough, and Franco-Tamil Creole seafood curry.",
                    popularAt = "Baker Street, Cafe des Arts & Coromandel Cafe",
                    priceRange = "₹180 - ₹350"
                )
            )
        ),
        stays = listOf(
            Accommodation(
                id = "stay-palais-de-mahe",
                name = "Palais de Mahe (CGH Earth)",
                category = "French Colonial Boutique Hotel",
                pricePerNight = 8500,
                rating = 4.8f,
                amenities = listOf("Courtyard Pool", "Colonial Verandas", "Fine Dining", "Near Promenade Beach")
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Chennai" to 150, "Bengaluru" to 310, "Hyderabad" to 780),
            drivingTimes = mapOf("Chennai" to "3 Hours via scenic East Coast Road (ECR)", "Bengaluru" to "6 Hours"),
            roadTripRoute = "Chennai -> Mahabalipuram -> Kalpakkam -> East Coast Road (ECR) -> Puducherry (scenic ocean drive).",
            nearestRailwayStation = "Puducherry Railway Station (PDY - 1 km) / Villupuram Junction (VM - 38 km)",
            nearestAirport = "Puducherry Airport (PNY - 6 km, regional ATR flights) / Chennai International Airport (MAA - 135 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 2800,
            foodEstimatePerDay = 1000,
            activitiesTotal = 800,
            travelEstimate = 1800,
            totalEstimateMin = 6400,
            totalEstimateMax = 15000
        ),
        seasons = RegionalSeasonalHelper.createCoastalSeasons("ut-puducherry")
    )

    val destinations: List<Destination> = listOf(ladakh, andaman, puducherry)
}
