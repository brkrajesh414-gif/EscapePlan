package com.example.data.imported.rajasthan

import com.example.data.imported.common.RegionalSeasonalHelper
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.DiscoveryLevel
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.HiddenGem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo
import com.example.data.model.VerificationLevel

object RajasthanDestinationsData {

    val jaipur = Destination(
        id = "rajasthan-jaipur",
        name = "Jaipur (The Pink City)",
        state = "Rajasthan",
        stateCode = "RJ",
        district = "Jaipur",
        latitude = 26.9124,
        longitude = 75.7873,
        tagline = "The royal capital of palaces, hilltop forts, astronomical wonders, and vibrant bazaars",
        description = "Jaipur, UNESCO World Heritage city, is the capital of Rajasthan. Founded in 1727 by Maharaja Sawai Jai Singh II, it is famous for its rose-pink terracotta walls, Amer Fort, the lattice facade of Hawa Mahal, and astronomical Jantar Mantar.",
        shortDescription = "Royal pink city with majestic hilltop forts and grand royal palaces",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 4,
        destinationTypes = listOf("Heritage", "Palaces", "Forts", "Shopping", "Food", "UNESCO Heritage"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "October to March",
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.FAMILY, TravelCategory.FOOD),
        verificationLevel = VerificationLevel.TRUSTED,
        attractions = listOf(
            Attraction(
                id = "amer-fort-jaipur",
                destinationId = "rajasthan-jaipur",
                name = "Amer Fort & Sheesh Mahal",
                description = "Opulent hilltop fort with Rajput and Mughal architecture, artistic cobbled pathways, and the glittering Mirror Palace.",
                category = "Fort",
                latitude = 26.9855,
                longitude = 75.8513,
                openingTime = "08:00 AM",
                closingTime = "05:30 PM",
                entryFeeAdult = "₹100 (Indian) / ₹500 (Foreigner)",
                recommendedDurationMinutes = 150,
                familyFriendly = true,
                photographyAllowed = true
            ),
            Attraction(
                id = "hawa-mahal-jaipur",
                destinationId = "rajasthan-jaipur",
                name = "Hawa Mahal (Palace of Winds)",
                description = "Five-story pink sandstone pyramid with 953 intricately carved jharokhas (casements) designed for royal women to observe street festivals unseen.",
                category = "Palace",
                latitude = 26.9239,
                longitude = 75.8267,
                entryFeeAdult = "₹50",
                recommendedDurationMinutes = 60,
                familyFriendly = true,
                photographyAllowed = true
            ),
            Attraction(
                id = "nahargarh-sunset-point",
                destinationId = "rajasthan-jaipur",
                name = "Nahargarh Fort Sunset Point",
                description = "Stands on the edge of the Aravalli Hills, offering spellbinding twilight views over the entire illuminated Pink City below.",
                category = "Viewpoint / Fort",
                latitude = 26.9372,
                longitude = 75.8155,
                entryFeeAdult = "₹50",
                recommendedDurationMinutes = 90
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-panna-meena-kund",
                destinationId = "rajasthan-jaipur",
                name = "Panna Meena ka Kund Stepwell",
                description = "Magnificent 16th-century symmetrical geometric stepwell with interlocking criss-cross stone stairs near Amer.",
                whyItIsSpecial = "Quiet historic oasis with mesmerizing geometric photography angles away from fort crowds.",
                category = "Historic Stepwell",
                location = "Amer Town, Jaipur",
                latitude = 26.9890,
                longitude = 75.8580,
                crowdLevel = "Low"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Pyaaz Kachori & Dal Baati Churma",
                    isVegetarian = true,
                    description = "Flaky golden pastry filled with spiced onions, accompanied by baked wheat balls dunked in pure ghee with spiced lentil curry.",
                    popularAt = "Rawat Mishthan Bhandar / LMB Johari Bazar",
                    priceRange = "₹50 - ₹200"
                ),
                FoodItem(
                    name = "Ghevar (Rabdi Sweet)",
                    isVegetarian = true,
                    description = "Honeycomb disc-shaped sweet cake soaked in saffron syrup and crowned with thick malai rabdi.",
                    popularAt = "Laxmi Mishthan Bhandar (LMB)",
                    priceRange = "₹100 - ₹250"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Delhi" to 280, "Agra" to 240, "Hyderabad" to 1480, "Mumbai" to 1150),
            drivingTimes = mapOf("Delhi" to "4.5 Hours via Delhi-Mumbai Expressway", "Agra" to "4 Hours"),
            roadTripRoute = "NH 48 or the new Delhi-Mumbai Expressway directly connected to Jaipur ring road.",
            nearestRailwayStation = "Jaipur Junction",
            nearestAirport = "Jaipur International Airport (JAI)"
        ),
        seasons = RegionalSeasonalHelper.createDeccanSeasons("rajasthan-jaipur")
    )

    val udaipur = Destination(
        id = "rajasthan-udaipur",
        name = "Udaipur (City of Lakes)",
        state = "Rajasthan",
        stateCode = "RJ",
        district = "Udaipur",
        latitude = 24.5854,
        longitude = 73.7125,
        tagline = "Romantic white palaces shimmering on Lake Pichola surrounded by the emerald Aravalli Hills",
        description = "Founded in 1559 by Maharana Udai Singh II, Udaipur is the crown jewel of Mewar. Known as the Venice of the East, it is celebrated for its majestic City Palace complex, floating Lake Palace, Jag Mandir island, and sunset boat cruises.",
        shortDescription = "Romantic lake city crowned with grand royal palaces and marble ghats",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 4,
        altitude = "598 m",
        destinationTypes = listOf("Lakes", "Heritage", "Palaces", "Romantic", "Architecture"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "September to March",
        categories = listOf(TravelCategory.COUPLES, TravelCategory.HERITAGE, TravelCategory.FAMILY),
        verificationLevel = VerificationLevel.TRUSTED,
        attractions = listOf(
            Attraction(
                id = "city-palace-udaipur",
                destinationId = "rajasthan-udaipur",
                name = "City Palace & Museum Complex",
                description = "Rajasthan's largest royal palace complex with granite and marble balconies overlooking Lake Pichola.",
                category = "Palace",
                latitude = 24.5764,
                longitude = 73.6835,
                openingTime = "09:00 AM",
                closingTime = "05:30 PM",
                entryFeeAdult = "₹300",
                recommendedDurationMinutes = 150
            ),
            Attraction(
                id = "lake-pichola-boat-ride",
                destinationId = "rajasthan-udaipur",
                name = "Lake Pichola Sunset Boat Cruise",
                description = "Serene boat ride passing the floating Taj Lake Palace and stopping at the marble courtyards of Jag Mandir island.",
                category = "Boating / Lake",
                latitude = 24.5780,
                longitude = 73.6790,
                entryFeeAdult = "₹450 - ₹700",
                recommendedDurationMinutes = 60
            ),
            Attraction(
                id = "saheliyon-ki-bari",
                destinationId = "rajasthan-udaipur",
                name = "Saheliyon-ki-Bari (Garden of Maidens)",
                description = "Historic royal garden designed with lotus pools, marble elephant fountains, and bird fountains powered purely by gravity.",
                category = "Heritage Garden",
                latitude = 24.6060,
                longitude = 73.6872,
                entryFeeAdult = "₹50",
                recommendedDurationMinutes = 45
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-badi-lake-bahubali-hill",
                destinationId = "rajasthan-udaipur",
                name = "Bahubali Hill & Lake Badi",
                description = "Short 15-minute nature trail to a cliff outcrop overlooking the turquoise waters of Badi Lake and rolling Aravalli ridge.",
                whyItIsSpecial = "Breathtaking panoramic lake-and-mountain vista far from city traffic.",
                category = "Viewpoint / Nature Trail",
                location = "Lake Badi, 12 km from Udaipur",
                latitude = 24.6150,
                longitude = 73.6280,
                crowdLevel = "Low"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Ker Sangri & Gatte ki Sabzi",
                    isVegetarian = true,
                    description = "Traditional desert bean and berry curry paired with gram-flour dumplings simmered in tangy spiced yogurt gravy.",
                    popularAt = "Traditional Mewari Thali at Natraj / 1559 AD",
                    priceRange = "₹250 - ₹500"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Ahmedabad" to 260, "Jaipur" to 395, "Delhi" to 660, "Mumbai" to 760, "Hyderabad" to 1180),
            drivingTimes = mapOf("Ahmedabad" to "4.5 Hours", "Jaipur" to "6.5 Hours", "Delhi" to "11 Hours"),
            roadTripRoute = "NH 48 via Chittorgarh or direct smooth 4-lane highway from Ahmedabad.",
            nearestRailwayStation = "Udaipur City Railway Station (UDZ)",
            nearestAirport = "Maharana Pratap Airport (UDR - 22 km)"
        ),
        seasons = RegionalSeasonalHelper.createDeccanSeasons("rajasthan-udaipur")
    )

    val jodhpur = Destination(
        id = "rajasthan-jodhpur",
        name = "Jodhpur (The Blue City)",
        state = "Rajasthan",
        stateCode = "RJ",
        district = "Jodhpur",
        latitude = 26.2968,
        longitude = 73.0185,
        tagline = "The majestic Sun City crowned by towering Mehrangarh Fort and indigo-painted lanes",
        description = "Founded in 1459 by Rao Jodha, Jodhpur is world-famous for its cliff-carved Mehrangarh Fort standing 400 feet above the plain, its sea of indigo-blue painted houses in Navchokiya, and royal Umaid Bhawan Palace.",
        shortDescription = "Sun City of indigo-hued alleys guarded by the mighty Mehrangarh Fort",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        destinationTypes = listOf("Forts", "Heritage", "Architecture", "Desert Culture", "Food"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "October to March",
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.WEEKEND_GETAWAYS, TravelCategory.FOOD),
        verificationLevel = VerificationLevel.TRUSTED,
        attractions = listOf(
            Attraction(
                id = "mehrangarh-fort-jodhpur",
                destinationId = "rajasthan-jodhpur",
                name = "Mehrangarh Fort & Museum",
                description = "Impregnable 15th-century fortress perched on a sheer perpendicular cliff with palatial courtyards and world-class royal museum.",
                category = "Fort",
                latitude = 26.2978,
                longitude = 73.0186,
                openingTime = "09:00 AM",
                closingTime = "05:00 PM",
                entryFeeAdult = "₹100 (Indian) / ₹600 (Foreigner)",
                recommendedDurationMinutes = 180
            ),
            Attraction(
                id = "jaswant-thada-jodhpur",
                destinationId = "rajasthan-jodhpur",
                name = "Jaswant Thada (Taj of Marwar)",
                description = "Intricately carved white marble cenotaph built by Maharaja Sardar Singh in 1899 with carved gazebos and lakeside gardens.",
                category = "Monument / Heritage",
                latitude = 26.3040,
                longitude = 73.0232,
                entryFeeAdult = "₹30",
                recommendedDurationMinutes = 45
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-toorji-ka-jhalra",
                destinationId = "rajasthan-jodhpur",
                name = "Toorji ka Jhalra Stepwell",
                description = "1740s Rajput stepwell crafted in rose-red sandstone with intricate carvings of dancing elephants, medieval lions, and waterside cafes.",
                whyItIsSpecial = "Restored heritage stepwell filled with clear turquoise water and vibrant urban step cafes.",
                category = "Historic Stepwell",
                location = "Makrana Mohalla, Jodhpur",
                latitude = 26.2971,
                longitude = 73.0255,
                crowdLevel = "Moderate"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Mirchi Vada & Mawa Kachori",
                    isVegetarian = true,
                    description = "Crispy gram-flour battered Bhavnagri chili stuffed with spiced potato mash, followed by sweet sugar-syrup soaked mawa pastry.",
                    popularAt = "Shahi Samosa & Janta Sweet Home",
                    priceRange = "₹40 - ₹120"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Jaipur" to 335, "Udaipur" to 250, "Delhi" to 600, "Ahmedabad" to 450),
            drivingTimes = mapOf("Jaipur" to "5.5 Hours", "Udaipur" to "4.5 Hours"),
            roadTripRoute = "NH 62 and NH 25 connecting smoothly across central Rajasthan.",
            nearestRailwayStation = "Jodhpur Junction (JU)",
            nearestAirport = "Jodhpur Airport (JDH)"
        ),
        seasons = RegionalSeasonalHelper.createDeccanSeasons("rajasthan-jodhpur")
    )

    val destinations: List<Destination> = listOf(jaipur, udaipur, jodhpur)
}
