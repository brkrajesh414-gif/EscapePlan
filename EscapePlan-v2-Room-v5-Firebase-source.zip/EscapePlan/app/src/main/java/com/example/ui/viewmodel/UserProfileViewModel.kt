package com.example.ui.viewmodel

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.auth.AuthRepository
import com.example.data.auth.AuthUser
import com.example.data.local.AppDatabase
import com.example.data.local.UserProfileEntity
import com.example.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProfileState(val user: AuthUser? = null, val profile: UserProfileEntity? = null,
    val loading: Boolean = true, val error: String? = null, val message: String? = null)

class UserProfileViewModel(application: Application) : AndroidViewModel(application) {
    private val auth = AuthRepository(application)
    private val repository = UserRepository(AppDatabase.getInstance(application).userProfileDao())
    private val mutable = MutableStateFlow(ProfileState())
    val state = mutable.asStateFlow()

    init {
        viewModelScope.launch {
            auth.user.collectLatest { result ->
                val user = result.getOrNull()
                mutable.value = ProfileState(user = user, loading = false, error = result.exceptionOrNull()?.message)
                if (user != null) {
                    val sync = repository.synchronize(user)
                    mutable.update { it.copy(error = sync.exceptionOrNull()?.message) }
                    repository.observe(user.uid).collect { profile -> mutable.update { it.copy(profile = profile) } }
                }
            }
        }
    }

    private fun runAction(block: suspend () -> Result<Unit>) {
        viewModelScope.launch {
            mutable.update { it.copy(loading = true, error = null, message = null) }
            val result = block()
            mutable.update { it.copy(loading = false, error = result.exceptionOrNull()?.message) }
        }
    }
    fun email(email: String, password: String, register: Boolean) = runAction { auth.email(email, password, register) }
    fun google(activity: Activity) = runAction { auth.google(activity) }
    fun signOut() = runAction { auth.signOut() }
    fun refresh() = runAction {
        state.value.user?.let { repository.synchronize(it) } ?: Result.failure(IllegalStateException("Sign in to synchronize your profile."))
    }
    fun resetPassword(email: String) = runAction {
        auth.resetPassword(email).onSuccess { mutable.update { it.copy(message = "If the account exists, a reset email will be sent.") } }
    }
    fun save(name: String, preferences: Set<String>) = runAction {
        state.value.user?.let { repository.save(it, name, preferences) }
            ?: Result.failure(IllegalStateException("Sign in first."))
    }
}
