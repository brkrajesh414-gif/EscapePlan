package com.example.data.imported.northeast

import com.example.data.imported.common.RegionalSeasonalHelper
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.DiscoveryLevel
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.HiddenGem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo

object NorthEastDestinationsData {

    val kaziranga = Destination(
        id = "assam-kaziranga",
        name = "Kaziranga National Park",
        state = "Assam",
        stateCode = "AS",
        district = "Golaghat & Nagaon",
        latitude = 26.5775,
        longitude = 93.1711,
        tagline = "UNESCO World Heritage: home to two-thirds of the world's Great One-Horned Rhinoceroses",
        description = "Set along the mighty Brahmaputra River floodplains, Kaziranga's tall elephant grass and tropical moist broadleaf forests shelter over 2,600 Indian one-horned rhinos, wild water buffaloes, swamp deer (barasingha), and high-density Bengal tiger populations.",
        shortDescription = "World Heritage floodplain sanctuary sheltering the rare one-horned rhinoceros",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "60 m",
        destinationTypes = listOf("UNESCO World Heritage", "Wildlife Safari", "Rhino", "Floodplains", "Birding"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "November to April (Park open, elephant and jeep safaris operating)",
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.ADVENTURE, TravelCategory.NATURE),
        attractions = listOf(
            Attraction(
                id = "central-range-kohora-safari",
                destinationId = "assam-kaziranga",
                name = "Central Range (Kohora) Jeep & Elephant Safari",
                description = "Prime safari zone renowned for close sightings of wild rhinos grazing in marshy wetlands and herds of wild elephants.",
                category = "Wildlife Safari",
                latitude = 26.5861,
                longitude = 93.3611,
                entryFeeAdult = "₹2,500 - ₹3,500 per Jeep safari (up to 6 persons)",
                recommendedDurationMinutes = 180,
                familyFriendly = true,
                insiderTip = "Take an early morning Elephant safari (05:30 AM) for magical misty rides right through the tall elephant grass."
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-kakochang-waterfall",
                destinationId = "assam-kaziranga",
                name = "Kakochang Waterfall & Rubber Estates",
                description = "Pristine jungle waterfall tumbling into clean rock pools amidst dense rubber, coffee, and tea plantations near Bokakhat.",
                whyItIsSpecial = "Quiet picnic and swimming paradise just 13 km from the wildlife safari gates.",
                category = "Jungle Waterfall",
                location = "Near Bokakhat, 13 km from Kohora",
                latitude = 26.6110,
                longitude = 93.5430,
                crowdLevel = "Low",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Assamese Thali with Masor Tenga & Khar",
                    isVegetarian = false,
                    description = "Light sour river fish curry cooked with tomatoes and elephant apple (Ou Tenga), served with fragrant Joha rice.",
                    popularAt = "Mai-Hang Ethnic Restaurant & Eco-Resorts in Kohora",
                    priceRange = "₹200 - ₹350"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Guwahati" to 220, "Jorhat" to 90, "Tezpur" to 50),
            drivingTimes = mapOf("Guwahati" to "4.5 Hours via 4-lane NH 715", "Jorhat" to "2 Hours"),
            roadTripRoute = "Guwahati -> Dispur -> Jagiroad -> Nagaon bypass -> Jakhalabandha -> Kohora (Kaziranga main gate).",
            nearestRailwayStation = "Furkating Junction (FKG - 75 km) / Guwahati (GHY - 220 km)",
            nearestAirport = "Jorhat Airport (JRH - 95 km) / Guwahati Lokpriya Gopinath Bordoloi Airport (GAU - 240 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 2800,
            foodEstimatePerDay = 850,
            activitiesTotal = 2200,
            travelEstimate = 2000,
            totalEstimateMin = 7850,
            totalEstimateMax = 17000
        ),
        seasons = RegionalSeasonalHelper.createDeccanSeasons("assam-kaziranga")
    )

    val meghalayaCherrapunji = Destination(
        id = "meghalaya-sohra",
        name = "Cherrapunji (Sohra) & Dawki",
        state = "Meghalaya",
        stateCode = "ML",
        district = "East Khasi Hills",
        latitude = 25.2986,
        longitude = 91.7324,
        tagline = "The Abode of Clouds: bio-engineered Living Root Bridges, towering waterfalls, and Dawki's glass-clear river",
        description = "Resting atop dramatic sandstone plateaus rising above the Bangladesh plains, Sohra (Cherrapunji) receives some of the highest rainfall on Earth. Celebrated for centuries-old double-decker living root bridges crafted by Khasi tribes from Ficus elastica trees, monumental plunge waterfalls like Nohkalikai (340 m), deep Mawsmai limestone caves, and Dawki's crystal-clear Umngot River where boats appear to float in mid-air.",
        shortDescription = "Abode of Clouds with double-decker root bridges and glass-like rivers",
        bestDurationMinDays = 3,
        bestDurationMaxDays = 5,
        altitude = "1,430 m",
        destinationTypes = listOf("Living Root Bridges", "Waterfalls", "Caves", "Crystal River", "Trekking"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "September to May (Post-monsoon waterfalls roaring, rivers transparent in winter)",
        categories = listOf(TravelCategory.WATERFALLS, TravelCategory.ADVENTURE, TravelCategory.NATURE),
        attractions = listOf(
            Attraction(
                id = "double-decker-root-bridge",
                destinationId = "meghalaya-sohra",
                name = "Double Decker Living Root Bridge (Nongriat)",
                description = "Biological wonder created by Khasi tribal ancestors intertwining the living aerial roots of Indian rubber fig trees over generations across roaring mountain streams.",
                category = "Living Architecture / Eco Trek",
                latitude = 25.2508,
                longitude = 91.6706,
                entryFeeAdult = "₹50 (Community conservation fee)",
                recommendedDurationMinutes = 300,
                familyFriendly = false,
                insiderTip = "Involves descending and ascending 3,500 stone stairs through Tyrna village; stay overnight at Nongriat village homestay to recover and visit the Rainbow Falls."
            ),
            Attraction(
                id = "nohkalikai-falls-sohra",
                destinationId = "meghalaya-sohra",
                name = "Nohkalikai Falls (340 m)",
                description = "India's tallest plunge waterfall cascading off a red rock cliff face into an emerald-green plunge pool.",
                category = "Monumental Waterfall",
                latitude = 25.2758,
                longitude = 91.6847,
                entryFeeAdult = "₹20",
                recommendedDurationMinutes = 60,
                familyFriendly = true,
                photographyAllowed = true
            ),
            Attraction(
                id = "dawki-umngot-river",
                destinationId = "meghalaya-sohra",
                name = "Dawki & Umngot Transparent River",
                description = "Crystal-clear river bordering Bangladesh where water is so transparent that hand-rowed wooden boats appear suspended in air.",
                category = "Crystal River / Boating",
                latitude = 25.1844,
                longitude = 92.0183,
                entryFeeAdult = "₹800 - ₹1,000 per wooden boat ride",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                insiderTip = "Water is clearest between November and April; during monsoon the current turns muddy and turbulent."
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-wei-sawdong-waterfall",
                destinationId = "meghalaya-sohra",
                name = "Wei Sawdong Three-Tiered Emerald Waterfall",
                description = "Spectacular 3-tiered natural stepped waterfall hidden deep in dense subtropical jungle, reached via a makeshift bamboo and root trek.",
                whyItIsSpecial = "Breathtaking turquoise plunge pools resembling a fairytale natural amphitheater.",
                category = "Secret Waterfall",
                location = "Near Mawmluh, Sohra",
                latitude = 25.2890,
                longitude = 91.7010,
                entryFee = "₹50",
                trekDistance = "800 m steep jungle trail with bamboo railings",
                crowdLevel = "Low to Moderate",
                difficulty = "Moderate"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Khasi Jadoh & Dohneiiong with Tungrymbai",
                    isVegetarian = false,
                    description = "Fragrant rice cooked with mild mountain spices and pork or chicken, accompanied by tender pork curry in black sesame paste.",
                    popularAt = "Trattoria in Shillong & Orange Roots (Pure Veg) in Sohra",
                    priceRange = "₹150 - ₹280"
                )
            )
        ),
        stays = listOf(
            Accommodation(
                id = "stay-cherrapunji-resort",
                name = "Polo Orchid Resort Cherrapunji",
                category = "Valley-Facing Resort",
                pricePerNight = 6500,
                rating = 4.7f,
                amenities = listOf("Infinity Pool facing Waterfalls", "Multi-Cuisine Dining", "Balcony Views")
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Shillong" to 54, "Guwahati" to 150),
            drivingTimes = mapOf("Shillong" to "2 Hours via scenic Mawkdok Dympep Valley", "Guwahati" to "4.5 Hours"),
            roadTripRoute = "Guwahati -> GS Road -> Shillong bypass -> Upper Shillong -> Mawkdok Bridge -> Sohra.",
            nearestRailwayStation = "Guwahati Railway Station (GHY - 150 km)",
            nearestAirport = "Shillong Airport (SHL - Umroi, 85 km) / Guwahati Airport (GAU - 170 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 3000,
            foodEstimatePerDay = 850,
            activitiesTotal = 1500,
            travelEstimate = 2500,
            totalEstimateMin = 7850,
            totalEstimateMax = 18000
        ),
        seasons = RegionalSeasonalHelper.createHighAltitudeSeasons("meghalaya-sohra")
    )

    val sikkimGangtok = Destination(
        id = "sikkim-gangtok",
        name = "Gangtok & Tsomgo Glacial Lake",
        state = "Sikkim",
        stateCode = "SK",
        district = "East Sikkim",
        latitude = 27.3389,
        longitude = 88.6065,
        tagline = "First organic state of India: majestic Kanchenjunga vistas, fluttering prayer flags, and holy alpine glacial lakes",
        description = "Spanning a cloud-kissed ridge at 1,650 meters, Gangtok is the modern capital of Sikkim, blending ancient Tibetan Buddhist culture at Rumtek and Enchey monasteries with eco-friendly urban pedestrian promenades on MG Marg. Gateway to sacred high-altitude Tsomgo Lake (3,753 m) and Nathu La Pass on the ancient Silk Route.",
        shortDescription = "Organic Himalayan capital with views of Kanchenjunga and sacred alpine lakes",
        bestDurationMinDays = 3,
        bestDurationMaxDays = 5,
        altitude = "1,650 m – 3,753 m",
        destinationTypes = listOf("Himalayas", "Buddhist Culture", "Alpine Lakes", "Eco Tourism", "Organic"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "March to May (Rhododendrons) & October to mid-December (Crystal clear peak views)",
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.TEMPLES, TravelCategory.NATURE),
        attractions = listOf(
            Attraction(
                id = "tsomgo-lake-sikkim",
                destinationId = "sikkim-gangtok",
                name = "Tsomgo (Changu) Glacial Lake (3,753 m)",
                description = "Sacred oval-shaped high-altitude lake fed by melting glacial snows, reflecting surrounding jagged peaks and decorated with decorated yaks.",
                category = "Sacred Glacial Lake",
                latitude = 27.3742,
                longitude = 88.7619,
                entryFeeAdult = "Protected Area Permit (PAP) required (₹200 through registered travel agency)",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                insiderTip = "Indians require PAP with passport photos & Govt ID; apply 1 day prior through registered Sikkim tour operator."
            ),
            Attraction(
                id = "rumtek-monastery-sikkim",
                destinationId = "sikkim-gangtok",
                name = "Rumtek Dharma Chakra Centre",
                description = "Largest monastery in Sikkim and seat of the Karma Kagyu lineage, housing golden stupas, rare Tibetan scriptures, and painted thangkas.",
                category = "Tibetan Buddhist Monastery",
                latitude = 27.2994,
                longitude = 88.5447,
                entryFeeAdult = "₹20",
                recommendedDurationMinutes = 90,
                familyFriendly = true,
                photographyAllowed = false
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-tashi-viewpoint",
                destinationId = "sikkim-gangtok",
                name = "Tashi Viewpoint & Bakthang Falls",
                description = "Serene vantage point 8 km from Gangtok built by the King of Sikkim, offering sweeping sunrise views of Mt. Kanchenjunga and Mt. Siniolchu.",
                whyItIsSpecial = "Breathtaking early morning alpine views with peaceful prayer wheels.",
                category = "Mountain Viewpoint",
                location = "8 km from Gangtok on North Sikkim Highway",
                latitude = 27.3567,
                longitude = 88.6250,
                entryFee = "₹10",
                crowdLevel = "Low to Moderate",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Sikkimese Phagshapa, Tingmo & Chhurpi Soup",
                    isVegetarian = false,
                    description = "Steamed soft flower-shaped yeast bread (Tingmo) paired with pork stewed with dried mountain chilies and radishes.",
                    popularAt = "Taste of Tibet & Nimtho on MG Marg",
                    priceRange = "₹180 - ₹320"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Siliguri" to 115, "Bagdogra" to 125, "Darjeeling" to 100),
            drivingTimes = mapOf("Siliguri" to "4.5 Hours along the Teesta River via NH 10", "Bagdogra" to "5 Hours"),
            roadTripRoute = "Siliguri / Bagdogra -> Sevoke Coronation Bridge -> Teesta Bazaar -> Rangpo border check-post -> Singtam -> Gangtok.",
            nearestRailwayStation = "New Jalpaiguri Junction (NJP - 120 km)",
            nearestAirport = "Pakyong Airport (PYG - 30 km, seasonal flights) / Bagdogra Airport (IXB - 125 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 2800,
            foodEstimatePerDay = 900,
            activitiesTotal = 1500,
            travelEstimate = 2800,
            totalEstimateMin = 8000,
            totalEstimateMax = 18000
        ),
        seasons = RegionalSeasonalHelper.createHighAltitudeSeasons("sikkim-gangtok")
    )

    val destinations: List<Destination> = listOf(kaziranga, meghalayaCherrapunji, sikkimGangtok)
}
