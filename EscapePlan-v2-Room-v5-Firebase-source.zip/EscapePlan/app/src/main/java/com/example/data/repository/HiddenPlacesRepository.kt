package com.example.data.repository

import android.content.Context
import com.example.core.operation
import com.example.data.model.HiddenPlace
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

class HiddenPlacesRepository(context: Context) {
    private val assets = context.applicationContext.assets
    private val json = Json { ignoreUnknownKeys = false }
    private var cache: List<HiddenPlace>? = null

    suspend fun load(): Result<List<HiddenPlace>> = operation {
        cache ?: withContext(Dispatchers.IO) {
            assets.open("hidden_places_catalog.json").bufferedReader().use { reader ->
                json.decodeFromString<List<HiddenPlace>>(reader.readText())
            }.also(::validate).also { cache = it }
        }
    }

    suspend fun get(id: String): Result<HiddenPlace> = operation {
        load().getOrThrow().singleOrNull { it.id == id } ?: error("Place not found")
    }

    private fun validate(entries: List<HiddenPlace>) {
        require(entries.size == 108) { "Expected 108 hidden-place entries" }
        require(entries.map { it.id }.distinct().size == entries.size) { "Duplicate hidden-place IDs" }
        entries.forEach { entry ->
            require(entry.id.isNotBlank() && entry.name.isNotBlank() && entry.stateOrUt.isNotBlank()) { "Incomplete hidden-place entry" }
            require(entry.categories.isNotEmpty() && entry.googleMapsUrl.startsWith("https://")) { "Invalid hidden-place entry" }
        }
    }
}
