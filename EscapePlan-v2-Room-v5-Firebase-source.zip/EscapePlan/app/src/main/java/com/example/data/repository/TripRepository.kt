package com.example.data.repository

import androidx.room.withTransaction
import com.example.core.operation
import com.example.data.local.ActivityEntity
import com.example.data.local.AppDatabase
import com.example.data.local.DayScheduleEntity
import com.example.data.local.TripEntity
import com.example.data.local.TripWithDays
import com.example.domain.Itinerary
import com.example.domain.validated
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.json.Json

class TripRepository(private val db: AppDatabase) {
    private val dao = db.plannerDao()
    private val json = Json { ignoreUnknownKeys = false }
    private fun currentUid(): String = runCatching { FirebaseAuth.getInstance().currentUser?.uid }.getOrNull().orEmpty()
    fun observe(id: String): Flow<TripWithDays?> = dao.observe(id).map { trip -> trip?.takeIf { it.trip.ownerUid == currentUid() } }
    fun trips(uid: String): Flow<List<TripEntity>> = dao.observeTrips(uid)

    suspend fun recover(): Result<Int> = operation {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: error("Sign in to recover generated plans.")
        val response = FirebaseFunctions.getInstance().getHttpsCallable("recoverItineraries").call().await().data as? Map<*, *>
            ?: error("Invalid recovery response")
        val records = response["trips"] as? List<*> ?: error("Missing recovery records")
        var restored = 0
        for (record in records) {
            check(currentUid() == uid) { "Your account changed. Please retry." }
            val fields = record as? Map<*, *> ?: error("Invalid trip record")
            val id = fields["tripId"] as? String ?: error("Missing trip ID")
            require(Regex("[a-f0-9-]{36}").matches(id)) { "Invalid recovered trip ID" }
            if (dao.get(id) != null) continue
            val plan = json.decodeFromString<Itinerary>(fields["itineraryJson"] as? String ?: error("Missing trip content"))
            save(plan, uid, id).getOrThrow()
            restored++
        }
        restored
    }

    suspend fun generate(prompt: String): Result<String> = operation {
        require(prompt.trim().length in 10..2000) { "Describe your trip in 10–2000 characters." }
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: error("Sign in to generate a trip.")
        val requestId = UUID.randomUUID().toString()
        val response = FirebaseFunctions.getInstance().getHttpsCallable("generateItinerary")
            .apply { setTimeout(130, TimeUnit.SECONDS) }
            .call(mapOf("prompt" to prompt.trim(), "requestId" to requestId)).await().data as? Map<*, *> ?: error("Invalid server response")
        check(FirebaseAuth.getInstance().currentUser?.uid == uid) { "Your account changed. Please retry." }
        val itinerary = json.decodeFromString<Itinerary>(response["itineraryJson"] as? String ?: error("Missing itinerary")).validated()
        check(response["tripId"] == requestId) { "Trip response does not match the request." }
        save(itinerary, uid, requestId).getOrThrow()
    }

    suspend fun save(itinerary: Itinerary, uid: String, id: String = UUID.randomUUID().toString()): Result<String> = operation {
        itinerary.validated()
        check(currentUid() == uid) { "Your account changed. Please retry." }
        val now = System.currentTimeMillis()
        db.withTransaction {
            val old = dao.get(id)
            check(old == null || old.trip.ownerUid == uid) { "Trip belongs to a different account" }
            dao.upsertTrip(TripEntity(id, itinerary.title, uid, itinerary.currency, old?.trip?.createdAt ?: now, now))
            dao.clearDays(id)
            itinerary.days.forEach { day ->
                val dayId = UUID.randomUUID().toString()
                dao.upsertDays(listOf(DayScheduleEntity(dayId, id, day.day, day.title)))
                dao.upsertActivities(day.activities.mapIndexed { index, activity -> ActivityEntity(
                    UUID.randomUUID().toString(), dayId, index, activity.timeSlot, activity.activity, activity.notes,
                    activity.latitude, activity.longitude, activity.estimatedCost
                ) })
            }
        }
        id
    }

    suspend fun reorder(tripId: String, dayId: String, orderedIds: List<String>): Result<Unit> = operation {
        db.withTransaction {
            val trip = dao.get(tripId) ?: error("Trip not found")
            check(trip.trip.ownerUid == currentUid()) { "Trip belongs to another account." }
            val activities = trip.days.single { it.day.id == dayId }.activities
            require(orderedIds.size == activities.size && orderedIds.toSet() == activities.map { it.id }.toSet()) { "Invalid activity order" }
            val byId = activities.associateBy { it.id }
            val slots = activities.sortedBy { it.position }.map { it.timeSlot }
            dao.upsertActivities(orderedIds.mapIndexed { index, id -> byId.getValue(id).copy(position = index, timeSlot = slots[index]) })
            dao.upsertTrip(trip.trip.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun swap(tripId: String, activityId: String, replacement: String): Result<Unit> = operation {
        require(replacement.isNotBlank() && replacement.length <= 300) { "Enter an activity name (up to 300 characters)." }
        db.withTransaction {
            val trip = dao.get(tripId) ?: error("Trip not found")
            check(trip.trip.ownerUid == currentUid()) { "Trip belongs to another account." }
            val activity = trip.days.flatMap { it.activities }.single { it.id == activityId }
            dao.upsertActivities(listOf(activity.copy(title = replacement.trim(), notes = "User-selected activity; confirm location and cost.", latitude = null, longitude = null, estimatedCost = 0.0)))
        }
    }

    suspend fun delete(id: String): Result<Unit> = operation {
        db.withTransaction {
            val trip = dao.get(id) ?: error("Trip not found")
            check(trip.trip.ownerUid == currentUid()) { "Trip belongs to another account." }
            dao.delete(id)
        }
    }
}
