package com.example.data.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

val MIGRATION_4_5: Migration = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS user_profiles (uid TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL, avatarUrl TEXT NOT NULL, preferencesJson TEXT NOT NULL, updatedAt INTEGER NOT NULL, pendingSync INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS planner_trips (id TEXT NOT NULL PRIMARY KEY, title TEXT NOT NULL, ownerUid TEXT NOT NULL, currency TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS day_schedules (id TEXT NOT NULL PRIMARY KEY, tripId TEXT NOT NULL, dayNumber INTEGER NOT NULL, title TEXT NOT NULL, FOREIGN KEY(tripId) REFERENCES planner_trips(id) ON UPDATE NO ACTION ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_day_schedules_tripId ON day_schedules(tripId)")
        db.execSQL("CREATE TABLE IF NOT EXISTS trip_activities (id TEXT NOT NULL PRIMARY KEY, dayId TEXT NOT NULL, position INTEGER NOT NULL, timeSlot TEXT NOT NULL, title TEXT NOT NULL, notes TEXT NOT NULL, latitude REAL, longitude REAL, estimatedCost REAL NOT NULL, FOREIGN KEY(dayId) REFERENCES day_schedules(id) ON UPDATE NO ACTION ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_trip_activities_dayId ON trip_activities(dayId)")
    }
}
