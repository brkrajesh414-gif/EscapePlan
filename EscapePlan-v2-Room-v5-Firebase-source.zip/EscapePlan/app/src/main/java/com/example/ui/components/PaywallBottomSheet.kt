package com.example.ui.components

import android.app.Activity
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.viewmodel.BillingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PaywallBottomSheet(model: BillingViewModel, onDismiss: () -> Unit) {
    val state by model.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(24.dp).verticalScroll(rememberScrollState())) {
            Text("EscapePlan Premium")
            Text("AI planning beyond the free allowance, PDF exports and premium map pin colours. Fair-use limits apply.")
            Text("Trip pass: one additional AI generation after the free allowance, with PDF export for that trip.")
            if (state.premium) Text("Premium active")
            Text("Available passes: ${state.credits}")
            state.error?.let { ErrorBanner(it, model.repository::restore) }
            if (state.products.isEmpty()) Text("No products available. Check Play Console configuration and install through a test track.")
            state.products.forEach { product ->
                val phases = product.subscriptionOfferDetails?.firstOrNull { it.offerId == null }?.pricingPhases?.pricingPhaseList
                    ?: product.subscriptionOfferDetails?.firstOrNull()?.pricingPhases?.pricingPhaseList
                val price = phases?.joinToString(" then ") { "${it.formattedPrice} / ${it.billingPeriod}" }
                    ?: product.oneTimePurchaseOfferDetails?.formattedPrice.orEmpty()
                Button(enabled = context is Activity && !state.loading, onClick = { (context as? Activity)?.let { model.repository.buy(it, product) } }) { Text("${product.name}: $price") }
            }
            Text("Subscriptions renew automatically under the terms shown by Google Play. Manage or cancel them in Google Play.")
            TextButton(onClick = model.repository::restore) { Text("Restore purchases") }
        }
    }
}
