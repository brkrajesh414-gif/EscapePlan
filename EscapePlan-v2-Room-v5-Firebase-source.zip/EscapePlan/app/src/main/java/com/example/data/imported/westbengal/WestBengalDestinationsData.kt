package com.example.data.imported.westbengal

import com.example.data.imported.common.RegionalSeasonalHelper
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.DiscoveryLevel
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.HiddenGem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo

object WestBengalDestinationsData {

    val darjeeling = Destination(
        id = "wb-darjeeling",
        name = "Darjeeling & Kanchenjunga",
        state = "West Bengal",
        stateCode = "WB",
        district = "Darjeeling",
        latitude = 27.0410,
        longitude = 88.2663,
        tagline = "Queen of the Hills: UNESCO Himalayan Toy Train, champagne tea gardens, and Tiger Hill sunrise over Mt. Kanchenjunga",
        description = "Perched at 2,042 meters in the Lesser Himalayas, Darjeeling is globally celebrated for its muscatel Darjeeling Tea estates, colonial charm along Mall Road (Chowrasta), the 1881 UNESCO Darjeeling Himalayan Railway steam locomotives, and sunrise panoramas illuminating Kangchenjunga and Mt. Everest from Tiger Hill.",
        shortDescription = "Colonial Himalayan hill town renowned for UNESCO steam train and world's finest tea",
        bestDurationMinDays = 3,
        bestDurationMaxDays = 5,
        altitude = "2,042 m",
        destinationTypes = listOf("Hill Station", "Tea Gardens", "UNESCO World Heritage", "Himalayas", "Colonial"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "March to May (Rhododendrons & clear skies) & October to December",
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.HERITAGE, TravelCategory.NATURE),
        attractions = listOf(
            Attraction(
                id = "tiger-hill-darjeeling",
                destinationId = "wb-darjeeling",
                name = "Tiger Hill Sunrise Panorama (2,590 m)",
                description = "Famous Himalayan vantage point where the first rays of morning sun turn the snows of Mt. Kanchenjunga into molten gold, with Mt. Everest visible on clear horizons.",
                category = "Sunrise Mountain Viewpoint",
                latitude = 26.9942,
                longitude = 88.2861,
                entryFeeAdult = "₹50 - ₹100 (Observation lounge ticket)",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                insiderTip = "Leave your hotel by 03:45 AM to beat morning tourist taxi queues and secure a front-row balcony spot."
            ),
            Attraction(
                id = "dhr-toy-train-darjeeling",
                destinationId = "wb-darjeeling",
                name = "Darjeeling Himalayan Railway (UNESCO Toy Train)",
                description = "Historic 2-foot narrow-gauge railway completed in 1881, offering scenic steam joy rides from Darjeeling to Ghum through the dramatic Batasia Loop.",
                category = "UNESCO World Heritage Railway",
                latitude = 27.0425,
                longitude = 88.2678,
                entryFeeAdult = "₹1,000 (Steam locomotive joyride) / ₹600 (Diesel)",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                photographyAllowed = true,
                insiderTip = "Book Joy Ride tickets online via IRCTC at least 30 days in advance during peak season."
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-lamahatta-eco-park",
                destinationId = "wb-darjeeling",
                name = "Lamahatta Eco Park & Sacred Lake",
                description = "Quiet mountain village 23 km from Darjeeling with manicured gardens, prayer flags, and a serene pine-forested trek leading to a sacred hilltop lake.",
                whyItIsSpecial = "Tranquil mist and towering pine groves away from bustling Mall Road.",
                category = "Eco Park & Pine Forest",
                location = "Lamahatta Village on Darjeeling-Kalimpong road",
                latitude = 27.0392,
                longitude = 88.3583,
                entryFee = "₹20",
                trekDistance = "1 km steep uphill walking trail",
                crowdLevel = "Low",
                difficulty = "Easy to Moderate"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "First Flush Darjeeling Tea & Nepalese Momos / Thukpa",
                    isVegetarian = true,
                    description = "Delicate amber muscatel tea paired with piping hot steamed dumplings and spicy red chili-tomato chutney.",
                    popularAt = "Glenary's Bakery & Keventer's Terrace",
                    priceRange = "₹150 - ₹300"
                )
            )
        ),
        stays = listOf(
            Accommodation(
                id = "stay-windamere-hotel",
                name = "Windamere Hotel (Historic Heritage)",
                category = "Colonial Heritage",
                pricePerNight = 7500,
                rating = 4.8f,
                amenities = listOf("Colonial Fireplaces", "Traditional Afternoon High Tea", "Kanchenjunga Views")
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Siliguri" to 65, "Bagdogra" to 70, "Kolkata" to 615),
            drivingTimes = mapOf("Siliguri" to "3 Hours via Hill Cart Road / Rohini Road", "Bagdogra" to "3.5 Hours"),
            roadTripRoute = "Siliguri / Bagdogra -> Kurseong -> Ghum -> Darjeeling via NH 110.",
            nearestRailwayStation = "New Jalpaiguri Junction (NJP - 70 km, major broad-gauge railway junction)",
            nearestAirport = "Bagdogra International Airport (IXB - 70 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 2800,
            foodEstimatePerDay = 900,
            activitiesTotal = 1500,
            travelEstimate = 2500,
            totalEstimateMin = 7700,
            totalEstimateMax = 18000
        ),
        seasons = RegionalSeasonalHelper.createHighAltitudeSeasons("wb-darjeeling")
    )

    val sundarbans = Destination(
        id = "wb-sundarbans",
        name = "Sundarbans National Park",
        state = "West Bengal",
        stateCode = "WB",
        district = "South 24 Parganas",
        latitude = 21.9497,
        longitude = 88.8999,
        tagline = "World's largest halophytic mangrove forest & UNESCO sanctuary of the swimming Royal Bengal Tiger",
        description = "Spanning the delta formed by the Ganges, Brahmaputra, and Meghna rivers into the Bay of Bengal, the Sundarbans is a UNESCO World Heritage Biosphere. It is navigated entirely by motorized wooden riverboats through tidal waterways, home to swimming Royal Bengal tigers, saltwater crocodiles, and chital spotted deer.",
        shortDescription = "World's largest mangrove delta navigated by boat safaris for Bengal tigers",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "Sea level",
        destinationTypes = listOf("UNESCO World Heritage", "Mangrove", "Wildlife Safari", "Boat Cruise", "Tigers"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "November to March (Pleasant weather, crocodiles sunbathing on mudflats)",
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.ADVENTURE, TravelCategory.NATURE),
        attractions = listOf(
            Attraction(
                id = "sajna-khali-watchtower",
                destinationId = "wb-sundarbans",
                name = "Sajnekhali Watchtower & Mangrove Interpretation Centre",
                description = "Chief forest department complex and watchtower offering views of sweet-water ponds where tigers, monitor lizards, and egrets gather.",
                category = "Wildlife Watchtower & Museum",
                latitude = 22.1158,
                longitude = 88.7694,
                entryFeeAdult = "₹60 for Indians, Forest Boat entry ₹400-500",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                insiderTip = "Keep binoculars ready to spot kingfishers (Sundarbans has 8 distinct species)."
            ),
            Attraction(
                id = "dobanki-canopy-walk",
                destinationId = "wb-sundarbans",
                name = "Dobanki Canopy Walk",
                description = "Half-kilometer elevated netted walkway standing 20 feet above the mangrove forest floor, enabling safe walks deep inside tiger territory.",
                category = "Canopy Walkway",
                latitude = 21.9867,
                longitude = 88.7500,
                entryFeeAdult = "Included in park permit",
                recommendedDurationMinutes = 60,
                familyFriendly = true,
                photographyAllowed = true
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-netidhopani-ruins",
                destinationId = "wb-sundarbans",
                name = "Netidhopani 400-Year-Old Temple Watchtower",
                description = "Remote historical watchtower overlooking the ruins of a 400-year-old Shiva temple, associated with the folklore of Behula-Lakhindar.",
                whyItIsSpecial = "Only a limited number of safari boats are granted daily entry permits to this protected deep core zone.",
                category = "Historical Watchtower",
                location = "Deep core forest zone, reachable by full-day boat cruise",
                latitude = 21.8900,
                longitude = 88.7800,
                crowdLevel = "Low",
                difficulty = "Boat accessible only"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Bhetki Macher Paturi & Pure Wild Mangrove Honey",
                    isVegetarian = false,
                    description = "Fresh barramundi fish marinated in mustard-poppy paste, wrapped in banana leaf and steam-cooked on the boat.",
                    popularAt = "Boat Cruise kitchens & Eco-resorts",
                    priceRange = "₹300 - ₹500"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Kolkata" to 100),
            drivingTimes = mapOf("Kolkata" to "3 Hours drive to Godkhali boat jetty"),
            roadTripRoute = "Kolkata (Science City) -> Basanti Highway -> Canning -> Godkhali Jetty (where road ends and boat safari begins).",
            nearestRailwayStation = "Canning Railway Station (CAN - 30 km from Godkhali jetty, connected by local trains from Sealdah)",
            nearestAirport = "Kolkata Netaji Subhash Chandra Bose International Airport (CCU - 110 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 3200,
            foodEstimatePerDay = 1000,
            activitiesTotal = 2500,
            travelEstimate = 2000,
            totalEstimateMin = 8700,
            totalEstimateMax = 18000
        ),
        seasons = RegionalSeasonalHelper.createCoastalSeasons("wb-sundarbans")
    )

    val destinations: List<Destination> = listOf(darjeeling, sundarbans)
}
