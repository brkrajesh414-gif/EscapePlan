package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.HiddenPlace
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ErrorBanner
import com.example.ui.components.LoadingShimmer
import com.example.ui.viewmodel.HiddenPlacesViewModel

@Composable
fun HomeScreen(
    onPlace: (String) -> Unit,
    onMap: () -> Unit,
    onCategories: () -> Unit,
    model: HiddenPlacesViewModel = viewModel()
) {
    val state by model.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Discover India", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.SemiBold)
            Text("108 lesser-known places across all states and union territories", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(
                value = state.query,
                onValueChange = model::search,
                placeholder = { Text("Search places, food or districts") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = { if (state.query.isNotEmpty()) IconButton(onClick = { model.search("") }) { Icon(Icons.Default.Clear, "Clear") } },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onMap) { Icon(Icons.Default.Map, null); Text(" Map search") }
                TextButton(onClick = onCategories) { Text("Popular categories") }
            }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(state.category == null, { model.category(null) }, label = { Text("All") }) }
            items(state.categories, key = { it }) { category ->
                FilterChip(state.category == category, { model.category(category) }, label = { Text(category) })
            }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(state.stateOrUt == null, { model.region(null) }, label = { Text("All India") }) }
            items(state.regions, key = { it }) { region ->
                FilterChip(state.stateOrUt == region, { model.region(region) }, label = { Text(region) })
            }
        }
        when {
            state.loading -> LoadingShimmer()
            state.error != null -> ErrorBanner(requireNotNull(state.error), model::reload, Modifier.padding(20.dp))
            state.filtered.isEmpty() -> EmptyStateView("No matching places", "Try a different name, state or category.")
            else -> LazyColumn(
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(state.filtered, key = { it.id }) { place -> HiddenPlaceCard(place) { onPlace(place.id) } }
            }
        }
    }
}

@Composable
private fun HiddenPlaceCard(place: HiddenPlace, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(place.name, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                    Text("${place.districtOrBase}, ${place.stateOrUt}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(Icons.Default.LocationOn, null, tint = MaterialTheme.colorScheme.primary)
            }
            Text(place.categories.joinToString(" · "), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
            Text(place.whyVisit, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("${place.bestSeason}  ·  ${place.suggestedTime}  ·  ${place.difficulty}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
