package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.HiddenPlace
import com.example.data.repository.HiddenPlacesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HiddenPlacesState(
    val loading: Boolean = true,
    val places: List<HiddenPlace> = emptyList(),
    val query: String = "",
    val category: String? = null,
    val stateOrUt: String? = null,
    val error: String? = null
) {
    val categories: List<String> get() = places.flatMap { it.categories }.distinct().sorted()
    val regions: List<String> get() = places.map { it.stateOrUt }.distinct().sorted()
    val filtered: List<HiddenPlace> get() {
        val search = query.trim()
        return places.filter { place ->
            (category == null || category in place.categories) &&
                (stateOrUt == null || stateOrUt == place.stateOrUt) &&
                (search.isBlank() || listOf(place.name, place.stateOrUt, place.districtOrBase, place.whyVisit, place.foodToTry)
                    .any { it.contains(search, ignoreCase = true) })
        }
    }
}

class HiddenPlacesViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = HiddenPlacesRepository(application)
    private val mutable = MutableStateFlow(HiddenPlacesState())
    val state = mutable.asStateFlow()

    init { reload() }

    fun reload() {
        viewModelScope.launch {
            mutable.update { it.copy(loading = true, error = null) }
            repository.load().fold(
                onSuccess = { places -> mutable.update { it.copy(loading = false, places = places) } },
                onFailure = { error -> mutable.update { it.copy(loading = false, error = error.message ?: "Unable to load places") } }
            )
        }
    }

    fun search(value: String) { mutable.update { it.copy(query = value) } }
    fun category(value: String?) { mutable.update { it.copy(category = value) } }
    fun region(value: String?) { mutable.update { it.copy(stateOrUt = value) } }
}
