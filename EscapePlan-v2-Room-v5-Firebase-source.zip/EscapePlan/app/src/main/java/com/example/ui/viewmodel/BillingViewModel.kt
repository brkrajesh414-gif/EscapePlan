package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.auth.AuthRepository
import com.example.data.repository.BillingRepository
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect

class BillingViewModel(application: Application) : AndroidViewModel(application) {
    val repository = BillingRepository(application, viewModelScope)
    val state = repository.state
    init {
        repository.connect()
        viewModelScope.launch { AuthRepository(application).user.collect { repository.accountChanged(it.getOrNull()?.uid) } }
    }
    override fun onCleared() { repository.close(); super.onCleared() }
}
