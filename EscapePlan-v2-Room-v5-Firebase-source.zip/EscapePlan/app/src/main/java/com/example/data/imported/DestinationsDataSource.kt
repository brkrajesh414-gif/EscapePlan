package com.example.data.imported

import com.example.R
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.RestaurantItem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo

object DestinationsDataSource {

    val supportedOriginCities = listOf(
        "Hyderabad",
        "Bengaluru",
        "Chennai",
        "Kochi",
        "Coimbatore",
        "Visakhapatnam",
        "Mumbai",
        "Delhi",
        "Pune",
        "Kolkata"
    )

    private val baseDestinations: List<Destination> = listOf(
        Destination(
            id = "araku-valley",
            name = "Araku Valley",
            state = "Andhra Pradesh",
            latitude = 18.3273,
            longitude = 82.8775,
            tagline = "Misty Coffee Plantations & Eastern Ghats",
            description = "A serene hill station wrapped in mist, evergreen forests, and organic coffee estates. Famous for prehistoric Borra Caves, gushing waterfalls, indigenous tribal culture, and the scenic Vistadome railway through 58 mountain tunnels.",
            rating = 4.6f,
            reviewCount = 1840,
            coverResId = null,
            categories = listOf(
                TravelCategory.MOUNTAINS,
                TravelCategory.NATURE,
                TravelCategory.COUPLES,
                TravelCategory.ROAD_TRIPS
            ),
            bestTime = BestTimeInfo(
                bestMonths = "October to February",
                weatherSummary = "Chilly mornings with rolling fog and crisp sunny afternoons",
                peakSeason = "December – January (tribal dance & coffee bloom)",
                offSeason = "April – June (warm summer)",
                expectedCrowd = "Moderate to Peaceful",
                temperatureRange = "12°C – 25°C",
                suggestedDuration = "2–3 Days"
            ),
            attractions = listOf(
                Attraction(
                    id = "borra-caves",
                    name = "Borra Caves",
                    category = "Natural Wonder",
                    distanceKmFromCenter = 36.0f,
                    distanceToNextAttraction = "15 km to Katiki Waterfalls",
                    suggestedDurationHours = "2 Hours",
                    description = "Million-year-old limestone caves featuring majestic stalactites, stalagmites, and vibrant atmospheric lighting in deep chambers.",
                    highlight = "Naturally formed Shiva Lingam & deep karstic formations",
                    entryFee = "₹80 / person"
                ),
                Attraction(
                    id = "katiki-waterfalls",
                    name = "Katiki Waterfalls",
                    category = "Waterfall & Trek",
                    distanceKmFromCenter = 39.0f,
                    distanceToNextAttraction = "35 km back to Araku Town",
                    suggestedDurationHours = "2.5 Hours",
                    description = "A 50-foot cascading waterfall accessed via exciting open-top 4x4 jeep safari and a short scenic jungle trek.",
                    highlight = "Cool plunge pool & roadside bamboo chicken stalls",
                    entryFee = "Jeep hire: ~₹300/person"
                ),
                Attraction(
                    id = "coffee-museum",
                    name = "Araku Coffee Museum",
                    category = "Heritage & Food",
                    distanceKmFromCenter = 1.0f,
                    distanceToNextAttraction = "1.5 km to Tribal Museum",
                    suggestedDurationHours = "1 Hour",
                    description = "Showcases the history of organic tribal coffee cultivation with live roasting and freshly brewed Arabica tastings.",
                    highlight = "Freshly roasted coffee chocolates & espresso shots",
                    entryFee = "₹20 / person"
                ),
                Attraction(
                    id = "tribal-museum",
                    name = "Araku Tribal Museum",
                    category = "Culture & Heritage",
                    distanceKmFromCenter = 1.5f,
                    distanceToNextAttraction = "14 km to Chaparai",
                    suggestedDurationHours = "1.5 Hours",
                    description = "Preserves the customs, clay lifestyle dioramas, handicrafts, and archery traditions of Eastern Ghats indigenous tribes.",
                    highlight = "Evening Dhimsa tribal dance performances",
                    entryFee = "₹40 / person"
                ),
                Attraction(
                    id = "chaparai",
                    name = "Chaparai Water Cascades",
                    category = "Scenic Picnic Spot",
                    distanceKmFromCenter = 15.0f,
                    distanceToNextAttraction = "20 km to Galikonda View Point",
                    suggestedDurationHours = "2 Hours",
                    description = "Smooth sloping rocky waterbeds surrounded by dense pine forests, ideal for wading in clear stream water.",
                    highlight = "Gentle natural water slide on smooth rocks",
                    entryFee = "₹10 / person"
                ),
                Attraction(
                    id = "galikonda-viewpoint",
                    name = "Galikonda View Point",
                    category = "Viewpoint",
                    distanceKmFromCenter = 20.0f,
                    distanceToNextAttraction = "On route to Vizag",
                    suggestedDurationHours = "45 Mins",
                    description = "Highest point in the Visakhapatnam hills at 1,500m elevation with panoramic valley views of coffee valleys.",
                    highlight = "Sunrise cloud bed and local hot ginger tea stalls",
                    entryFee = "Free"
                )
            ),
            stays = listOf(
                Accommodation(
                    id = "haritha-resort",
                    name = "Haritha Hill Resort (APTDC)",
                    type = "Hill Resort",
                    pricePerNight = 2800,
                    rating = 4.3f,
                    reviewsCount = 420,
                    distanceFromAttractions = "0.8 km from Coffee Museum",
                    amenities = listOf("Cottage View", "Free Parking", "In-house Dining", "Lawn"),
                    highlights = "State-run reliable resort nestled amidst lush trees"
                ),
                Accommodation(
                    id = "rahul-resorts",
                    name = "Rahul Valley View Resort",
                    type = "Resort",
                    pricePerNight = 3200,
                    rating = 4.2f,
                    reviewsCount = 210,
                    distanceFromAttractions = "2 km from town center",
                    amenities = listOf("Balcony View", "Bonfire", "Room Service", "Wi-Fi"),
                    highlights = "Excellent balcony valley views and campfire evenings"
                ),
                Accommodation(
                    id = "nature-nest-homestay",
                    name = "Nature's Nest Coffee Homestay",
                    type = "Homestay",
                    pricePerNight = 1900,
                    rating = 4.5f,
                    reviewsCount = 135,
                    distanceFromAttractions = "4 km from town center",
                    amenities = listOf("Home-cooked Meals", "Plantation Tour", "Pet Friendly"),
                    highlights = "Stay directly on a working organic coffee plantation"
                )
            ),
            foodGuide = FoodGuide(
                localSpecialties = listOf(
                    FoodItem(
                        name = "Bamboo Chicken (Bongu Kodi)",
                        isVegetarian = false,
                        description = "Tender chicken marinated in crushed green chillies, ginger-garlic and spices, stuffed inside raw green bamboo tubes and roasted over wood embers with zero oil.",
                        popularAt = "Near Katiki falls and Chaparai entry"
                    ),
                    FoodItem(
                        name = "Araku Arabica Coffee",
                        isVegetarian = true,
                        description = "Single-origin shade-grown organic coffee hand-picked by local Adivasi farmers with notes of chocolate and citrus.",
                        popularAt = "Araku Coffee Museum cafe"
                    ),
                    FoodItem(
                        name = "Madugula Halwa",
                        isVegetarian = true,
                        description = "Century-old heritage sweet made from wheat milk, pure ghee, and roasted cashew nuts that melts in your mouth.",
                        popularAt = "Highway pit-stops near Chodavaram"
                    ),
                    FoodItem(
                        name = "Bamboo Veg Biryani",
                        isVegetarian = true,
                        description = "Fragrant spiced basmati rice and vegetables cooked inside steamed bamboo culm.",
                        popularAt = "Tribal food huts around Chaparai"
                    )
                ),
                restaurants = listOf(
                    RestaurantItem(
                        name = "Vasu Bamboo Kitchen",
                        cuisine = "Andhra & Tribal Specialties",
                        rating = 4.5f,
                        isVegFriendly = true,
                        signatureDish = "Authentic Bongu Chicken & Ragi Mudda",
                        priceForTwo = "₹500",
                        distance = "1.2 km from town center"
                    ),
                    RestaurantItem(
                        name = "Coffee Museum Cafe",
                        cuisine = "Cafe & Beverages",
                        rating = 4.6f,
                        isVegFriendly = true,
                        signatureDish = "Hot Artisan Cappuccino & Coffee Truffles",
                        priceForTwo = "₹250",
                        distance = "Inside Coffee Museum"
                    ),
                    RestaurantItem(
                        name = "Haritha Restaurant",
                        cuisine = "South Indian Thali",
                        rating = 4.0f,
                        isVegFriendly = true,
                        signatureDish = "Traditional Andhra Veg Bhojanam",
                        priceForTwo = "₹400",
                        distance = "Near APTDC Resort"
                    )
                )
            ),
            travelRoute = TravelRouteInfo(
                originDistances = mapOf(
                    "Hyderabad" to 640,
                    "Visakhapatnam" to 115,
                    "Bengaluru" to 890,
                    "Chennai" to 750,
                    "Mumbai" to 1250,
                    "Delhi" to 1750,
                    "Kolkata" to 920,
                    "Pune" to 1180
                ),
                drivingTimes = mapOf(
                    "Hyderabad" to "12h 30m drive",
                    "Visakhapatnam" to "3h 15m scenic drive",
                    "Bengaluru" to "17h drive",
                    "Chennai" to "14h drive",
                    "Mumbai" to "23h drive",
                    "Delhi" to "32h drive",
                    "Kolkata" to "18h drive",
                    "Pune" to "22h drive"
                ),
                roadTripRoute = "Via NH16 from Vizag -> Srungavarapukota (S.Kota) -> Tyda -> Araku. Excellent tarmac with thrilling 45 km mountain ghat curves.",
                tollAndParkingNotes = "Toll approx ₹120 on highway; parking ₹30–₹50 at major tourist attractions.",
                nearestRailwayStation = "Araku (ARK) or Visakhapatnam (VSKP - 115 km)",
                nearestAirport = "Visakhapatnam International Airport (VTZ - 110 km)",
                busTrainFlightOptions = "Best Option: Take overnight train/flight to Vizag, then take the morning 08551 Vistadome Glass-roof train directly to Araku through 58 mountain tunnels!"
            ),
            budget = BudgetBreakdown(
                stayEstimatePerNight = 2500,
                foodEstimatePerDay = 1800,
                activitiesTotal = 1500,
                travelEstimate = 5500,
                totalEstimateMin = 14000,
                totalEstimateMax = 18000
            )
        )
    )

    private val _customDestinations = mutableListOf<Destination>()

    val destinations: List<Destination>
        get() = (baseDestinations +
                 RegionalDestinationsData.allRegionalDestinations +
                 com.example.data.imported.karnataka.KarnatakaDestinationsData.allDestinations +
                 com.example.data.imported.tamilnadu.TamilNaduDestinationsData.allDestinations +
                 com.example.data.imported.kerala.KeralaDestinationsData.allDestinations +
                 com.example.data.imported.maharashtra.MaharashtraDestinationsData.destinations +
                 com.example.data.imported.goa.GoaDestinationsData.destinations +
                 com.example.data.imported.andhrapradesh.AndhraPradeshDestinationsData.destinations +
                 com.example.data.imported.rajasthan.RajasthanDestinationsData.destinations +
                 com.example.data.imported.himachal.HimachalDestinationsData.destinations +
                 com.example.data.imported.uttarakhand.UttarakhandDestinationsData.destinations +
                 com.example.data.imported.madhyapradesh.MadhyaPradeshDestinationsData.destinations +
                 com.example.data.imported.odisha.OdishaDestinationsData.destinations +
                 com.example.data.imported.westbengal.WestBengalDestinationsData.destinations +
                 com.example.data.imported.gujarat.GujaratDestinationsData.destinations +
                 com.example.data.imported.northeast.NorthEastDestinationsData.destinations +
                 com.example.data.imported.bihar.BiharDestinationsData.destinations +
                 com.example.data.imported.telangana.TelanganaDestinationsData.destinations +
                 com.example.data.imported.unionterritories.UnionTerritoriesDestinationsData.destinations +
                 _customDestinations).distinctBy { it.id }

    fun addCustomDestination(destination: Destination) {
        _customDestinations.removeAll { it.id == destination.id }
        _customDestinations.add(0, destination)
    }

    fun importCsvDestinations(csvText: String): Int {
        val imported = com.example.data.engine.DataImportEngine.importFromCsv(csvText)
        for (dest in imported) {
            addCustomDestination(dest)
        }
        return imported.size
    }

    fun getDestinationById(id: String): Destination? {
        return destinations.find { it.id == id } ?: destinations.firstOrNull()
    }

    fun getDestinationsByCategory(category: TravelCategory): List<Destination> {
        return destinations.filter { it.categories.contains(category) }
    }

    fun getDestinationsByState(state: String): List<Destination> {
        if (state.isBlank() || state.equals("All", ignoreCase = true)) return destinations
        return destinations.filter { it.state.contains(state, ignoreCase = true) }
    }

    fun getDestinationsByDiscoveryLevel(level: com.example.data.model.DiscoveryLevel): List<Destination> {
        return destinations.filter { it.discoveryLevel == level }
    }

    fun getAllHiddenGems(): List<com.example.data.model.HiddenGem> {
        return destinations.flatMap { it.hiddenGems }
    }

    fun getAvailableStates(): List<String> {
        val statesFromDest = destinations.map { it.state }
        val allMasterStates = com.example.data.model.IndiaStatesMaster.getAllNames()
        val combined = (statesFromDest + allMasterStates).distinct().sorted()
        return listOf("All") + combined
    }

    fun searchDestinations(query: String): List<Destination> {
        return destinations.filter { it.name.contains(query, ignoreCase = true) || it.state.contains(query, ignoreCase = true) }
    }
}
