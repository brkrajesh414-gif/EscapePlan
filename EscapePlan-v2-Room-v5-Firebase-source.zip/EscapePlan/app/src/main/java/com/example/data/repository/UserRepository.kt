package com.example.data.repository

import com.example.core.operation
import com.example.data.auth.AuthUser
import com.example.data.local.UserProfileDao
import com.example.data.local.UserProfileEntity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class UserRepository(private val dao: UserProfileDao) {
    private val preferenceChoices = setOf(
        "Budget:Budget", "Budget:Comfort", "Budget:Premium",
        "Transport:Flexible", "Transport:Public transport", "Transport:Car", "Transport:Bike", "Transport:Flight",
        "Travel:Flexible", "Travel:Solo", "Travel:Couple", "Travel:Family", "Travel:Friends", "Travel:Adventure",
        "Food:No preference", "Food:Vegetarian", "Food:Non-vegetarian", "Food:Vegan", "Food:Local cuisine",
        "Budget", "Solo", "Adventure", "Family"
    )
    fun observe(uid: String): Flow<UserProfileEntity?> = dao.observe(uid)

    private fun requireOwner(uid: String) {
        check(FirebaseAuth.getInstance().currentUser?.uid == uid) { "Please sign in again." }
    }

    suspend fun synchronize(user: AuthUser): Result<Unit> = operation {
        requireOwner(user.uid)
        val local = dao.get(user.uid)
        if (local?.pendingSync == true) {
            push(local).getOrThrow()
        } else {
            val snapshot = FirebaseFirestore.getInstance().collection("profiles").document(user.uid).get().await()
            requireOwner(user.uid)
            val profile = UserProfileEntity(user.uid, snapshot.getString("name") ?: user.name,
                user.email, user.avatarUrl,
                Json.encodeToString((snapshot.get("preferences") as? List<*>)?.filterIsInstance<String>().orEmpty()),
                System.currentTimeMillis(), false)
            dao.upsert(profile)
        }
    }

    suspend fun save(user: AuthUser, name: String, preferences: Set<String>): Result<Unit> = operation {
        requireOwner(user.uid)
        require(name.length <= 100 && preferences.size <= 4 && preferences.all { it in preferenceChoices }) { "Invalid profile preferences" }
        val profile = UserProfileEntity(user.uid, name.trim(), user.email, user.avatarUrl,
            Json.encodeToString(preferences.toList()), System.currentTimeMillis(), true)
        dao.upsert(profile)
        push(profile).getOrThrow()
    }

    private suspend fun push(profile: UserProfileEntity): Result<Unit> = operation {
        requireOwner(profile.uid)
        FirebaseFirestore.getInstance().collection("profiles").document(profile.uid).set(mapOf(
            "name" to profile.name, "preferences" to Json.decodeFromString<List<String>>(profile.preferencesJson)
        )).await()
        requireOwner(profile.uid)
        if (dao.get(profile.uid)?.updatedAt == profile.updatedAt) dao.upsert(profile.copy(pendingSync = false))
    }
}
