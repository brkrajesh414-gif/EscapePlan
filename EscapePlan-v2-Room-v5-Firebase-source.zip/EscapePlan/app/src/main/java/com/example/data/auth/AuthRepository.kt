package com.example.data.auth

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.example.BuildConfig
import com.example.core.operation
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class AuthUser(val uid: String, val name: String, val email: String, val avatarUrl: String)

class AuthRepository(context: Context) {
    private val credentials = CredentialManager.create(context)
    private val sessions = EncryptedSessionStore(context.applicationContext)
    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()

    val user: Flow<Result<AuthUser?>> = callbackFlow {
        val instance = try { auth } catch (error: Exception) {
            trySend(Result.failure(IllegalStateException("Firebase is not configured. Add google-services.json.", error)))
            close()
            return@callbackFlow
        }
        val listener = FirebaseAuth.AuthStateListener { firebase ->
            val current = firebase.currentUser
            trySend(Result.success(current?.let { AuthUser(it.uid, it.displayName.orEmpty(), it.email.orEmpty(), it.photoUrl?.toString().orEmpty()) }))
        }
        instance.addAuthStateListener(listener)
        awaitClose { instance.removeAuthStateListener(listener) }
    }

    suspend fun email(email: String, password: String, register: Boolean): Result<Unit> = operation {
        require(email.isNotBlank() && password.length >= 6) { "Enter an email and a password of at least six characters." }
        val result = if (register) auth.createUserWithEmailAndPassword(email.trim(), password).await()
            else auth.signInWithEmailAndPassword(email.trim(), password).await()
        sessions.saveUid(result.user?.uid)
    }

    suspend fun google(activity: Activity): Result<Unit> = operation {
        require(BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()) { "Google sign-in client ID is not configured." }
        val option = GetGoogleIdOption.Builder().setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
            .setFilterByAuthorizedAccounts(false).setAutoSelectEnabled(false).build()
        val response = credentials.getCredential(activity, GetCredentialRequest.Builder().addCredentialOption(option).build())
        val credential = response.credential
        require(credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) { "Unsupported sign-in credential" }
        val idToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val result = auth.signInWithCredential(GoogleAuthProvider.getCredential(idToken, null)).await()
        sessions.saveUid(result.user?.uid)
    }

    suspend fun resetPassword(email: String): Result<Unit> = operation {
        require(email.isNotBlank()) { "Enter your email first." }
        auth.sendPasswordResetEmail(email.trim()).await()
    }

    suspend fun signOut(): Result<Unit> = operation {
        auth.signOut()
        sessions.saveUid(null)
        credentials.clearCredentialState(ClearCredentialStateRequest())
    }
}
