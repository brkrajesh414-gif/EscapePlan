package com.example.data.imported.odisha

import com.example.data.imported.common.RegionalSeasonalHelper
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.DiscoveryLevel
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.HiddenGem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo

object OdishaDestinationsData {

    val puriKonark = Destination(
        id = "odisha-puri-konark",
        name = "Puri & Konark Sun Temple",
        state = "Odisha",
        stateCode = "OD",
        district = "Puri",
        latitude = 19.8135,
        longitude = 85.8312,
        tagline = "Sacred coastal Char Dham, UNESCO 13th-century Sun Temple chariot, and Blue Flag Golden Beach",
        description = "One of India's four sacred Char Dham pilgrimage sites on the Bay of Bengal, Puri is venerated for the 12th-century Jagannath Temple, the legendary Ratha Yatra, serene Golden Beach (certified Blue Flag), and the nearby UNESCO architectural wonder: the monumental Sun Temple at Konark designed as a colossal 24-wheeled chariot of Surya.",
        shortDescription = "Sacred coastal Char Dham and UNESCO Sun Temple architectural marvel",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 4,
        altitude = "Sea level",
        destinationTypes = listOf("Spiritual", "UNESCO World Heritage", "Beach", "Culture", "Architecture"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "October to March",
        categories = listOf(TravelCategory.TEMPLES, TravelCategory.HERITAGE, TravelCategory.BEACHES),
        attractions = listOf(
            Attraction(
                id = "jagannath-temple-puri",
                destinationId = "odisha-puri-konark",
                name = "Shree Jagannath Temple",
                description = "Monumental 12th-century Kalinga-style temple dedicated to Lord Jagannath, Balabhadra, and Subhadra with the world's largest traditional mega-kitchen (Ananda Bazar).",
                category = "Sacred Char Dham Shrine",
                latitude = 19.8049,
                longitude = 85.8179,
                entryFeeAdult = "Free (Only Indian Hindus permitted in inner sanctum per ancient tradition)",
                openingTime = "05:00",
                closingTime = "23:00",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                insiderTip = "Taste the divine Mahaprasad cooked in seven earthen pots stacked over single wood fires in Ananda Bazar between 1:00 PM and 3:00 PM."
            ),
            Attraction(
                id = "konark-sun-temple",
                destinationId = "odisha-puri-konark",
                name = "Konark Sun Temple (Black Pagoda)",
                description = "13th-century UNESCO World Heritage architectural wonder built by King Narasimhadeva I, shaped as a colossal sun chariot with 24 carved sundial wheels pulled by 7 galloping horses.",
                category = "UNESCO World Heritage Site",
                latitude = 19.8876,
                longitude = 86.0945,
                entryFeeAdult = "₹40 for Indians, ₹600 Foreigners",
                openingTime = "06:00",
                closingTime = "18:00",
                recommendedDurationMinutes = 150,
                familyFriendly = true,
                photographyAllowed = true,
                insiderTip = "Hire a certified ASI guide to explain the intricate sundial calculations etched into the stone wheels."
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-raghurajpur-heritage-crafts",
                destinationId = "odisha-puri-konark",
                name = "Raghurajpur Heritage Crafts Village",
                description = "Picturesque heritage village where every single household practices Pattachitra palm-leaf scroll painting, Tussar silk art, and Gotipua dance.",
                whyItIsSpecial = "Directly observe master artisans crafting palm-leaf paintings and purchase directly from the source.",
                category = "Heritage Artisan Village",
                location = "14 km from Puri on the banks of River Bhargavi",
                latitude = 19.8860,
                longitude = 85.8340,
                crowdLevel = "Low",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Chhena Poda (Caramelized Cheese Dessert)",
                    isVegetarian = true,
                    description = "Odisha's signature baked dessert made of fresh cottage cheese, sugar, and cardamom, baked until crusted caramel brown.",
                    popularAt = "Bapuji Chhena Poda & Nimapada Sweet Outlets",
                    priceRange = "₹80 - ₹150"
                ),
                FoodItem(
                    name = "Khaja & Abadha Mahaprasad",
                    isVegetarian = true,
                    description = "Flaky layered crisp pastry dipped in sweet syrup, prepared as holy offering in the temple kitchen.",
                    popularAt = "Puri Bada Danda & Ananda Bazar",
                    priceRange = "₹100 - ₹200"
                )
            )
        ),
        stays = listOf(
            Accommodation(
                id = "stay-puri-mayfair",
                name = "Mayfair Waves Puri",
                category = "Beachfront Luxury Resort",
                pricePerNight = 6500,
                rating = 4.8f,
                amenities = listOf("Direct Beach Access", "Swimming Pool", "Seafood Dining", "Spa")
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Bhubaneswar" to 60, "Kolkata" to 500, "Visakhapatnam" to 440, "Hyderabad" to 850),
            drivingTimes = mapOf("Bhubaneswar" to "1.5 Hours", "Visakhapatnam" to "8 Hours"),
            roadTripRoute = "Bhubaneswar -> Pipili (Applique craft village) -> Puri -> Marine Drive to Konark (scenic 35 km coastal highway).",
            nearestRailwayStation = "Puri Railway Station (PURI - 2 km, connects directly to all major Indian cities)",
            nearestAirport = "Bhubaneswar Biju Patnaik International Airport (BBI - 60 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 2500,
            foodEstimatePerDay = 850,
            activitiesTotal = 800,
            travelEstimate = 1800,
            totalEstimateMin = 5950,
            totalEstimateMax = 14000
        ),
        seasons = RegionalSeasonalHelper.createCoastalSeasons("odisha-puri-konark")
    )

    val chilikaLake = Destination(
        id = "odisha-chilika-lake",
        name = "Chilika Lake & Mangalajodi",
        state = "Odisha",
        stateCode = "OD",
        district = "Khordha & Puri",
        latitude = 19.7167,
        longitude = 85.3167,
        tagline = "Asia's largest brackish water lagoon, paradise of 160+ migratory bird species, and rare Irrawaddy dolphins",
        description = "Spanning over 1,100 sq km along the Bay of Bengal, Chilika Lake is a Ramsar Wetland of global renown. It is home to endangered Irrawaddy dolphins at Satapada and serves as the winter haven for over a million migratory birds flying from Siberia and Central Asia to Mangalajodi marshlands.",
        shortDescription = "Asia's largest lagoon with Irrawaddy dolphins and world-class bird sanctuary",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        altitude = "Sea level",
        destinationTypes = listOf("Lagoon", "Wildlife", "Bird Sanctuary", "Nature", "Boating"),
        discoveryLevel = DiscoveryLevel.POPULAR,
        bestMonths = "November to February (Peak migratory bird season)",
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.LAKES, TravelCategory.NATURE),
        attractions = listOf(
            Attraction(
                id = "satapada-dolphin-spotting",
                destinationId = "odisha-chilika-lake",
                name = "Satapada Dolphin Watching & Sea Mouth Island",
                description = "Motorboat cruise into the outer lagoon where freshwater meets the sea, spotting shy Irrawaddy dolphins breaching the waves.",
                category = "Marine Wildlife / Boat Cruise",
                latitude = 19.6744,
                longitude = 85.4389,
                entryFeeAdult = "₹1,200 - ₹2,500 per boat (OTDC regulated rates)",
                recommendedDurationMinutes = 180,
                familyFriendly = true,
                insiderTip = "Take an early morning boat (07:00 AM) when the water is calm for the highest chance of dolphin sightings."
            ),
            Attraction(
                id = "mangalajodi-bird-marsh",
                destinationId = "odisha-chilika-lake",
                name = "Mangalajodi Bird Eco-Reserve",
                description = "World-famous community conservation wetland where poachers turned protectors guide silent hand-paddled wooden boats through marshes teeming with rare birds.",
                category = "Bird Sanctuary / Eco-Tourism",
                latitude = 19.9142,
                longitude = 85.4261,
                entryFeeAdult = "₹1,200 per wooden boat with certified eco-guide",
                recommendedDurationMinutes = 150,
                familyFriendly = true,
                photographyAllowed = true,
                insiderTip = "Silent wooden canoes allow photographers to get within 5 meters of flamingos, purple swamphens, and migratory ducks without disturbing them."
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-kalijai-island",
                destinationId = "odisha-chilika-lake",
                name = "Kalijai Island Shrine",
                description = "Solitary temple island in the middle of the deep blue lake, honoring Goddess Kalijai, folklore guardian of Chilika fishermen.",
                whyItIsSpecial = "Serene boat cruise to an island surrounded by open blue waters and swooping seagulls.",
                category = "Island Shrine",
                location = "Center of Chilika Lake, reachable from Barkul",
                latitude = 19.6583,
                longitude = 85.2950,
                crowdLevel = "Low to Moderate",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Chilika Fresh Crab Roast & Tiger Prawn Curry",
                    isVegetarian = false,
                    description = "Freshly caught lagoon giant mud crabs cooked in mustard paste, garlic, and fresh green chilies.",
                    popularAt = "Chilika Dhaba at Barkul & Satapada Boat jetty",
                    priceRange = "₹350 - ₹600"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Bhubaneswar" to 100, "Puri" to 50, "Berhampur" to 95),
            drivingTimes = mapOf("Puri" to "1.5 Hours to Satapada", "Bhubaneswar" to "2 Hours to Barkul"),
            roadTripRoute = "NH 16 from Bhubaneswar towards Berhampur connects directly to Barkul on the western bank.",
            nearestRailwayStation = "Balugaon Railway Station (BALU - 5 km from Barkul) / Puri (PURI - 50 km from Satapada)",
            nearestAirport = "Bhubaneswar Biju Patnaik International Airport (BBI - 100 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 2200,
            foodEstimatePerDay = 800,
            activitiesTotal = 1500,
            travelEstimate = 1800,
            totalEstimateMin = 6300,
            totalEstimateMax = 12000
        ),
        seasons = RegionalSeasonalHelper.createCoastalSeasons("odisha-chilika-lake")
    )

    val destinations: List<Destination> = listOf(puriKonark, chilikaLake)
}
