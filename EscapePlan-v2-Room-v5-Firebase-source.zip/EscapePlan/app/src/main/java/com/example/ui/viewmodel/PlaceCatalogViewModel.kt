package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.PlaceCatalogEntry
import com.example.data.repository.PlaceCatalogRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PlaceCatalogState(
    val loading: Boolean = true,
    val entries: List<PlaceCatalogEntry> = emptyList(),
    val query: String = "",
    val category: String? = null,
    val error: String? = null
) {
    val categories: List<String> get() = entries.flatMap { it.categories }.distinct()
    val filtered: List<PlaceCatalogEntry> get() = entries.filter { entry ->
        (category == null || category in entry.categories) &&
            (entry.aliases + entry.name + entry.state.orEmpty()).any { it.contains(query.trim(), ignoreCase = true) }
    }
}

class PlaceCatalogViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PlaceCatalogRepository(application)
    private val mutable = MutableStateFlow(PlaceCatalogState())
    val state = mutable.asStateFlow()
    private var loadingJob: Job? = null

    init { reload() }

    fun reload() {
        loadingJob?.cancel()
        loadingJob = viewModelScope.launch {
            mutable.update { it.copy(loading = true, error = null) }
            repository.load().fold(
                onSuccess = { entries -> mutable.update { it.copy(loading = false, entries = entries) } },
                onFailure = { error -> mutable.update { it.copy(loading = false, error = error.message ?: "Unable to load places") } }
            )
        }
    }

    fun search(value: String) { mutable.update { it.copy(query = value) } }
    fun category(value: String?) { mutable.update { it.copy(category = value) } }
    fun guideId(entry: PlaceCatalogEntry): String? = repository.existingGuide(entry)?.id
}
