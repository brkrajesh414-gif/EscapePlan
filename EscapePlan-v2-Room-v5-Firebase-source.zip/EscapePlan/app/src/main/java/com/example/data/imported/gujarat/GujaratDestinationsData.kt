package com.example.data.imported.gujarat

import com.example.data.imported.common.RegionalSeasonalHelper
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.DiscoveryLevel
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.HiddenGem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo

object GujaratDestinationsData {

    val rannOfKutch = Destination(
        id = "gujarat-rann-of-kutch",
        name = "Great Rann of Kutch & Dhordo",
        state = "Gujarat",
        stateCode = "GJ",
        district = "Kutch",
        latitude = 23.8344,
        longitude = 69.8358,
        tagline = "The world's largest salt marsh desert: ethereal white flats, full moon magic, and vibrant Kutchi handicrafts",
        description = "Spanning over 7,500 sq km of the Thar Desert, the Great Rann of Kutch transforms from an underwater marsh during monsoon into an endless, blindingly white crystalline salt desert in winter. Celebrated during Rann Utsav with tent cities, camel safaris across salt flats under full moons, Rogan art, and Kutchi embroidery.",
        shortDescription = "Endless white salt desert glowing under full moons with rich Kutchi culture",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 4,
        altitude = "Sea level",
        destinationTypes = listOf("Desert", "Salt Flats", "Culture", "Full Moon", "Handicrafts"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "November to February (Rann Utsav, salt crust fully dried)",
        categories = listOf(TravelCategory.NATURE, TravelCategory.HERITAGE, TravelCategory.ROAD_TRIPS),
        attractions = listOf(
            Attraction(
                id = "white-rann-dhordo",
                destinationId = "gujarat-rann-of-kutch",
                name = "White Rann Salt Desert at Dhordo",
                description = "Breathtaking expanse of pure white salt crystals stretching to the horizon, where earth meets sky in a seamless mirage.",
                category = "Salt Desert Landscape",
                latitude = 23.8340,
                longitude = 69.8350,
                entryFeeAdult = "₹100 (Online permit required via Kutch Tourism)",
                recommendedDurationMinutes = 180,
                familyFriendly = true,
                insiderTip = "Plan visits around the Full Moon nights (Purnima) when the entire desert glows silvery white under moonlight."
            ),
            Attraction(
                id = "kalo-dungar-black-hill",
                destinationId = "gujarat-rann-of-kutch",
                name = "Kalo Dungar (Black Hill - 462 m)",
                description = "Highest point in Kutch offering a panoramic vista of the entire white desert curving into the horizon, home to the 400-year-old Dattatreya Temple.",
                category = "Desert Viewpoint & Temple",
                latitude = 23.8967,
                longitude = 69.8167,
                entryFeeAdult = "Free",
                recommendedDurationMinutes = 90,
                familyFriendly = true,
                photographyAllowed = true
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-nirona-rogan-art",
                destinationId = "gujarat-rann-of-kutch",
                name = "Nirona Village (Rogan Art & Copper Bells)",
                description = "Artisan village where the Khatri family preserves the 300-year-old Persian Rogan art (painting castor oil paste using a thin metal stylus), alongside Luhar copper bell makers.",
                whyItIsSpecial = "The only place in the world where true castor-oil Rogan painting is still practiced by hand.",
                category = "Heritage Craft Village",
                location = "Nirona, 40 km from Bhuj",
                latitude = 23.4000,
                longitude = 69.5800,
                crowdLevel = "Low",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Authentic Kutchi Thali (Bajra Rotla with Ringna No Olo & Makhan)",
                    isVegetarian = true,
                    description = "Clay oven pearl millet flatbread served with charred spiced eggplant mash, fresh white butter, and jaggery.",
                    popularAt = "Traditional Bhungas in Dhordo & Hodka villages",
                    priceRange = "₹200 - ₹350"
                )
            )
        ),
        stays = listOf(
            Accommodation(
                id = "stay-hodka-resort",
                name = "Shaam-e-Sarhad Village Resort (Hodka)",
                category = "Eco Traditional Bhunga",
                pricePerNight = 4500,
                rating = 4.7f,
                amenities = listOf("Traditional Mud Bhungas", "Kutchi Folk Music", "Local Organic Food")
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Bhuj" to 85, "Ahmedabad" to 415, "Rajkot" to 315),
            drivingTimes = mapOf("Bhuj" to "1.5 Hours", "Ahmedabad" to "7.5 Hours"),
            roadTripRoute = "Ahmedabad -> Viramgam -> Dhrangadhra -> Bhachau -> Bhuj -> Bhirandiyara check-post -> Dhordo.",
            nearestRailwayStation = "Bhuj Railway Station (BHUJ - 85 km, connected directly to Mumbai, Delhi, Ahmedabad)",
            nearestAirport = "Bhuj Airport (BHJ - 85 km) / Ahmedabad Airport (AMD - 415 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 3500,
            foodEstimatePerDay = 900,
            activitiesTotal = 1500,
            travelEstimate = 3000,
            totalEstimateMin = 8900,
            totalEstimateMax = 20000
        ),
        seasons = RegionalSeasonalHelper.createDeccanSeasons("gujarat-rann-of-kutch")
    )

    val girNationalPark = Destination(
        id = "gujarat-gir",
        name = "Gir National Park & Sasan Gir",
        state = "Gujarat",
        stateCode = "GJ",
        district = "Junagadh & Gir Somnath",
        latitude = 21.1241,
        longitude = 70.8242,
        tagline = "The only natural home of the majestic Asiatic Lion (Panthera leo persica) on planet Earth",
        description = "Spread across 1,412 sq km of dry deciduous teak and acacia forests, Gir is world-renowned as the last global sanctuary of the wild Asiatic Lion. Guided open-top 4x4 Gypsy safaris navigate riverine tracks shared with leopards, marsh crocodiles, and spotted deer.",
        shortDescription = "The only wild habitat of the Asiatic Lion in the entire world",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "150 m",
        destinationTypes = listOf("Wildlife", "Safari", "Asiatic Lion", "Forest", "Conservation"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "December to March (Comfortable morning safaris, peak wildlife sightings)",
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.ADVENTURE, TravelCategory.NATURE),
        attractions = listOf(
            Attraction(
                id = "gir-lion-safari",
                destinationId = "gujarat-gir",
                name = "Sasan Gir Jungle Jeep Safari",
                description = "Open 4x4 Gypsy safari into the protected lion reserve across designated trail routes with certified naturalist guides.",
                category = "Wildlife Safari",
                latitude = 21.1345,
                longitude = 70.8122,
                entryFeeAdult = "₹3,500 - ₹4,800 per gypsy (Permit, vehicle, guide for up to 6 persons)",
                recommendedDurationMinutes = 180,
                familyFriendly = true,
                insiderTip = "Forest permits must be booked on the official Gujarat Forest portal (girlion.gujarat.gov.in) 90 days in advance."
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-devalia-safari-park",
                destinationId = "gujarat-gir",
                name = "Gir Interpretation Zone (Devalia)",
                description = "Enclosed 412-hectare eco-zone providing guaranteed close-range viewings of Asiatic lions, leopards, and blackbucks in natural scrubland.",
                whyItIsSpecial = "Ideal if main park permits are sold out or for families with young children.",
                category = "Interpretation Safari Park",
                location = "12 km from Sasan Gir",
                latitude = 21.1492,
                longitude = 70.6811,
                entryFee = "₹150 for Indians / ₹400 for Minibus tour",
                crowdLevel = "Moderate",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Kathiyawadi Thali with Sev Tameta & Chhas",
                    isVegetarian = true,
                    description = "Fiery tomato-gram flour noodle curry served with garlic chutney, jaggery, and cool spiced buttermilk.",
                    popularAt = "Local Kathiyawadi Dhabas along Sasan-Malia Highway",
                    priceRange = "₹120 - ₹200"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Rajkot" to 160, "Junagadh" to 55, "Ahmedabad" to 360, "Somnath" to 45),
            drivingTimes = mapOf("Junagadh" to "1.5 Hours", "Rajkot" to "3.5 Hours"),
            roadTripRoute = "Rajkot -> Gondal -> Jetpur -> Junagadh -> Mendarda -> Sasan Gir via SH 26.",
            nearestRailwayStation = "Sasan Gir (SASG - 1 km) / Junagadh Junction (JND - 55 km)",
            nearestAirport = "Keshod Airport (IXK - 45 km) / Diu Airport (DIU - 100 km) / Rajkot Airport (RAJ - 160 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 3200,
            foodEstimatePerDay = 850,
            activitiesTotal = 2500,
            travelEstimate = 2200,
            totalEstimateMin = 8750,
            totalEstimateMax = 18000
        ),
        seasons = RegionalSeasonalHelper.createDeccanSeasons("gujarat-gir")
    )

    val destinations: List<Destination> = listOf(rannOfKutch, girNationalPark)
}
