package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.core.operation
import com.example.data.local.TripWithDays
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object TripExporter {
    fun summary(trip: TripWithDays): String = buildString {
        appendLine(trip.trip.title)
        trip.days.sortedBy { it.day.dayNumber }.forEach { day ->
            appendLine("\nDay ${day.day.dayNumber}: ${day.day.title}")
            day.activities.sortedBy { it.position }.forEach {
                appendLine("${it.timeSlot} — ${it.title} (${trip.trip.currency} ${it.estimatedCost})")
                if (it.notes.isNotBlank()) appendLine(it.notes)
            }
        }
        appendLine("\nEstimates only. Confirm opening times, transport, safety, and prices locally.")
        appendLine("Open on this device: escapeplan://trip/${trip.trip.id}")
    }

    fun textIntent(trip: TripWithDays): Intent = Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, summary(trip))
    }, "Share trip")

    suspend fun pdf(context: Context, trip: TripWithDays): Result<Intent> = operation {
        val file = withContext(Dispatchers.IO) {
            val folder = File(context.cacheDir, "trip_exports").apply { mkdirs() }
            val target = File(folder, "trip-${trip.trip.id.replace(Regex("[^a-zA-Z0-9-]"), "")}.pdf")
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f }
            PdfDocument().use { document ->
                var pageNumber = 1
                var page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber).create())
                var y = 40f
                summary(trip).lineSequence().forEach { paragraph ->
                    var remaining = paragraph
                    do {
                        if (y > 790f) {
                            document.finishPage(page)
                            page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, ++pageNumber).create())
                            y = 40f
                        }
                        val count = if (remaining.isEmpty()) 0 else paint.breakText(remaining, true, 515f, null).coerceAtLeast(1)
                        page.canvas.drawText(remaining.take(count), 40f, y, paint)
                        y += 17f
                        remaining = remaining.drop(count)
                    } while (remaining.isNotEmpty())
                }
                document.finishPage(page)
                target.outputStream().use { document.writeTo(it) }
            }
            target
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = android.content.ClipData.newRawUri("Trip PDF", uri)
        }, "Export trip PDF")
    }
}
