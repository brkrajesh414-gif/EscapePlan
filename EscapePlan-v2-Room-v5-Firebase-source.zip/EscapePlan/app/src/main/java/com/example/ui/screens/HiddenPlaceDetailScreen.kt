package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.HiddenPlace
import com.example.data.repository.HiddenPlacesRepository
import com.example.ui.components.ErrorBanner
import com.example.ui.components.LoadingShimmer

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HiddenPlaceDetailScreen(id: String, onPlan: (String) -> Unit) {
    val context = LocalContext.current
    val repository = remember { HiddenPlacesRepository(context) }
    var place by remember(id) { mutableStateOf<HiddenPlace?>(null) }
    var error by remember(id) { mutableStateOf<String?>(null) }
    var retryKey by remember(id) { mutableStateOf(0) }
    fun open(url: String) {
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            .onFailure { error = it.message ?: "Unable to open link" }
    }
    LaunchedEffect(id, retryKey) {
        repository.get(id).fold({ place = it }, { error = it.message })
    }
    val current = place
    if (current == null && error == null) { LoadingShimmer(); return }
    if (current == null) { ErrorBanner(error ?: "Place not found", onRetry = { error = null; retryKey++ }); return }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(current.name, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.SemiBold)
        Text("${current.districtOrBase}, ${current.stateOrUt}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(current.categories.joinToString(" · "), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        Text(current.whyVisit, style = MaterialTheme.typography.bodyLarge)
        DetailBlock("Best season and time", "${current.bestSeason}\nSuggested stay: ${current.suggestedTime}\nDifficulty: ${current.difficulty}")
        DetailBlock("Where to stay", "Area: ${current.stayArea}\n${current.staySuggestion}")
        DetailBlock("Food to try", current.foodToTry)
        DetailBlock("Transport", current.transport)
        DetailBlock("Caution and permits", current.cautionOrPermit)
        DetailBlock("Evidence", "${current.evidenceStatus}\nLast reviewed: ${current.lastReviewed}")
        Button(onClick = { onPlan("Plan a trip to ${current.name}, ${current.stateOrUt}. Best season: ${current.bestSeason}. Suggested time: ${current.suggestedTime}. Consider: ${current.cautionOrPermit}") }, modifier = Modifier.fillMaxWidth()) { Text("Plan this trip") }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LinkButton("Map", current.googleMapsUrl, ::open)
            LinkButton("Hotels", current.googleHotelsUrl, ::open)
            LinkButton("MakeMyTrip", current.makeMyTripUrl, ::open)
            LinkButton("OYO", current.oyoUrl, ::open)
            LinkButton("Food nearby", current.foodMapUrl, ::open)
            LinkButton("Source", current.primarySourceUrl, ::open)
            LinkButton("Instagram", current.instagramUrl, ::open)
            LinkButton("Facebook", current.facebookUrl, ::open)
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Text("Confirm current prices, permits, weather, road access, opening status and reviews before travel.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun DetailBlock(title: String, content: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(content)
        }
    }
}

@Composable
private fun LinkButton(label: String, url: String, open: (String) -> Unit) {
    if (url.isNotBlank()) OutlinedButton(onClick = { open(url) }) { Text(label) }
}
