package com.example.data.imported.telangana

import com.example.data.model.*

object TelanganaDestinationsData {

    val hyderabad = Destination(
        id = "telangana-hyderabad",
        name = "Hyderabad",
        state = "Telangana",
        district = "Hyderabad",
        tagline = "City of Pearls, Nizam Palaces & World-Famous Biryani",
        description = "A dynamic metropolis of four centuries combining historical marvels like Charminar, Golconda Fort, and Chowmahalla Palace with cutting-edge IT hubs, vibrant bazaars, and world-renowned culinary culture.",
        bestDurationMinDays = 3,
        bestDurationMaxDays = 4,
        destinationTypes = listOf("Metropolis", "Heritage", "Food", "Monuments"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.FOOD, TravelCategory.FAMILY, TravelCategory.POPULAR),
        rating = 4.8f,
        reviewCount = 45000,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Hyderabad" to 0, "Bengaluru" to 570, "Chennai" to 630, "Mumbai" to 710),
            drivingTimes = mapOf("Bengaluru" to "8h via NH44", "Chennai" to "10h via NH65"),
            roadTripRoute = "Hub connecting major national highways NH44, NH65, and Outer Ring Road.",
            nearestRailwayStation = "Secunderabad / Hyderabad Deccan (Nampally) / Kacheguda",
            nearestAirport = "Rajiv Gandhi International Airport (HYD)"
        ),
        budget = BudgetBreakdown(3000, 1500, 800, 1000, 8000, 25000)
    )

    val warangal = Destination(
        id = "telangana-warangal",
        name = "Warangal",
        state = "Telangana",
        district = "Warangal",
        tagline = "Ancient Capital of the Kakatiya Dynasty & Iconic Stone Gateways",
        description = "The glorious seat of the Kakatiya kingdom, Warangal features the historic Warangal Fort with its ornate stone torana gateways, thousand-pillar temple carvings, and rich medieval architectural legacy.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        destinationTypes = listOf("Heritage", "Historical Fort", "Archaeology"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.7f,
        reviewCount = 18000,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Hyderabad" to 145, "Vijayawada" to 240),
            drivingTimes = mapOf("Hyderabad" to "3h via NH163"),
            roadTripRoute = "Direct 4-lane expressway via NH163 from Hyderabad through Yadagirigutta belt.",
            nearestRailwayStation = "Warangal / Kazipet Junction",
            nearestAirport = "Rajiv Gandhi International Airport, Hyderabad (160 km)"
        )
    )

    val hanamkonda = Destination(
        id = "telangana-hanamkonda",
        name = "Hanamkonda",
        state = "Telangana",
        district = "Hanamkonda",
        tagline = "Home of the 1,000 Pillar Temple & Padmakshi Hill",
        description = "Twin city to Warangal, renowned for the star-shaped Thousand Pillar Temple built in 1163 AD dedicated to Shiva, Vishnu, and Surya, with exquisite monolithic stone elephant carvings.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Heritage", "Spiritual", "Architecture"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.PILGRIMAGE),
        rating = 4.6f,
        reviewCount = 9500
    )

    val ramappa = Destination(
        id = "telangana-ramappa",
        name = "Ramappa (Palampet)",
        state = "Telangana",
        district = "Mulugu",
        tagline = "UNESCO World Heritage Floating-Brick Temple of Kakatiya Glory",
        description = "A UNESCO World Heritage marvel constructed in 1213 AD by General Recharla Rudra. Notable for its lightweight floating bricks, sandstone sculptures of dancing maidens, and earthquake-resistant sandbox technology.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("UNESCO Heritage", "Spiritual", "Architecture"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.PILGRIMAGE, TravelCategory.POPULAR),
        rating = 4.9f,
        reviewCount = 14200,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Hyderabad" to 210, "Warangal" to 65),
            drivingTimes = mapOf("Hyderabad" to "4h 30m", "Warangal" to "1h 30m"),
            roadTripRoute = "Via NH163 to Mulugu, then state highway to Palampet village.",
            nearestRailwayStation = "Warangal / Kazipet (65 km)",
            nearestAirport = "Hyderabad (HYD - 230 km)"
        )
    )

    val bhongir = Destination(
        id = "telangana-bhongir",
        name = "Bhongir Fort",
        state = "Telangana",
        district = "Yadadri Bhuvanagiri",
        tagline = "Monolithic Egg-Shaped Rock Fortress & Rock Climbing Trek",
        description = "An imposing monolithic rock fortress perched at 500 feet above the surrounding plains, built by Western Chalukya ruler Tribhuvanamalla Vikramaditya VI in the 10th century.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Trekking", "Fort", "Monolith"),
        categories = listOf(TravelCategory.ADVENTURE, TravelCategory.HERITAGE, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.5f,
        reviewCount = 8900
    )

    val medak = Destination(
        id = "telangana-medak",
        name = "Medak",
        state = "Telangana",
        district = "Medak",
        tagline = "Gothic Cathedral, Hilltop Fortress & Pocharam Lake",
        description = "Famed for the grand Medak Cathedral, one of the largest churches in India built in pristine Gothic Revival style with stained glass windows, alongside the historic hilltop Medak Fort.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Heritage", "Architecture", "Pilgrimage"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.6f,
        reviewCount = 11000
    )

    val elgandal = Destination(
        id = "telangana-elgandal",
        name = "Elgandal Fort",
        state = "Telangana",
        district = "Karimnagar",
        tagline = "Historic Hilltop Citadel by the Manair River",
        description = "A medieval stronghold overlooking the Manair river palm groves, bearing architectural influences from Kakatiyas, Bahmanis, Qutb Shahis, and Asaf Jahis with secret underground tunnels.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Fort", "Heritage", "Viewpoint"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.OFFBEAT),
        rating = 4.4f,
        reviewCount = 4200
    )

    val jagtial = Destination(
        id = "telangana-jagtial",
        name = "Jagtial",
        state = "Telangana",
        district = "Jagtial",
        tagline = "Star-Shaped Moated Fort & Kondagattu Gateway",
        description = "Known for its unique star-shaped fortress surrounded by a water moat designed by French engineers for Mughal governors, and proximity to mango orchards and ancient temples.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Fort", "History"),
        categories = listOf(TravelCategory.HERITAGE),
        rating = 4.3f,
        reviewCount = 3800
    )

    val karimnagar = Destination(
        id = "telangana-karimnagar",
        name = "Karimnagar",
        state = "Telangana",
        district = "Karimnagar",
        tagline = "Silver Filigree Craft, Lower Manair Dam & Granite Hills",
        description = "A vibrant heritage city world-famous for its delicate Silver Filigree (Tarkashi) handcraft, Lower Manair Dam water reservoir with boating, and scenic granite hills.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Culture", "Crafts", "Dam"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.CULTURE),
        rating = 4.5f,
        reviewCount = 7600
    )

    val laknavaram = Destination(
        id = "telangana-laknavaram",
        name = "Laknavaram Lake",
        state = "Telangana",
        district = "Mulugu",
        tagline = "Suspension Bridges & 13 Island Forest Lake",
        description = "An expansive lake created by Kakatiya rulers featuring 13 verdant islands connected by yellow suspension footbridges, speed boating, kayaking, and eco-resorts inside dense forests.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Lake", "Boating", "Eco Tourism"),
        categories = listOf(TravelCategory.LAKES, TravelCategory.WEEKEND_GETAWAYS, TravelCategory.NATURE),
        rating = 4.7f,
        reviewCount = 19800,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Hyderabad" to 215, "Warangal" to 70),
            drivingTimes = mapOf("Hyderabad" to "4h 30m", "Warangal" to "1h 45m"),
            roadTripRoute = "Via NH163 Warangal highway to Mulugu and Govindaraopet.",
            nearestRailwayStation = "Warangal (70 km)",
            nearestAirport = "Hyderabad (230 km)"
        )
    )

    val pakhal = Destination(
        id = "telangana-pakhal",
        name = "Pakhal Lake & Sanctuary",
        state = "Telangana",
        district = "Warangal",
        tagline = "Ancient 1213 AD Kakatiya Lake & Forest Sanctuary",
        description = "Encircled by deciduous forested hills and wildlife, Pakhal Lake was excavated in 1213 AD by Ganapati Deva, offering scenic picnics, birdwatching, and leopards and chital sightings.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Lake", "Wildlife", "Picnic"),
        categories = listOf(TravelCategory.LAKES, TravelCategory.NATURE, TravelCategory.OFFBEAT),
        rating = 4.5f,
        reviewCount = 6400
    )

    val bogatha = Destination(
        id = "telangana-bogatha",
        name = "Bogatha Waterfalls",
        state = "Telangana",
        district = "Mulugu",
        tagline = "Telangana's Niagara: Roaring Forest Cascade",
        description = "A breathtaking wide waterfall amidst dense teak and sal forests of the Eastern Ghats near Cheekupalli, offering thrilling natural splash pools and viewing galleries.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Waterfalls", "Nature", "Photography"),
        categories = listOf(TravelCategory.WATERFALLS, TravelCategory.NATURE, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.7f,
        reviewCount = 16200
    )

    val kuntala = Destination(
        id = "telangana-kuntala",
        name = "Kuntala Waterfalls",
        state = "Telangana",
        district = "Adilabad",
        tagline = "Highest Waterfall in Telangana at 150 Feet",
        description = "Telangana's tallest waterfall cascading down two tiers on the Kadem river, deep within the Sahyadri mountain ranges surrounded by dense wilderness and medicinal flora.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Waterfalls", "Trekking", "Forest"),
        categories = listOf(TravelCategory.WATERFALLS, TravelCategory.ADVENTURE, TravelCategory.NATURE),
        rating = 4.8f,
        reviewCount = 21000,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Hyderabad" to 280, "Adilabad" to 45),
            drivingTimes = mapOf("Hyderabad" to "5h via NH44", "Adilabad" to "1h"),
            roadTripRoute = "Northbound along NH44 past Nirmal to Neredigonda, then 12 km scenic forest road.",
            nearestRailwayStation = "Adilabad (45 km)",
            nearestAirport = "Hyderabad (300 km)"
        )
    )

    val pochera = Destination(
        id = "telangana-pochera",
        name = "Pochera Waterfalls",
        state = "Telangana",
        district = "Adilabad",
        tagline = "Cascading Plunge Pool on the Godavari Basin",
        description = "A wide, multi-stream cascade dropping 20 meters into a deep rock amphitheater on the Godavari river basin, located close to Kuntala Waterfalls.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Waterfalls", "Picnic"),
        categories = listOf(TravelCategory.WATERFALLS, TravelCategory.NATURE),
        rating = 4.6f,
        reviewCount = 13500
    )

    val singur = Destination(
        id = "telangana-singur",
        name = "Singur Dam & Crocodile Sanctuary",
        state = "Telangana",
        district = "Sangareddy",
        tagline = "Manjira Backwaters & Mugger Crocodile Habitat",
        description = "A massive reservoir on the Manjira river that provides drinking water to Hyderabad and serves as a natural breeding habitat for hundreds of wild marsh crocodiles and migratory waterbirds.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Dam", "Wildlife", "Birdwatching"),
        categories = listOf(TravelCategory.LAKES, TravelCategory.WILDLIFE, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.4f,
        reviewCount = 5700
    )

    val nagarjunaSagar = Destination(
        id = "telangana-nagarjunasagar",
        name = "Nagarjuna Sagar",
        state = "Telangana",
        district = "Nalgonda",
        tagline = "World's Largest Masonry Dam & Buddhist Island Museum",
        description = "An engineering marvel on the Krishna river, boasting the world's largest masonry dam with 26 crest gates and Nagarjunakonda, an island museum holding 3rd-century Buddhist relics.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Dam", "Buddhist Heritage", "Island"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.WEEKEND_GETAWAYS, TravelCategory.FAMILY),
        rating = 4.7f,
        reviewCount = 28000,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Hyderabad" to 150, "Vijayawada" to 190),
            drivingTimes = mapOf("Hyderabad" to "3h 15m via Sagar Highway"),
            roadTripRoute = "Direct 4-lane state highway from Hyderabad through Ibrahimpatnam.",
            nearestRailwayStation = "Macherla (25 km)",
            nearestAirport = "Hyderabad (150 km)"
        )
    )

    val yadagirigutta = Destination(
        id = "telangana-yadagirigutta",
        name = "Yadagirigutta (Sri Lakshmi Narasimha Swamy)",
        state = "Telangana",
        district = "Yadadri Bhuvanagiri",
        tagline = "Spiritual Heart of Telangana: The Grand Hilltop Temple",
        description = "A majestic hilltop cave shrine reconstructed in grand Krishna Shila stone architecture, dedicated to Lord Lakshmi Narasimha Swamy, drawing millions of pilgrims annually.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Pilgrimage", "Temple", "Hilltop"),
        categories = listOf(TravelCategory.PILGRIMAGE, TravelCategory.HERITAGE, TravelCategory.POPULAR),
        rating = 4.9f,
        reviewCount = 38000
    )

    val basara = Destination(
        id = "telangana-basara",
        name = "Basara (Sri Gnana Saraswathi Temple)",
        state = "Telangana",
        district = "Nirmal",
        tagline = "One of India's Two Historic Goddess Saraswathi Shrines",
        description = "Revered shrine on the banks of the Godavari river where children are initiated into education through Aksharabhyasam ceremonies, blessed by Maharshi Ved Vyasa.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Pilgrimage", "Godavari River", "Temple"),
        categories = listOf(TravelCategory.PILGRIMAGE, TravelCategory.FAMILY),
        rating = 4.8f,
        reviewCount = 24000
    )

    val vemulawada = Destination(
        id = "telangana-vemulawada",
        name = "Vemulawada (Sri Raja Rajeshwara Swamy)",
        state = "Telangana",
        district = "Rajanna Sircilla",
        tagline = "Dakshina Kasi: Sacred Shiva Temple & Holy Dharma Gundam",
        description = "Known as Dakshina Kasi, this 8th-century temple built by Chalukya kings features the sacred Dharma Gundam pool and the unique ritual offering of Kode Mokku (ox tying).",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Pilgrimage", "Shiva Temple"),
        categories = listOf(TravelCategory.PILGRIMAGE, TravelCategory.HERITAGE),
        rating = 4.7f,
        reviewCount = 18500
    )

    val kondagattu = Destination(
        id = "telangana-kondagattu",
        name = "Kondagattu (Sri Anjaneya Swamy)",
        state = "Telangana",
        district = "Jagtial",
        tagline = "Sacred Hilltop Hanuman Shrine Surrounded by Valleys",
        description = "Surrounded by picturesque hills and valleys, this 500-year-old temple houses a unique deity of Lord Anjaneya with dual faces of Narasimha and Varaha.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Pilgrimage", "Hanuman Temple", "Hilltop"),
        categories = listOf(TravelCategory.PILGRIMAGE, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.7f,
        reviewCount = 15000
    )

    val dharmapuri = Destination(
        id = "telangana-dharmapuri",
        name = "Dharmapuri (Sri Lakshmi Narasimha Swamy)",
        state = "Telangana",
        district = "Jagtial",
        tagline = "Sacred Godavari Teertham & Vedic Scholar Hub",
        description = "One of the nine sacred Narasimha Kshetrams situated along the Godavari river with ancient stepwells, ghats, and a heritage of Sanskrit learning.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Pilgrimage", "Ghats", "Heritage"),
        categories = listOf(TravelCategory.PILGRIMAGE, TravelCategory.HERITAGE),
        rating = 4.6f,
        reviewCount = 9200
    )

    val kaleshwaram = Destination(
        id = "telangana-kaleshwaram",
        name = "Kaleshwaram (Triveni Sangamam & Dual Lingas)",
        state = "Telangana",
        district = "Jayashankar Bhupalpally",
        tagline = "Confluence of Godavari & Pranahita with Dual Shiva-Yama Lingas",
        description = "A rare temple where two Shiva lingas stand on a single pedestal, representing Lord Shiva and Lord Yama, at the sacred river confluence of Godavari and Pranahita.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Pilgrimage", "River Confluence"),
        categories = listOf(TravelCategory.PILGRIMAGE, TravelCategory.HERITAGE),
        rating = 4.7f,
        reviewCount = 11400
    )

    val medaram = Destination(
        id = "telangana-medaram",
        name = "Medaram (Sammakka Saralamma Jatara)",
        state = "Telangana",
        district = "Mulugu",
        tagline = "Asia's Largest Tribal Congregation in the Dandakaranya Forest",
        description = "Home to the biennial Sammakka Saralamma Jatara, which draws over 10 million devotees to celebrate tribal courage and unity in the heart of dense forests.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Tribal Heritage", "Jatara", "Forest"),
        categories = listOf(TravelCategory.CULTURE, TravelCategory.PILGRIMAGE, TravelCategory.OFFBEAT),
        rating = 4.8f,
        reviewCount = 26000
    )

    val bhadrachalam = Destination(
        id = "telangana-bhadrachalam",
        name = "Bhadrachalam (Sri Seetha Ramachandra Swamy)",
        state = "Telangana",
        district = "Bhadradri Kothagudem",
        tagline = "Sacred Rama Temple on the Holy Godavari Banks",
        description = "Constructed by Bhakta Ramadasu in the 17th century, this revered temple on the winding Godavari is deeply tied to the Ramayana epic and Sita Rama Kalyanam celebrations.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        destinationTypes = listOf("Pilgrimage", "River Cruise", "Heritage"),
        categories = listOf(TravelCategory.PILGRIMAGE, TravelCategory.HERITAGE, TravelCategory.POPULAR),
        rating = 4.9f,
        reviewCount = 34000,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Hyderabad" to 310, "Vijayawada" to 190, "Rajamahendravaram" to 160),
            drivingTimes = mapOf("Hyderabad" to "6h via Khammam"),
            roadTripRoute = "Via NH65 to Suryapet, then Khammam and Kothagudem to Bhadrachalam.",
            nearestRailwayStation = "Bhadrachalam Road (Kothagudem - 40 km)",
            nearestAirport = "Vijayawada (VGA - 190 km)"
        )
    )

    val parnasala = Destination(
        id = "telangana-parnasala",
        name = "Parnasala",
        state = "Telangana",
        district = "Bhadradri Kothagudem",
        tagline = "Legendary Forest Hermitage of Lord Rama's Exile",
        description = "Believed to be the sacred spot in Dandakaranya forest where Lord Rama lived during exile and where Ravana abducted Goddess Sita, located 32 km from Bhadrachalam.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Ramayana Heritage", "River"),
        categories = listOf(TravelCategory.PILGRIMAGE, TravelCategory.HERITAGE),
        rating = 4.6f,
        reviewCount = 8400
    )

    val alampur = Destination(
        id = "telangana-alampur",
        name = "Alampur (Navabrahma Temples)",
        state = "Telangana",
        district = "Jogulamba Gadwal",
        tagline = "Gateway to Srisailam & 7th Century Badami Chalukya Gems",
        description = "Situated at the confluence of Tungabhadra and Krishna rivers, Alampur houses nine remarkable 7th-century sandstone temples showcasing Nagara and Dravidian architecture.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Archaeology", "Chalukya", "Heritage"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.PILGRIMAGE),
        rating = 4.7f,
        reviewCount = 10500
    )

    val jogulamba = Destination(
        id = "telangana-jogulamba",
        name = "Jogulamba Temple (5th Maha Shakti Peetham)",
        state = "Telangana",
        district = "Jogulamba Gadwal",
        tagline = "5th Maha Shakti Peetham on the Sacred Tungabhadra River",
        description = "One of the eighteen supreme Maha Shakti Peethams, where Sati's upper teeth are believed to have fallen, located within the Alampur temple complex.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Shakti Peetham", "Pilgrimage"),
        categories = listOf(TravelCategory.PILGRIMAGE, TravelCategory.HERITAGE),
        rating = 4.8f,
        reviewCount = 14200
    )

    val beechupally = Destination(
        id = "telangana-beechupally",
        name = "Beechupally (Sri Anjaneya Swamy)",
        state = "Telangana",
        district = "Jogulamba Gadwal",
        tagline = "Riverside Hanuman Temple on Krishna River Bridge",
        description = "A 200-year-old temple installed by Vyasaraja on an island bank of the Krishna river along NH44, famous for serene river bathing ghats.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Pilgrimage", "River Ghats"),
        categories = listOf(TravelCategory.PILGRIMAGE, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.5f,
        reviewCount = 6800
    )

    val somasila = Destination(
        id = "telangana-somasila",
        name = "Somasila",
        state = "Telangana",
        district = "Nagarkurnool",
        tagline = "Krishna Backwaters, 15 Shiva Temples & Island Boating",
        description = "A scenic riverside village with 15 ancient Shiva temples dating back to the 7th century, where the Krishna river forms vast tranquil backwaters perfect for boating and camping.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Backwaters", "Boating", "Heritage"),
        categories = listOf(TravelCategory.LAKES, TravelCategory.WEEKEND_GETAWAYS, TravelCategory.HERITAGE),
        rating = 4.6f,
        reviewCount = 9800
    )

    val kollapur = Destination(
        id = "telangana-kollapur",
        name = "Kollapur (City of Palaces & Nallamala Gateway)",
        state = "Telangana",
        district = "Nagarkurnool",
        tagline = "Royal Samsthanam Palaces & Nallamala Forest Gateway",
        description = "Former princely seat known for its ornate Kollapur Palace, historic Madhava Swamy temple, and mango orchards nestled against the Nallamala forest ranges.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Palace", "Heritage", "Forest"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.OFFBEAT),
        rating = 4.5f,
        reviewCount = 5200
    )

    val jatprole = Destination(
        id = "telangana-jatprole",
        name = "Jatprole (Relocated Chalukyan Temples)",
        state = "Telangana",
        district = "Nagarkurnool",
        tagline = "Ancient Stone Temples Relocated from Srisailam Submersion",
        description = "Magnificent 10th-century temples painstakingly relocated stone by stone by the Archaeological Survey of India to save them from Srisailam dam waters.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Archaeology", "Heritage"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.OFFBEAT),
        rating = 4.4f,
        reviewCount = 3100
    )

    val vikarabad = Destination(
        id = "telangana-vikarabad",
        name = "Vikarabad / Ananthagiri Hills",
        state = "Telangana",
        district = "Vikarabad",
        tagline = "Forest Trekking, Musi River Origin & Kayaking on Kotepally",
        description = "Just 80 km from Hyderabad, Ananthagiri Hills is the source of the Musi River, offering dense forest trails, the ancient Sri Anantha Padmanabha Swamy temple, and kayaking on Kotepally reservoir.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Hills", "Trekking", "Kayaking"),
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.WEEKEND_GETAWAYS, TravelCategory.ADVENTURE),
        rating = 4.6f,
        reviewCount = 22400,
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Hyderabad" to 80),
            drivingTimes = mapOf("Hyderabad" to "2h via Chevella"),
            roadTripRoute = "Direct state highway from Mehdipatnam via Chevella through sunflower fields.",
            nearestRailwayStation = "Vikarabad Junction (6 km)",
            nearestAirport = "Hyderabad (85 km)"
        )
    )

    val pocharam = Destination(
        id = "telangana-pocharam",
        name = "Pocharam Sanctuary & Dam",
        state = "Telangana",
        district = "Medak",
        tagline = "Nizam's Dam Without Sluice Gates & Deer Sanctuary",
        description = "A peaceful reservoir built in 1922 without sluice gates that overflows into a scenic water curtain, surrounded by a sanctuary sheltering chital, nilgai, and winter birds.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Sanctuary", "Dam", "Picnic"),
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.4f,
        reviewCount = 7200
    )

    val narsapur = Destination(
        id = "telangana-narsapur",
        name = "Narsapur Forest & Urban Eco-Park",
        state = "Telangana",
        district = "Medak",
        tagline = "Deciduous Forest Trekking & Natural Lake Just 45 km from City",
        description = "A popular day trek destination featuring natural forest trails, watchtowers, and a scenic lake offering a refreshing green escape from Hyderabad.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Trekking", "Forest", "Day Trip"),
        categories = listOf(TravelCategory.WEEKEND_GETAWAYS, TravelCategory.NATURE),
        rating = 4.3f,
        reviewCount = 6100
    )

    val kawal = Destination(
        id = "telangana-kawal",
        name = "Kawal Wildlife Sanctuary (Tiger Reserve)",
        state = "Telangana",
        district = "Mancherial",
        tagline = "Teak Forests of the Godavari Basin & Tiger Corridor",
        description = "Spread over 892 sq km of prime teak and bamboo forest, Kawal is a vital tiger corridor connected to Tadoba, home to leopards, wild dogs, sambar, and rare birds.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        destinationTypes = listOf("Tiger Reserve", "Safari", "Wildlife"),
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.ADVENTURE, TravelCategory.OFFBEAT),
        rating = 4.6f,
        reviewCount = 8800
    )

    val eturnagaram = Destination(
        id = "telangana-eturnagaram",
        name = "Eturnagaram Wildlife Sanctuary",
        state = "Telangana",
        district = "Mulugu",
        tagline = "One of India's Oldest Sanctuaries Bordering Godavari",
        description = "Declared a sanctuary in 1952, this dense deciduous forest is bisected by the Dayyam Vagu stream and borders the Godavari river, offering tiger and sloth bear habitats.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        destinationTypes = listOf("Wildlife", "Forest", "River"),
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.NATURE),
        rating = 4.5f,
        reviewCount = 7400
    )

    val pandavulagutta = Destination(
        id = "telangana-pandavulagutta",
        name = "Pandavula Gutta",
        state = "Telangana",
        district = "Jayashankar Bhupalpally",
        tagline = "Prehistoric Mesolithic Rock Art & Natural Cave Canopies",
        description = "An extraordinary geological site with natural sandstone rock shelters featuring prehistoric Mesolithic paintings dating back thousands of years.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Rock Art", "Trek", "Archaeology"),
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.ADVENTURE, TravelCategory.OFFBEAT),
        rating = 4.5f,
        reviewCount = 4900
    )

    val shivaram = Destination(
        id = "telangana-shivaram",
        name = "Shivaram Wildlife Sanctuary",
        state = "Telangana",
        district = "Mancherial",
        tagline = "River Godavari Marsh Crocodile Breeding Sanctuary",
        description = "A scenic riverine sanctuary along the Godavari river where freshwater marsh crocodiles bask on river sandbanks amid riverine forests.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 1,
        destinationTypes = listOf("Crocodile Sanctuary", "Riverine"),
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.OFFBEAT),
        rating = 4.4f,
        reviewCount = 3300
    )

    val kinnerasani = Destination(
        id = "telangana-kinnerasani",
        name = "Kinnerasani Wildlife Sanctuary & Dam",
        state = "Telangana",
        district = "Bhadradri Kothagudem",
        tagline = "Island Glass House, Deer Park & Kinnerasani Reservoir",
        description = "Set around a picturesque reservoir, Kinnerasani features a deer park, an island guest house surrounded by water, and rich wildlife including gaurs and panthers.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Wildlife", "Lake", "Deer Park"),
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.LAKES, TravelCategory.WEEKEND_GETAWAYS),
        rating = 4.6f,
        reviewCount = 9100
    )

    val amrabad = Destination(
        id = "telangana-amrabad",
        name = "Amrabad (Tiger Reserve & Nallamala Hills)",
        state = "Telangana",
        district = "Nagarkurnool",
        tagline = "One of India's Largest Tiger Reserves in Ancient Nallamala",
        description = "Spanning over 2,600 sq km of pristine Nallamala hills, Amrabad is one of the largest tiger reserves in India, featuring viewpoints like Octopus Viewpoint overlooking Krishna gorge.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "650 m",
        destinationTypes = listOf("Tiger Reserve", "Nallamala Hills", "Jungle Safari"),
        categories = listOf(TravelCategory.WILDLIFE, TravelCategory.ADVENTURE, TravelCategory.MOUNTAINS),
        rating = 4.8f,
        reviewCount = 17600
    )

    val adilabad = Destination(
        id = "telangana-adilabad",
        name = "Adilabad",
        state = "Telangana",
        district = "Adilabad",
        tagline = "Northern Frontier of Cascades, Teak Woods & Dhokra Craft",
        description = "Telangana's northern hill district celebrated for its majestic waterfalls, Dhokra bell-metal tribal craft, teak forests, and cool winter weather.",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        destinationTypes = listOf("Nature", "Waterfalls", "Tribal Craft"),
        categories = listOf(TravelCategory.NATURE, TravelCategory.CULTURE, TravelCategory.OFFBEAT),
        rating = 4.6f,
        reviewCount = 10200
    )

    val nirmal = Destination(
        id = "telangana-nirmal",
        name = "Nirmal",
        state = "Telangana",
        district = "Nirmal",
        tagline = "City of Wooden Toys, Golden Lacquer Art & French Forts",
        description = "World-renowned for its 400-year-old GI-tagged Nirmal wooden toy craft made from Poniki wood, painted with natural dyes, alongside historical forts built with French engineering.",
        bestDurationMinDays = 1,
        bestDurationMaxDays = 2,
        destinationTypes = listOf("Crafts", "Heritage", "Toys"),
        categories = listOf(TravelCategory.CULTURE, TravelCategory.HERITAGE),
        rating = 4.6f,
        reviewCount = 8100
    )

    val destinations: List<Destination> = listOf(
        hyderabad, warangal, hanamkonda, ramappa, bhongir,
        medak, elgandal, jagtial, karimnagar, laknavaram,
        pakhal, bogatha, kuntala, pochera, singur,
        nagarjunaSagar, yadagirigutta, basara, vemulawada, kondagattu,
        dharmapuri, kaleshwaram, medaram, bhadrachalam, parnasala,
        alampur, jogulamba, beechupally, somasila, kollapur,
        jatprole, vikarabad, pocharam, narsapur, kawal,
        eturnagaram, pandavulagutta, shivaram, kinnerasani, amrabad,
        adilabad, nirmal
    )

    val allTelanganaDestinations: List<Destination> get() = destinations

    fun getDestinationById(id: String): Destination? =
        destinations.find { it.id.equals(id, ignoreCase = true) }
}
