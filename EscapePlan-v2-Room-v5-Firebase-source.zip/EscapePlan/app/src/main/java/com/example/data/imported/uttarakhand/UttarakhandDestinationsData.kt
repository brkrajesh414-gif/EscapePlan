package com.example.data.imported.uttarakhand

import com.example.data.imported.common.RegionalSeasonalHelper
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.DiscoveryLevel
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.HiddenGem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo

object UttarakhandDestinationsData {

    val rishikesh = Destination(
        id = "uttarakhand-rishikesh",
        name = "Rishikesh",
        state = "Uttarakhand",
        stateCode = "UK",
        district = "Dehradun",
        latitude = 30.0869,
        longitude = 78.2676,
        tagline = "Yoga capital of the world & white-water river rafting along the emerald Ganga",
        description = "Nestled in the Himalayan foothills where the holy Ganges emerges from mountain gorges, Rishikesh is a global center for yoga, meditation, river rafting, cliff jumping, evening Ganga Aarti at Triveni Ghat, and tranquil ashrams.",
        shortDescription = "Spiritual haven and Himalayan adventure hub along the holy Ganges",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 4,
        altitude = "340 m",
        destinationTypes = listOf("Spiritual", "Adventure", "River", "Yoga", "Mountains"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "September to November & March to May",
        categories = listOf(TravelCategory.ADVENTURE, TravelCategory.TEMPLES, TravelCategory.NATURE),
        attractions = listOf(
            Attraction(
                id = "ram-jhula-rishikesh",
                destinationId = "uttarakhand-rishikesh",
                name = "Ram Jhula & Laxman Jhula Suspension Bridges",
                description = "Famous iron suspension bridges spanning the turquoise Ganga, connecting historic ashrams and markets.",
                category = "Iconic Landmark",
                latitude = 30.1238,
                longitude = 78.3155,
                entryFeeAdult = "Free",
                recommendedDurationMinutes = 60,
                familyFriendly = true,
                insiderTip = "Walk across at sunrise for misty views of the Ganga and ringing temple bells."
            ),
            Attraction(
                id = "ganga-aarti-triveni-ghat",
                destinationId = "uttarakhand-rishikesh",
                name = "Triveni Ghat Evening Ganga Aarti",
                description = "Spellbinding evening ritual with flaming multi-tiered brass lamps, chanting priests, and floating diya offerings.",
                category = "Spiritual / Ritual",
                latitude = 30.1033,
                longitude = 78.2977,
                entryFeeAdult = "Free",
                openingTime = "18:00",
                closingTime = "19:30",
                recommendedDurationMinutes = 90,
                familyFriendly = true,
                photographyAllowed = true
            ),
            Attraction(
                id = "shivpuri-rafting-rishikesh",
                destinationId = "uttarakhand-rishikesh",
                name = "Shivpuri White Water River Rafting",
                description = "Grade III and IV white-water rapids through rocky Himalayan river gorges, including Roller Coaster and Golf Course.",
                category = "Adventure / Rafting",
                latitude = 30.1362,
                longitude = 78.3892,
                entryFeeAdult = "₹800 - ₹1,500 per person",
                recommendedDurationMinutes = 180,
                familyFriendly = false,
                insiderTip = "Post-monsoon from late September to November provides the cleanest emerald water and ideal water volume."
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-neer-garh-waterfall",
                destinationId = "uttarakhand-rishikesh",
                name = "Neer Garh Waterfall (Neer Gaddu)",
                description = "Three-tiered natural limestone waterfall cascading into jade-green rock pools, hidden in deep pine forest.",
                whyItIsSpecial = "Natural freshwater swimming pools far cleaner and more peaceful than river beach spots.",
                category = "Hidden Waterfall",
                location = "Neer Gaddu, 6 km from Laxman Jhula",
                latitude = 30.1472,
                longitude = 78.3340,
                entryFee = "₹30 Forest Dept permit",
                trekDistance = "1.5 km uphill trek",
                crowdLevel = "Low to Moderate",
                difficulty = "Easy to Moderate"
            ),
            HiddenGem(
                id = "gem-beatles-ashram",
                destinationId = "uttarakhand-rishikesh",
                name = "Chaurasi Kutia (The Beatles Ashram)",
                description = "Abandoned Maharishi Mahesh Yogi ashram inside Rajaji Tiger Reserve, adorned with vibrant graffiti murals and stone meditation domes.",
                whyItIsSpecial = "Transcendental meditation history and serene jungle atmosphere.",
                category = "Heritage / Forest Sanctuary",
                location = "Swarg Ashram, Rishikesh",
                latitude = 30.1118,
                longitude = 78.3142,
                entryFee = "₹150 for Indians, ₹600 Foreigners",
                crowdLevel = "Moderate",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Aloo ke Gutke with Pahadi Raita",
                    isVegetarian = true,
                    description = "Baby potatoes stir-fried with Himalayan herbs (Jakhya) served with cucumber-mustard yogurt.",
                    popularAt = "Chotiwala Restaurant & Local Ashrams",
                    priceRange = "₹120 - ₹180"
                ),
                FoodItem(
                    name = "Authentic Ayurvedic Kitchari & Herbal Chai",
                    isVegetarian = true,
                    description = "Wholesome organic cleansing bowl cooked with mountain ghee, cumin, and ginger.",
                    popularAt = "German Bakery & Organic Cafes in Tapovan",
                    priceRange = "₹150 - ₹250"
                )
            )
        ),
        stays = listOf(
            Accommodation(
                id = "stay-tapovan-retreat",
                name = "Ganga Kinare Heritage Resort",
                category = "Riverside Heritage",
                pricePerNight = 5500,
                rating = 4.7f,
                amenities = listOf("Direct Private Ghat Access", "Yoga Deck", "Vegetarian Dining", "WiFi")
            ),
            Accommodation(
                id = "stay-rishikesh-hostel",
                name = "Zostel Rishikesh (Tapovan)",
                category = "Backpacker & Solo",
                pricePerNight = 1200,
                rating = 4.6f,
                amenities = listOf("Rooftop Cafe", "Community Treks", "High Speed WiFi")
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Delhi" to 240, "Chandigarh" to 210, "Dehradun" to 45),
            drivingTimes = mapOf("Delhi" to "5 Hours via Delhi-Meerut Expressway", "Dehradun" to "1 Hour"),
            roadTripRoute = "Delhi -> Meerut Expressway -> Muzaffarnagar -> Roorkee -> Haridwar -> Rishikesh.",
            nearestRailwayStation = "Yog Nagari Rishikesh (YNRK - 3 km) / Haridwar Junction (HW - 25 km)",
            nearestAirport = "Dehradun Jolly Grant Airport (DED - 21 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 2500,
            foodEstimatePerDay = 900,
            activitiesTotal = 1500,
            travelEstimate = 2200,
            totalEstimateMin = 7100,
            totalEstimateMax = 16000
        ),
        seasons = RegionalSeasonalHelper.createHighAltitudeSeasons("uttarakhand-rishikesh")
    )

    val choptaTungnath = Destination(
        id = "uttarakhand-chopta",
        name = "Chopta & Tungnath",
        state = "Uttarakhand",
        stateCode = "UK",
        district = "Rudraprayag",
        latitude = 30.4878,
        longitude = 79.1764,
        tagline = "The Mini Switzerland of Uttarakhand & highest Shiva temple in the world (3,680 m)",
        description = "Chopta is an unspoiled high-altitude alpine meadow (bugyal) surrounded by evergreen deodar, pine, and rhododendron forests. Base camp for the trek to Tungnath (highest of the Panch Kedar temples) and Chandrashila peak offering a 360-degree panorama of Chaukhamba, Nanda Devi, and Trishul peaks.",
        shortDescription = "Enchanting high-altitude meadows and sacred Himalayan peaks",
        bestDurationMinDays = 3,
        bestDurationMaxDays = 4,
        altitude = "2,680 m – 3,680 m",
        destinationTypes = listOf("Meadows", "Trekking", "Himalayas", "Spiritual", "Offbeat"),
        discoveryLevel = DiscoveryLevel.OFFBEAT,
        bestMonths = "April to June (Rhododendron blooms) & September to November",
        categories = listOf(TravelCategory.MOUNTAINS, TravelCategory.ADVENTURE, TravelCategory.TEMPLES),
        attractions = listOf(
            Attraction(
                id = "tungnath-temple-chopta",
                destinationId = "uttarakhand-chopta",
                name = "Tungnath Mahadev Temple",
                description = "1000-year-old stone temple situated at 3,680 meters, the highest shrine among the sacred Panch Kedar.",
                category = "Sacred Himalayan Temple",
                latitude = 30.4883,
                longitude = 79.2167,
                entryFeeAdult = "Free",
                recommendedDurationMinutes = 180,
                familyFriendly = true,
                insiderTip = "Begin the 3.5 km trek from Chopta at 6:00 AM to reach before midday clouds envelop the summit."
            ),
            Attraction(
                id = "chandrashila-summit-chopta",
                destinationId = "uttarakhand-chopta",
                name = "Chandrashila Summit (4,000 m)",
                description = "Dramatic rocky peak 1.5 km above Tungnath offering an unmatched sunrise vista of 40+ Himalayan peaks.",
                category = "Mountain Summit Viewpoint",
                latitude = 30.4901,
                longitude = 79.2224,
                entryFeeAdult = "Free",
                recommendedDurationMinutes = 120,
                familyFriendly = false,
                insiderTip = "Carry a warm windbreaker and trekking pole; winds are intense at the summit."
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-deoriatal-lake-chopta",
                destinationId = "uttarakhand-chopta",
                name = "Deoria Tal Mirror Lake",
                description = "Pristine emerald lake at 2,438 meters surrounded by rhododendron forest, reflecting the towering Chaukhamba peaks in its glass-like water.",
                whyItIsSpecial = "Legendary lake from Mahabharata where Yaksha questioned the Pandavas; serene camping paradise.",
                category = "Alpine Lake",
                location = "Sari Village base, 20 km from Chopta",
                latitude = 30.5218,
                longitude = 79.1287,
                entryFee = "₹150 Forest camping / entry fee",
                trekDistance = "2.3 km trek from Sari",
                crowdLevel = "Low",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Mandua (Finger Millet) Roti with Gahat (Horsegram) Dal",
                    isVegetarian = true,
                    description = "Nutritious traditional Garhwali high-altitude meal packed with warmth and protein.",
                    popularAt = "Local Dhabas in Sari & Chopta",
                    priceRange = "₹100 - ₹160"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Delhi" to 420, "Rishikesh" to 200, "Dehradun" to 240),
            drivingTimes = mapOf("Rishikesh" to "7 Hours", "Delhi" to "11 Hours"),
            roadTripRoute = "Rishikesh -> Devprayag -> Srinagar -> Rudraprayag -> Ukhimath -> Chopta.",
            nearestRailwayStation = "Rishikesh (YNRK - 200 km) / Haridwar (HW - 225 km)",
            nearestAirport = "Dehradun Jolly Grant Airport (DED - 220 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 1800,
            foodEstimatePerDay = 700,
            activitiesTotal = 1000,
            travelEstimate = 3500,
            totalEstimateMin = 7000,
            totalEstimateMax = 15000
        ),
        seasons = RegionalSeasonalHelper.createHighAltitudeSeasons("uttarakhand-chopta")
    )

    val destinations: List<Destination> = listOf(rishikesh, choptaTungnath)
}
