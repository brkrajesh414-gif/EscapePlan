package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.auth.AuthRepository
import com.example.data.local.AppDatabase
import com.example.data.local.TripEntity
import com.example.data.local.TripWithDays
import com.example.data.repository.TripRepository
import com.example.domain.GenerateItineraryUseCase
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface GenerationState {
    data object Idle : GenerationState
    data object Generating : GenerationState
    data class Success(val tripId: String) : GenerationState
    data class Failure(val message: String) : GenerationState
}

@OptIn(ExperimentalCoroutinesApi::class)
class ItineraryViewModel(application: Application) : AndroidViewModel(application) {
    val repository = TripRepository(AppDatabase.getInstance(application))
    private val generate = GenerateItineraryUseCase(repository)
    private val mutable = MutableStateFlow<GenerationState>(GenerationState.Idle)
    val state = mutable.asStateFlow()
    private val selected = MutableStateFlow<TripWithDays?>(null)
    val trip = selected.asStateFlow()
    private val problem = MutableStateFlow<String?>(null)
    val error = problem.asStateFlow()
    private val information = MutableStateFlow<String?>(null)
    val message = information.asStateFlow()
    val trips = AuthRepository(application).user.flatMapLatest { user -> repository.trips(user.getOrNull()?.uid.orEmpty()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList<TripEntity>())
    private var generation: Job? = null
    private var selection: Job? = null
    init {
        viewModelScope.launch {
            var initialized = false
            var previousUid: String? = null
            AuthRepository(application).user.collect { result ->
                val uid = result.getOrNull()?.uid
                if (initialized && uid != previousUid) {
                    selection?.cancel()
                    generation?.cancel()
                    selected.value = null
                    mutable.value = GenerationState.Idle
                }
                initialized = true
                previousUid = uid
            }
        }
    }

    fun generateTrip(prompt: String) {
        generation?.cancel()
        generation = viewModelScope.launch {
            mutable.value = GenerationState.Generating
            generate(prompt).fold({ mutable.value = GenerationState.Success(it); open(it) },
                { mutable.value = GenerationState.Failure(it.message ?: "Generation failed. Please retry.") })
        }
    }
    fun cancel() { generation?.cancel(); mutable.value = GenerationState.Idle }
    fun open(id: String) {
        selection?.cancel()
        selection = viewModelScope.launch {
            repository.observe(id).collect { selected.value = it; problem.value = if (it == null) "Trip not found on this device." else null }
        }
    }
    fun move(dayId: String, activityId: String, delta: Int) {
        val current = trip.value ?: return
        val ids = current.days.singleOrNull { it.day.id == dayId }?.activities?.sortedBy { it.position }?.map { it.id }?.toMutableList() ?: return
        val index = ids.indexOf(activityId)
        val target = index + delta
        if (index !in ids.indices || target !in ids.indices) return
        ids.add(target, ids.removeAt(index))
        viewModelScope.launch { problem.value = repository.reorder(current.trip.id, dayId, ids).exceptionOrNull()?.message }
    }
    fun swap(activityId: String, title: String) {
        val id = trip.value?.trip?.id ?: return
        viewModelScope.launch { problem.value = repository.swap(id, activityId, title).exceptionOrNull()?.message }
    }
    fun delete(id: String) {
        viewModelScope.launch { problem.value = repository.delete(id).exceptionOrNull()?.message }
    }
    fun recover() {
        viewModelScope.launch {
            information.value = "Checking completed plans…"
            repository.recover().fold({ information.value = "Recovered $it plans. Existing edits were kept." },
                { information.value = null; problem.value = it.message })
        }
    }
}
