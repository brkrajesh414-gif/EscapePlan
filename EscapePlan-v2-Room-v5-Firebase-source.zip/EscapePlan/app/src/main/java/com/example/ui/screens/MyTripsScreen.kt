package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.TripEntity
import com.example.ui.viewmodel.ItineraryViewModel
import java.text.DateFormat
import java.util.Date

@Composable
fun MyTripsScreen(
    onPlan: () -> Unit,
    onOpen: (String) -> Unit,
    hasLegacyTrips: Boolean,
    onLegacyTrips: () -> Unit,
    model: ItineraryViewModel = viewModel()
) {
    val trips by model.trips.collectAsStateWithLifecycle()
    var deleteTrip by remember { mutableStateOf<TripEntity?>(null) }
    Column(Modifier.fillMaxSize().padding(top = 24.dp)) {
        Text("My Trips", fontSize = 42.sp, lineHeight = 48.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 20.dp))
        if (trips.isEmpty() && !hasLegacyTrips) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Icon(Icons.Outlined.BookmarkBorder, null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("No saved trips yet", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Text("Plan a trip with AI and save it to see it here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = onPlan, shape = RoundedCornerShape(24.dp)) { Text("Plan a Trip", modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)) }
                }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (hasLegacyTrips) item {
                    TextButton(onClick = onLegacyTrips, modifier = Modifier.fillMaxWidth()) { Text("Open trips saved in the earlier planner") }
                }
                items(trips, key = { it.id }) { trip ->
                    Card(Modifier.fillMaxWidth().clickable { onOpen(trip.id) }, shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(trip.title, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                                Text("Updated ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(trip.updatedAt))}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { deleteTrip = trip }) { Icon(Icons.Default.Delete, "Delete ${trip.title}") }
                        }
                    }
                }
            }
        }
    }
    deleteTrip?.let { trip ->
        AlertDialog(
            onDismissRequest = { deleteTrip = null },
            title = { Text("Delete trip?") },
            text = { Text("${trip.title} will be removed from this device.") },
            confirmButton = { TextButton(onClick = { model.delete(trip.id); deleteTrip = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteTrip = null }) { Text("Cancel") } }
        )
    }
}
