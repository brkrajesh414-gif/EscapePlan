package com.example.core

import kotlinx.coroutines.CancellationException

suspend fun <T> operation(block: suspend () -> T): Result<T> = try {
    Result.success(block())
} catch (cancelled: CancellationException) {
    throw cancelled
} catch (error: Exception) {
    Result.failure(error)
}
