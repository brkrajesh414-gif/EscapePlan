package com.example.data.imported.madhyapradesh

import com.example.data.imported.common.RegionalSeasonalHelper
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.DiscoveryLevel
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.HiddenGem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo

object MadhyaPradeshDestinationsData {

    val pachmarhi = Destination(
        id = "mp-pachmarhi",
        name = "Pachmarhi",
        state = "Madhya Pradesh",
        stateCode = "MP",
        district = "Narmadapuram",
        latitude = 22.4674,
        longitude = 78.4346,
        tagline = "Queen of Satpura: misty waterfalls, ancient rock shelters, and rugged red sandstone canyons",
        description = "Perched at 1,067 meters in the Satpura Range inside a UNESCO Biosphere Reserve, Pachmarhi is MP's sole hill station. Celebrated for sparkling waterfalls like Bee Falls and Duchess Falls, Pandava Caves, colonial churches, and sunset viewpoints like Dhoopgarh (highest point in MP).",
        shortDescription = "Verdant hill station with majestic waterfalls and Satpura biosphere forests",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 4,
        altitude = "1,067 m",
        destinationTypes = listOf("Hill Station", "Waterfalls", "Biosphere", "Caves", "Viewpoints"),
        discoveryLevel = DiscoveryLevel.POPULAR,
        bestMonths = "October to March",
        categories = listOf(TravelCategory.WATERFALLS, TravelCategory.MOUNTAINS, TravelCategory.NATURE),
        attractions = listOf(
            Attraction(
                id = "bee-falls-pachmarhi",
                destinationId = "mp-pachmarhi",
                name = "Bee Falls (Jamuna Prapat)",
                description = "Spectacular 35-meter waterfall tumbling through rocky ravines with invigorating natural splash pools.",
                category = "Waterfall / Nature",
                latitude = 22.4621,
                longitude = 78.4208,
                entryFeeAdult = "Included in Forest Gypsy Entry (₹50-100)",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                insiderTip = "Steep stairs require moderate fitness; carry water and footwear with good grip."
            ),
            Attraction(
                id = "dhoopgarh-pachmarhi",
                destinationId = "mp-pachmarhi",
                name = "Dhoopgarh Sunset Point (1,352 m)",
                description = "Highest point in the Satpura Range and Madhya Pradesh, offering a breathtaking 360-degree sunset over jagged wooded valleys.",
                category = "Panoramic Viewpoint",
                latitude = 22.4497,
                longitude = 78.4392,
                entryFeeAdult = "Forest permit required",
                recommendedDurationMinutes = 90,
                familyFriendly = true,
                photographyAllowed = true
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-jatashankar-cave",
                destinationId = "mp-pachmarhi",
                name = "Jatashankar Cave Shrine",
                description = "Deep natural limestone cave gorge with hanging stalactites resembling Lord Shiva's matted hair, surrounded by natural fresh springs.",
                whyItIsSpecial = "Spiritual natural sanctuary hidden beneath massive overhanging boulders.",
                category = "Cave Shrine",
                location = "Pachmarhi Cantonment outskirts",
                latitude = 22.4831,
                longitude = 78.4410,
                crowdLevel = "Low to Moderate",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Bhutte Ka Kees & Poha-Jalebi",
                    isVegetarian = true,
                    description = "Grated corn slow-cooked in milk, tempered with mustard, hing, and fresh grated coconut.",
                    popularAt = "Pachmarhi Market Stalls & MP Tourism Glen View",
                    priceRange = "₹60 - ₹120"
                )
            )
        ),
        stays = listOf(
            Accommodation(
                id = "stay-mpt-champak",
                name = "MPT Champak Bungalow",
                category = "Colonial Heritage Hotel",
                pricePerNight = 3200,
                rating = 4.4f,
                amenities = listOf("Garden Lawns", "Multi-Cuisine Restaurant", "Heritage Architecture")
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Bhopal" to 200, "Nagpur" to 250, "Jabalpur" to 240, "Hyderabad" to 720),
            drivingTimes = mapOf("Bhopal" to "4.5 Hours", "Nagpur" to "5.5 Hours"),
            roadTripRoute = "Bhopal -> Hoshangabad -> Pipariya -> Pachmarhi ghat road.",
            nearestRailwayStation = "Pipariya (PPI - 47 km on Mumbai-Howrah main line)",
            nearestAirport = "Bhopal Raja Bhoj Airport (BHO - 200 km) / Nagpur Airport (NAG - 250 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 2500,
            foodEstimatePerDay = 800,
            activitiesTotal = 1200,
            travelEstimate = 2500,
            totalEstimateMin = 7000,
            totalEstimateMax = 15000
        ),
        seasons = RegionalSeasonalHelper.createDeccanSeasons("mp-pachmarhi")
    )

    val khajuraho = Destination(
        id = "mp-khajuraho",
        name = "Khajuraho",
        state = "Madhya Pradesh",
        stateCode = "MP",
        district = "Chhatarpur",
        latitude = 24.8318,
        longitude = 79.9199,
        tagline = "UNESCO World Heritage: pinnacle of medieval Chandela art, temple architecture, and timeless stone carvings",
        description = "Built between 950 and 1050 CE by the Chandela dynasty, Khajuraho's sandstone temples are celebrated worldwide for their architectural balance, intricate stone sculptures celebrating human life, devotion, and erotic themes.",
        shortDescription = "World-famous UNESCO group of medieval stone temples with sublime carvings",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 3,
        altitude = "283 m",
        destinationTypes = listOf("UNESCO World Heritage", "Heritage", "Architecture", "Spiritual"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "October to March (Khajuraho Dance Festival in February)",
        categories = listOf(TravelCategory.HERITAGE, TravelCategory.TEMPLES),
        attractions = listOf(
            Attraction(
                id = "kandariya-mahadeva-khajuraho",
                destinationId = "mp-khajuraho",
                name = "Kandariya Mahadeva Temple (Western Group)",
                description = "Masterpiece of Chandela architectural brilliance standing 31 meters high with over 800 exquisitely carved statues.",
                category = "UNESCO World Heritage Site",
                latitude = 24.8532,
                longitude = 79.9195,
                entryFeeAdult = "₹40 for Indians, ₹600 Foreigners (ASI composite ticket)",
                openingTime = "06:00",
                closingTime = "18:00",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                photographyAllowed = true
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-raneh-falls-ken",
                destinationId = "mp-khajuraho",
                name = "Raneh Falls & Ken River Crystalline Granite Canyon",
                description = "Deep natural canyon formed by multi-hued crystalline granite rocks (pink, green, grey, and red) where Ken River plunges in numerous waterfalls.",
                whyItIsSpecial = "Mini Grand Canyon of India, located just 20 km from Khajuraho temples inside Ken Ghariyal Sanctuary.",
                category = "Canyon Waterfall & Geology",
                location = "Ken Ghariyal Sanctuary, 20 km from Khajuraho",
                latitude = 24.9125,
                longitude = 79.9722,
                entryFee = "₹100 + Vehicle permit",
                crowdLevel = "Low",
                difficulty = "Easy"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Bundelkhandi Thali with Kadhi-Badi & Mawa Jalebi",
                    isVegetarian = true,
                    description = "Authentic Bundelkhand rustic meal with slow-cooked gram flour dumplings and rich mawa sweets.",
                    popularAt = "Raja Cafe & Local Bhojnalayas near Western Group",
                    priceRange = "₹150 - ₹280"
                )
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Jhansi" to 175, "Kanpur" to 220, "Varanasi" to 380, "Delhi" to 600),
            drivingTimes = mapOf("Jhansi" to "3.5 Hours", "Kanpur" to "5 Hours"),
            roadTripRoute = "Jhansi -> Mauranipur -> Chhatarpur -> Khajuraho via NH 39.",
            nearestRailwayStation = "Khajuraho Railway Station (KURJ - 5 km) / Satna (STA - 115 km)",
            nearestAirport = "Khajuraho Airport (HJR - 4 km, daily direct flights from Delhi)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 2800,
            foodEstimatePerDay = 900,
            activitiesTotal = 800,
            travelEstimate = 2500,
            totalEstimateMin = 7000,
            totalEstimateMax = 16000
        ),
        seasons = RegionalSeasonalHelper.createDeccanSeasons("mp-khajuraho")
    )

    val destinations: List<Destination> = listOf(pachmarhi, khajuraho)
}
