package com.example.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory

fun destinationPin(hue: Float): BitmapDescriptor {
    val bitmap = Bitmap.createBitmap(72, 92, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.HSVToColor(floatArrayOf(hue, 0.8f, 0.8f)) }
    val tail = Path().apply { moveTo(13f, 44f); lineTo(36f, 90f); lineTo(59f, 44f); close() }
    canvas.drawPath(tail, paint)
    canvas.drawCircle(36f, 34f, 32f, paint)
    paint.color = Color.WHITE
    canvas.drawCircle(36f, 34f, 16f, paint)
    paint.color = Color.HSVToColor(floatArrayOf(hue, 0.8f, 0.8f))
    canvas.drawCircle(36f, 34f, 7f, paint)
    return BitmapDescriptorFactory.fromBitmap(bitmap)
}
