package com.example.data.local

import androidx.room.Dao
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Relation
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "user_profiles")
data class UserProfileEntity(
    @PrimaryKey val uid: String,
    val name: String,
    val email: String,
    val avatarUrl: String,
    val preferencesJson: String,
    val updatedAt: Long,
    val pendingSync: Boolean
)

@Entity(tableName = "planner_trips")
data class TripEntity(
    @PrimaryKey val id: String,
    val title: String,
    val ownerUid: String,
    val currency: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "day_schedules", foreignKeys = [ForeignKey(
    entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE
)], indices = [Index("tripId")])
data class DayScheduleEntity(@PrimaryKey val id: String, val tripId: String, val dayNumber: Int, val title: String)

@Entity(tableName = "trip_activities", foreignKeys = [ForeignKey(
    entity = DayScheduleEntity::class, parentColumns = ["id"], childColumns = ["dayId"], onDelete = ForeignKey.CASCADE
)], indices = [Index("dayId")])
data class ActivityEntity(
    @PrimaryKey val id: String,
    val dayId: String,
    val position: Int,
    val timeSlot: String,
    val title: String,
    val notes: String,
    val latitude: Double?,
    val longitude: Double?,
    val estimatedCost: Double
)

data class DayWithActivities(
    @Embedded val day: DayScheduleEntity,
    @Relation(parentColumn = "id", entityColumn = "dayId") val activities: List<ActivityEntity>
)

data class TripWithDays(
    @Embedded val trip: TripEntity,
    @Relation(entity = DayScheduleEntity::class, parentColumn = "id", entityColumn = "tripId") val days: List<DayWithActivities>
)

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profiles WHERE uid = :uid")
    fun observe(uid: String): Flow<UserProfileEntity?>
    @Query("SELECT * FROM user_profiles WHERE uid = :uid")
    suspend fun get(uid: String): UserProfileEntity?
    @Upsert suspend fun upsert(profile: UserProfileEntity)
    @Query("DELETE FROM user_profiles WHERE uid = :uid") suspend fun delete(uid: String)
}

@Dao
interface PlannerDao {
    @Transaction @Query("SELECT * FROM planner_trips WHERE id = :id")
    fun observe(id: String): Flow<TripWithDays?>
    @Transaction @Query("SELECT * FROM planner_trips WHERE id = :id")
    suspend fun get(id: String): TripWithDays?
    @Query("SELECT * FROM planner_trips WHERE ownerUid = :uid ORDER BY updatedAt DESC")
    fun observeTrips(uid: String): Flow<List<TripEntity>>
    @Upsert suspend fun upsertTrip(trip: TripEntity)
    @Upsert suspend fun upsertDays(days: List<DayScheduleEntity>)
    @Upsert suspend fun upsertActivities(activities: List<ActivityEntity>)
    @Query("DELETE FROM day_schedules WHERE tripId = :tripId") suspend fun clearDays(tripId: String)
    @Query("DELETE FROM planner_trips WHERE id = :id") suspend fun delete(id: String)
}
