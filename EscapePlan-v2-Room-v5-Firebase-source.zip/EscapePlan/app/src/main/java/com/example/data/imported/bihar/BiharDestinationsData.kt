package com.example.data.imported.bihar

import com.example.data.imported.common.RegionalSeasonalHelper
import com.example.data.model.Accommodation
import com.example.data.model.Attraction
import com.example.data.model.BestTimeInfo
import com.example.data.model.BudgetBreakdown
import com.example.data.model.Destination
import com.example.data.model.DiscoveryLevel
import com.example.data.model.FoodGuide
import com.example.data.model.FoodItem
import com.example.data.model.HiddenGem
import com.example.data.model.TravelCategory
import com.example.data.model.TravelRouteInfo

object BiharDestinationsData {

    val bodhGaya = Destination(
        id = "bihar-bodh-gaya",
        name = "Bodh Gaya & Nalanda",
        state = "Bihar",
        stateCode = "BR",
        district = "Gaya & Nalanda",
        latitude = 24.6961,
        longitude = 84.9869,
        tagline = "Cradle of Enlightenment: UNESCO Mahabodhi Temple, sacred Bodhi Tree, and ancient Nalanda University ruins",
        description = "The most sacred pilgrimage site in Buddhism, Bodh Gaya is where Siddhartha Gautama attained supreme enlightenment beneath the sacred Bodhi Tree around 500 BCE. The grand 50-meter pyramid-shaped Mahabodhi Temple is a UNESCO World Heritage site surrounded by magnificent international Buddhist monasteries (Thai, Japanese, Bhutanese, Tibetan). Nearby Nalanda preserves the ruins of the world's first residential international university.",
        shortDescription = "Most sacred Buddhist pilgrimage site and ancient international university",
        bestDurationMinDays = 2,
        bestDurationMaxDays = 4,
        altitude = "111 m",
        destinationTypes = listOf("Spiritual", "UNESCO World Heritage", "Ancient Ruins", "Buddhism", "History"),
        discoveryLevel = DiscoveryLevel.ICONIC,
        bestMonths = "October to March",
        categories = listOf(TravelCategory.TEMPLES, TravelCategory.HERITAGE, TravelCategory.SPIRITUAL),
        attractions = listOf(
            Attraction(
                id = "mahabodhi-temple-bodhgaya",
                destinationId = "bihar-bodh-gaya",
                name = "Mahabodhi Temple & Sacred Bodhi Tree",
                description = "Grand 5th-6th century brick temple complex enshrining the Diamond Throne (Vajrasana) and direct descendant of the original sacred Peepal tree where the Buddha attained Nirvana.",
                category = "UNESCO World Heritage Site",
                latitude = 24.6960,
                longitude = 84.9914,
                entryFeeAdult = "Free (Mobile phones and cameras not permitted inside inner courtyard)",
                openingTime = "05:00",
                closingTime = "21:00",
                recommendedDurationMinutes = 150,
                familyFriendly = true,
                insiderTip = "Sit in quiet meditation near the Bodhi Tree in the early morning at 06:00 AM as monks chant in Pali, Tibetan, and Japanese."
            ),
            Attraction(
                id = "nalanda-university-ruins",
                destinationId = "bihar-bodh-gaya",
                name = "Ancient Nalanda Mahavihara Ruins",
                description = "UNESCO ruins of the 5th-century CE monastic university that educated 10,000 students and scholars including Xuanzang and Aryabhata across 10 massive red brick viharas and stupas.",
                category = "UNESCO World Heritage Ruins",
                latitude = 25.1357,
                longitude = 85.4450,
                entryFeeAdult = "₹40 for Indians, ₹600 Foreigners",
                openingTime = "09:00",
                closingTime = "17:00",
                recommendedDurationMinutes = 120,
                familyFriendly = true,
                photographyAllowed = true
            )
        ),
        hiddenGems = listOf(
            HiddenGem(
                id = "gem-barabar-caves",
                destinationId = "bihar-bodh-gaya",
                name = "Barabar Caves (Oldest Rock-Cut Caves in India)",
                description = "Dating to Emperor Ashoka's Maurya Empire (3rd century BCE), these granite caves feature extraordinary mirror-like polished interior walls and unique acoustic echo chambers.",
                whyItIsSpecial = "Oldest surviving rock-cut caves in India, which inspired E.M. Forster's Marabar Caves in 'A Passage to India'.",
                category = "Ancient Rock-Cut Heritage",
                location = "Sultanpur, 40 km north of Gaya",
                latitude = 25.0064,
                longitude = 85.0625,
                entryFee = "₹25",
                crowdLevel = "Low",
                difficulty = "Moderate"
            )
        ),
        foodGuide = FoodGuide(
            localSpecialties = listOf(
                FoodItem(
                    name = "Bihari Litti Chokha with Ghee",
                    isVegetarian = true,
                    description = "Roasted whole wheat dough balls stuffed with spiced sattu (roasted gram flour), dipped in pure desi ghee and served with charred eggplant-tomato mash.",
                    popularAt = "Local eateries near Sujata Bridge & Bodh Gaya market",
                    priceRange = "₹80 - ₹150"
                )
            )
        ),
        stays = listOf(
            Accommodation(
                id = "stay-bodhgaya-regency",
                name = "The Royal Residency Bodhgaya",
                category = "Boutique Heritage Hotel",
                pricePerNight = 3500,
                rating = 4.5f,
                amenities = listOf("Zen Gardens", "Meditation Hall", "Multi-Cuisine Vegetarian Dining")
            )
        ),
        travelRoute = TravelRouteInfo(
            originDistances = mapOf("Gaya" to 12, "Patna" to 110, "Varanasi" to 250, "Kolkata" to 470),
            drivingTimes = mapOf("Gaya" to "25 Mins", "Patna" to "3 Hours via 4-lane NH 22"),
            roadTripRoute = "Patna -> Jehanabad -> Gaya -> Bodh Gaya via NH 22.",
            nearestRailwayStation = "Gaya Junction (GAYA - 15 km, major junction on Grand Chord route)",
            nearestAirport = "Gaya International Airport (GAY - 7 km, seasonal international pilgrim flights) / Patna Airport (PAT - 115 km)"
        ),
        budget = BudgetBreakdown(
            stayEstimatePerNight = 2200,
            foodEstimatePerDay = 750,
            activitiesTotal = 600,
            travelEstimate = 1500,
            totalEstimateMin = 5050,
            totalEstimateMax = 12000
        ),
        seasons = RegionalSeasonalHelper.createDeccanSeasons("bihar-bodh-gaya")
    )

    val destinations: List<Destination> = listOf(bodhGaya)
}
