package com.example.domain

import com.example.data.repository.TripRepository

class GenerateItineraryUseCase(private val repository: TripRepository) {
    suspend operator fun invoke(prompt: String): Result<String> = repository.generate(prompt.trim())
}
