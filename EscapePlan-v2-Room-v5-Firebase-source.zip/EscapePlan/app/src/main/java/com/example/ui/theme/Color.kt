package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette (Warm Wanderlust / Coastal & Earth)
val TealPrimary = Color(0xFFC55432)
val TealOnPrimary = Color(0xFFFFFFFF)
val TealPrimaryContainer = Color(0xFFFFDBCF)
val TealOnPrimaryContainer = Color(0xFF451000)

val AmberSecondary = Color(0xFF7B625A)
val AmberOnSecondary = Color(0xFFFFFFFF)
val AmberSecondaryContainer = Color(0xFFF2DFD8)
val AmberOnSecondaryContainer = Color(0xFF2E1510)

val ForestTertiary = Color(0xFFB7862E)
val ForestTertiaryContainer = Color(0xFFFFDEA5)

val SandBackground = Color(0xFFFCFAF7)
val SandSurface = Color(0xFFFFFDFC)
val SandSurfaceVariant = Color(0xFFF4EFEB)
val SandOnSurface = Color(0xFF211A18)
val SandOnSurfaceVariant = Color(0xFF756A66)

// Dark Theme Palette (Deep Twilight Journey)
val DarkTealPrimary = Color(0xFFFFB59D)
val DarkTealOnPrimary = Color(0xFF652000)
val DarkTealContainer = Color(0xFF8E3518)
val DarkTealOnContainer = Color(0xFFFFDBCF)

val DarkAmberSecondary = Color(0xFFE8BDAF)
val DarkAmberOnSecondary = Color(0xFF442A22)
val DarkAmberContainer = Color(0xFF5D4038)
val DarkAmberOnContainer = Color(0xFFFFDBD0)

val DarkBackground = Color(0xFF181210)
val DarkSurface = Color(0xFF211A18)
val DarkSurfaceVariant = Color(0xFF332925)
val DarkOnSurface = Color(0xFFF1DFDA)
val DarkOnSurfaceVariant = Color(0xFFD5C2BC)
