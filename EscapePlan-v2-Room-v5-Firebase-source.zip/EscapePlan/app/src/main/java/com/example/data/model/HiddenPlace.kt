package com.example.data.model

import kotlinx.serialization.Serializable

@Serializable
data class HiddenPlace(
    val id: String,
    val stateOrUt: String,
    val regionType: String,
    val name: String,
    val districtOrBase: String,
    val categories: List<String>,
    val whyVisit: String,
    val bestSeason: String,
    val suggestedTime: String,
    val difficulty: String,
    val stayArea: String,
    val staySuggestion: String,
    val foodToTry: String,
    val transport: String,
    val cautionOrPermit: String,
    val evidenceStatus: String,
    val primarySourceUrl: String,
    val googleMapsUrl: String,
    val googleHotelsUrl: String,
    val makeMyTripUrl: String,
    val oyoUrl: String,
    val foodMapUrl: String,
    val instagramUrl: String,
    val facebookUrl: String,
    val lastReviewed: String
)
