package com.example.data.engine

import com.example.data.model.Destination
import java.util.Locale

/** Keeps EscapePlan IDs and detailed content while adding the second export's catalog. */
object CatalogMerger {
    data class Result(val destinations: List<Destination>, val aliases: Map<String, String>)

    private fun normalized(value: String) = value.lowercase(Locale.ROOT)
        .replace(Regex("[^\\p{L}\\p{N}]"), "")

    fun merge(original: List<Destination>, incoming: List<Destination>): Result {
        val records = linkedMapOf<String, Destination>()
        val names = mutableMapOf<String, String>()
        val aliases = mutableMapOf<String, String>()
        for (candidate in original + incoming) {
            val key = normalized(candidate.state) + ":" + normalized(candidate.name)
            val id = aliases[candidate.id] ?: names[key] ?: candidate.id
            val previous = records[id]
            records[id] = if (previous == null) candidate else enrich(previous, candidate)
            names[key] = id
            aliases[candidate.id] = id
        }
        return Result(records.values.toList(), aliases)
    }

    private fun <T> union(first: List<T>, second: List<T>, key: (T) -> String): List<T> =
        (first + second).distinctBy { normalized(key(it)) }

    private fun enrich(a: Destination, b: Destination): Destination = a.copy(
        latitude = if (a.latitude == 0.0 && a.longitude == 0.0) b.latitude else a.latitude,
        longitude = if (a.latitude == 0.0 && a.longitude == 0.0) b.longitude else a.longitude,
        district = a.district.ifBlank { b.district },
        stateCode = a.stateCode.ifBlank { b.stateCode },
        description = a.description.ifBlank { b.description },
        heroImage = a.heroImage.ifBlank { b.heroImage },
        coverResId = a.coverResId ?: b.coverResId,
        categories = (a.categories + b.categories).distinct(),
        destinationTypes = (a.destinationTypes + b.destinationTypes).distinct(),
        attractions = union(a.attractions, b.attractions) { it.name }.map { it.copy(destinationId = a.id) },
        stays = union(a.stays, b.stays) { it.name }.map { it.copy(destinationId = a.id) },
        hiddenGems = union(a.hiddenGems, b.hiddenGems) { it.name }.map { it.copy(destinationId = a.id) },
        foodGuide = a.foodGuide.copy(
            localSpecialties = union(a.foodGuide.localSpecialties, b.foodGuide.localSpecialties) { it.name },
            restaurants = union(a.foodGuide.restaurants, b.foodGuide.restaurants) { it.name }
        ),
        travelRoute = a.travelRoute.copy(
            originDistances = b.travelRoute.originDistances + a.travelRoute.originDistances,
            drivingTimes = b.travelRoute.drivingTimes + a.travelRoute.drivingTimes
        ),
        seasons = union(a.seasons, b.seasons) { it.month },
        foodSpecialties = union(a.foodSpecialties, b.foodSpecialties) { it.name },
        restaurantsList = union(a.restaurantsList, b.restaurantsList) { it.name },
        itineraryTemplates = union(a.itineraryTemplates, b.itineraryTemplates) { it.id },
        localExperiences = union(a.localExperiences, b.localExperiences) { it.name },
        scenicRoutes = union(a.scenicRoutes, b.scenicRoutes) { it.routeName },
        timedScheduleTemplate = a.timedScheduleTemplate.ifEmpty { b.timedScheduleTemplate },
        travelRoutesList = a.travelRoutesList.ifEmpty { b.travelRoutesList },
        budgetPlans = a.budgetPlans.ifEmpty { b.budgetPlans },
        safetyNotes = listOf(a.safetyNotes, b.safetyNotes).filter { it.isNotBlank() }.distinct().joinToString("\n")
    )
}
