package com.example.data.repository

import android.content.Context
import com.example.core.operation
import com.example.data.datasource.DestinationsDataSource
import com.example.data.model.Destination
import com.example.data.model.PlaceCatalogEntry
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

class PlaceCatalogRepository(context: Context) {
    private val assets = context.applicationContext.assets

    suspend fun load(): Result<List<PlaceCatalogEntry>> = operation {
        withContext(Dispatchers.IO) {
            val entries = assets.open("places_catalog.json").bufferedReader().use {
                Json.decodeFromString<List<PlaceCatalogEntry>>(it.readText())
            }
            require(entries.map { it.id }.distinct().size == entries.size) { "Duplicate catalog IDs" }
            entries.forEach {
                require(it.id.isNotBlank() && it.name.isNotBlank() && it.categories.isNotEmpty()) { "Incomplete catalog entry" }
                require((it.latitude == null) == (it.longitude == null)) { "Incomplete coordinates" }
                require(it.latitude == null || it.latitude in -90.0..90.0) { "Invalid latitude" }
                require(it.longitude == null || it.longitude in -180.0..180.0) { "Invalid longitude" }
            }
            entries
        }
    }

    fun existingGuide(entry: PlaceCatalogEntry): Destination? {
        val names = (entry.aliases + entry.name).map(::normalized).toSet()
        val matches = DestinationsDataSource.destinations.filter {
            normalized(it.name) in names || normalized(it.id) in names
        }
        return matches.singleOrNull()
    }

    private fun normalized(value: String): String = value.trim().lowercase(Locale.ROOT)
}
