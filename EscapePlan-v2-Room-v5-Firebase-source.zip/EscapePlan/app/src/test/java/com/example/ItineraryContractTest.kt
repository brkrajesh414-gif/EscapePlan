package com.example

import com.example.domain.Itinerary
import com.example.domain.PlanActivity
import com.example.domain.PlanDay
import com.example.domain.validated
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Test

class ItineraryContractTest {
    private fun plan(activity: PlanActivity = PlanActivity("09:00", "Museum", "Confirm hours", 17.4, 78.5, 200.0)) =
        Itinerary("Hyderabad", "INR", listOf(PlanDay(1, "Heritage", listOf(activity))))
    @Test fun roundTripSerialization() {
        val original = plan().validated()
        assertEquals(original, Json.decodeFromString<Itinerary>(Json.encodeToString(original)))
    }
    @Test(expected = IllegalArgumentException::class)
    fun rejectsImpossibleTime() { plan(PlanActivity("25:00", "Museum")).validated() }
    @Test(expected = IllegalArgumentException::class)
    fun rejectsPartialCoordinates() { plan(PlanActivity("09:00", "Museum", latitude = 17.4)).validated() }
    @Test(expected = IllegalArgumentException::class)
    fun rejectsNegativeCost() { plan(PlanActivity("09:00", "Museum", estimatedCost = -100.0)).validated() }
}
