package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.MIGRATION_4_5
import com.example.data.local.SavedTripEntity
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PlannerMigrationTest {
    @Test fun versionFourTablesSurviveMigrationAndRoomValidatesNewTables() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val name = "escapeplan-migration5-test"
        context.deleteDatabase(name)
        try {
            val fixture = Room.databaseBuilder(context, AppDatabase::class.java, name).allowMainThreadQueries().build()
            fixture.tripDao().insertTrip(SavedTripEntity("legacy", "Original trip", "Araku", "Hyderabad", 3, 10000, "Solo", "Keep", "{}", 1))
            val sqlite = fixture.openHelper.writableDatabase
            listOf("trip_activities", "day_schedules", "planner_trips", "user_profiles").forEach { sqlite.execSQL("DROP TABLE $it") }
            sqlite.execSQL("PRAGMA user_version = 4")
            fixture.close()
            val migrated = Room.databaseBuilder(context, AppDatabase::class.java, name)
                .addMigrations(MIGRATION_4_5).allowMainThreadQueries().build()
            try {
                migrated.openHelper.writableDatabase.query("SELECT title FROM saved_trips WHERE id = 'legacy'").use { cursor ->
                    check(cursor.moveToFirst())
                    assertEquals("Original trip", cursor.getString(0))
                }
                migrated.openHelper.writableDatabase.query("SELECT COUNT(*) FROM planner_trips").use { cursor ->
                    check(cursor.moveToFirst()); assertEquals(0, cursor.getInt(0))
                }
            } finally { migrated.close() }
        } finally { context.deleteDatabase(name) }
    }
}
