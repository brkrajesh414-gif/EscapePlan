package com.example

import com.example.data.datasource.DestinationsDataSource
import com.example.data.engine.CatalogMerger
import com.example.data.model.*
import org.junit.Assert.*
import org.junit.Test

class CatalogMergeTest {
    private fun destination(id: String, name: String = "Hyderabad", state: String = "Telangana") =
        Destination(id = id, name = name, state = state, tagline = "Test", description = "Test record")

    @Test fun preservesOriginalIdAndDetails() {
        val a = destination("original").copy(attractions = listOf(Attraction(id = "old", name = "Fort", description = "Test", category = "Heritage")))
        val b = destination("imported").copy(latitude = 17.4, longitude = 78.5,
            attractions = listOf(Attraction(id = "new", name = "Museum", description = "Test", category = "Heritage")))
        val result = CatalogMerger.merge(listOf(a), listOf(b))
        assertEquals(1, result.destinations.size)
        assertEquals("original", result.destinations.single().id)
        assertEquals("original", result.aliases["imported"])
        assertEquals(2, result.destinations.single().attractions.size)
        assertEquals(17.4, result.destinations.single().latitude, 0.0001)
    }

    @Test fun sameNameInDifferentStatesRemainsSeparate() {
        val result = CatalogMerger.merge(listOf(destination("a")), listOf(destination("b", state = "Other State")))
        assertEquals(2, result.destinations.size)
    }

    @Test fun duplicateAttractionsAreNotRepeated() {
        val a = destination("a").copy(attractions = listOf(Attraction(id = "one", name = "City Fort", description = "Test", category = "Heritage")))
        val b = destination("b").copy(attractions = listOf(Attraction(id = "two", name = "City-Fort", description = "Test", category = "Heritage")))
        assertEquals(1, CatalogMerger.merge(listOf(a), listOf(b)).destinations.single().attractions.size)
    }

    @Test fun catalogIncludesBothExportsAndKeepsOldLinksResolvable() {
        val all = DestinationsDataSource.destinations
        assertEquals(all.size, all.map { it.id }.distinct().size)
        for (old in DestinationsDataSource.originalDestinations) {
            val merged = DestinationsDataSource.getDestinationById(old.id)
            assertNotNull(old.id, merged)
            assertTrue(old.id, merged!!.attractions.size >= old.attractions.distinctBy { it.name.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "") }.size)
        }
        assertTrue(all.any { it.state == "Gujarat" })
        assertTrue(all.any { it.state == "Bihar" })
        for (imported in com.example.data.imported.DestinationsDataSource.destinations) {
            assertNotNull(imported.id, DestinationsDataSource.getDestinationById(imported.id))
        }
        assertNull(DestinationsDataSource.getDestinationById("nonexistent-id"))
    }
}
